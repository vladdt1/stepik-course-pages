import {defineStore} from 'pinia'
import {ref} from 'vue'
import {request,query} from '../lib/api'
export const useCatalogStore=defineStore('catalog',()=>{
 const items=ref([]),categories=ref([]),nextCursor=ref(0),loading=ref(false),error=ref(null)
 let controller=null,generation=0
 async function load(filters={},append=false){controller?.abort();controller=new AbortController();const mine=++generation;loading.value=true;error.value=null
  try{const data=await request('/catalog/products'+query({...filters,limit:filters.limit||6,after_id:append?nextCursor.value:0}),{signal:controller.signal});if(mine!==generation)return;const merged=append?[...items.value,...data.items]:data.items;items.value=[...new Map(merged.map(p=>[p.id,p])).values()];nextCursor.value=data.next_cursor}
  catch(e){if(e.name!=='AbortError'&&mine===generation)error.value=e}
  finally{if(mine===generation)loading.value=false}
 }
 async function loadCategories(){categories.value=(await request('/catalog/categories')).items}
 function cancel(){++generation;controller?.abort();loading.value=false}
 return{items,categories,nextCursor,loading,error,load,loadCategories,cancel}
})
