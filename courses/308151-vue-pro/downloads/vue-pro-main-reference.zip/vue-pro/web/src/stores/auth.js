import {defineStore} from 'pinia'
import {ref,computed,onScopeDispose} from 'vue'
import {request} from '../lib/api'
import {clearPending,loadPending} from '../lib/checkout'
export const useAuthStore=defineStore('auth',()=>{
 const user=ref(null),status=ref('unknown'),initializing=ref(false)
 let initialization=null
 const authenticated=computed(()=>status.value==='authenticated'),operator=computed(()=>user.value?.role==='operator')
 function setUser(value){const previous=user.value?.id;if(previous!==value?.id){if(!value||!loadPending(value.id))clearPending();window.dispatchEvent(new CustomEvent('delivery:identity-changed'))}user.value=value;status.value=value?'authenticated':'guest'}
 async function restore(){if(initialization)return initialization;initializing.value=true;initialization=(async()=>{try{setUser(await request('/auth/me'))}catch(e){if(e.status===401)setUser(null);else{status.value='unknown';throw e}}finally{initializing.value=false}})();try{return await initialization}finally{initialization=null}}
 async function ensure(){if(status.value==='unknown')await restore()}
 async function login(email,password){const u=await request('/auth/login',{method:'POST',body:{email,password}});setUser(u);return u}
 async function logout(){await request('/auth/logout',{method:'POST'});setUser(null)}
 function expire(){setUser(null)}
 const unauthorized=()=>expire();window.addEventListener('delivery:unauthorized',unauthorized);onScopeDispose(()=>window.removeEventListener('delivery:unauthorized',unauthorized))
 return{user,status,initializing,authenticated,operator,restore,ensure,login,logout,expire}
})
