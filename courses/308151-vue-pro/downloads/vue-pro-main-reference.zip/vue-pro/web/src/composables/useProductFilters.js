import{ref,computed}from'vue'
import{filterProducts}from'../lib/domain'
export function useProductFilters(products){const search=ref(''),category=ref(0);const filtered=computed(()=>filterProducts(products.value,search.value,category.value));return{search,category,filtered}}
