import{ref}from'vue'
export function useDisclosure(){const opened=ref(false);return{opened,open:()=>opened.value=true,close:()=>opened.value=false,toggle:()=>opened.value=!opened.value}}
