import{createRouter,createWebHistory}from'vue-router'
import{useAuthStore}from'./stores/auth'
export function makeRouter(history=createWebHistory()){
 const router=createRouter({history,scrollBehavior:()=>({top:0}),routes:[
 {path:'/',redirect:'/catalog'},
 {path:'/catalog',name:'catalog',component:()=>import('./views/CatalogView.vue')},
 {path:'/products/:id',name:'product',component:()=>import('./views/ProductView.vue')},
 {path:'/login',name:'login',component:()=>import('./views/LoginView.vue')},
 {path:'/register',name:'register',component:()=>import('./views/RegisterView.vue')},
 {path:'/cart',name:'cart',meta:{auth:true},component:()=>import('./views/CartView.vue')},
 {path:'/checkout',name:'checkout',meta:{auth:true},component:()=>import('./views/CheckoutView.vue')},
 {path:'/orders',name:'orders',meta:{auth:true},component:()=>import('./views/OrdersView.vue')},
 {path:'/orders/:id',name:'order',meta:{auth:true},component:()=>import('./views/OrderView.vue')},
 {path:'/operator',name:'operator',meta:{auth:true,operator:true},component:()=>import('./views/OperatorView.vue')},
 {path:'/forbidden',name:'forbidden',component:()=>import('./views/MessageView.vue'),props:{title:'Доступ ограничен',message:'Эта страница доступна оператору.'}},
 {path:'/:pathMatch(.*)*',name:'notfound',component:()=>import('./views/MessageView.vue'),props:{title:'Страница не найдена',message:'Проверьте адрес или откройте каталог.'}},
 ]})
 router.beforeEach(async to=>{const auth=useAuthStore();try{await auth.ensure()}catch{if(to.meta.auth)return{name:'login',query:{return:to.fullPath}}}
 if(to.meta.auth&&!auth.authenticated)return{name:'login',query:{return:to.fullPath}}
 if(to.meta.operator&&!auth.operator)return{name:'forbidden'}
 })
 return router
}
