<script setup>
import{watch,ref}from'vue';import{useRoute,useRouter}from'vue-router';import{useAuthStore}from'./stores/auth';import{useCartStore}from'./stores/cart';import NoticeBox from'./components/NoticeBox.vue'
const auth=useAuthStore(),cart=useCartStore(),route=useRoute(),router=useRouter(),error=ref(null)
watch(()=>auth.user?.id,async id=>{if(id)try{await cart.load()}catch(e){error.value=e}})
watch(()=>auth.status,status=>{if(status==='guest'&&route.meta.auth)router.replace({name:'login',query:{return:route.fullPath}})})
async function logout(){try{await auth.logout();await router.push('/catalog')}catch(e){error.value=e}}
</script>
<template><header class="header"><RouterLink to="/catalog" class="brand">Ложка и Go <span>доставка</span></RouterLink><nav aria-label="Главная навигация"><RouterLink to="/catalog">Каталог</RouterLink><template v-if="auth.authenticated"><RouterLink to="/cart">Корзина <strong>{{cart.count}}</strong></RouterLink><RouterLink to="/orders">Мои заказы</RouterLink><RouterLink v-if="auth.operator" to="/operator">Оператор</RouterLink><button class="link" @click="logout">Выйти</button></template><RouterLink v-else to="/login">Войти</RouterLink></nav></header><main class="main"><NoticeBox :error="error"/><RouterView/></main><footer class="footer">Vue + Go + PostgreSQL · учебный сервис доставки</footer></template>
