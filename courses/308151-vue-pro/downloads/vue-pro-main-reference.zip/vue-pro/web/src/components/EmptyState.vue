<script setup>defineProps({title:{type:String,default:'Пока ничего нет'}})</script>
<template><section class="empty"><h2>{{title}}</h2><p><slot/></p><slot name="action"/></section></template>
