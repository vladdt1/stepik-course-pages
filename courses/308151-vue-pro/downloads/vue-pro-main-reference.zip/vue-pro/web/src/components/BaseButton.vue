<script setup>defineProps({busy:Boolean,variant:{type:String,default:'primary'}})</script>
<template><button :class="['button',variant]" :disabled="busy" :aria-busy="busy"><slot>{{busy?'Подождите…':'Продолжить'}}</slot></button></template>
