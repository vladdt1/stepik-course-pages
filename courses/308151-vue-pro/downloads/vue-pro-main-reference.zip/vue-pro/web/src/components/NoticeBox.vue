<script setup>import{errorText}from'../lib/api';defineProps({error:Object,message:String})</script>
<template><p v-if="error||message" class="notice" :role="error?'alert':'status'">{{error?errorText(error):message}}</p></template>
