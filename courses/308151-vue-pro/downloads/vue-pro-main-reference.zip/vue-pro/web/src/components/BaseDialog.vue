<script setup>
import{ref,watch,nextTick,onBeforeUnmount,useId}from'vue'
const open=defineModel({type:Boolean,default:false});defineProps({title:String});const titleId=useId();const dialog=ref(null);let previous=null
watch(open,async value=>{await nextTick();if(value&&!dialog.value.open){previous=document.activeElement;dialog.value.showModal()}else if(!value&&dialog.value.open){dialog.value.close();previous?.focus()}},{immediate:true})
function close(){open.value=false}
onBeforeUnmount(()=>{dialog.value?.close();previous?.focus()})
</script>
<template><Teleport to="body"><dialog ref="dialog" :aria-labelledby="titleId" @cancel.prevent="close" @close="close"><h2 :id="titleId">{{title}}</h2><slot/><footer class="actions"><slot name="actions"><button class="button secondary" @click="close">Закрыть</button></slot></footer></dialog></Teleport></template>
