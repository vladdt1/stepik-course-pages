<script setup>
import{formatMoney}from'../lib/domain';defineProps({product:{type:Object,required:true},busy:Boolean});defineEmits(['add'])
</script>
<template><article class="product"><RouterLink :to="'/products/'+product.id" class="product-link"><img :src="'/products/'+product.id+'.svg'" :alt="product.name" width="180" height="120"><h2>{{product.name}}</h2></RouterLink><p>{{product.description}}</p><p class="price">{{formatMoney(product.price_cents)}}</p><small>В наличии: {{product.stock}}</small><button class="button" :disabled="busy||product.stock<1" @click="$emit('add',product.id)">{{product.stock<1?'Закончился':'В корзину'}}</button></article></template>
