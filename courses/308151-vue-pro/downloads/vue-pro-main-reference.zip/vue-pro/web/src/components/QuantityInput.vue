<script setup>
const model=defineModel({type:Number,default:1});const props=defineProps({disabled:Boolean,label:{type:String,default:'Количество'},min:{type:Number,default:1},max:{type:Number,default:100}})
function update(event){const n=Number(event.target.value);if(Number.isInteger(n)&&n>=props.min&&n<=props.max)model.value=n;else event.target.value=model.value}
</script>
<template><label class="quantity"><span>{{label}}</span><input type="number" :value="model" :min="min" :max="max" :disabled="disabled" inputmode="numeric" @change="update"></label></template>
