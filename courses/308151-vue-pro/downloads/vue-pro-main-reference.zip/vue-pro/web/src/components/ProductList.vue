<script setup>
import ProductCard from './ProductCard.vue'
defineProps({products:{type:Array,default:()=>[]},busy:Boolean})
defineEmits(['add'])
</script>
<template><div class="grid"><ProductCard v-for="product in products" :key="product.id" :product="product" :busy="busy" @add="$emit('add',$event)"/></div></template>
