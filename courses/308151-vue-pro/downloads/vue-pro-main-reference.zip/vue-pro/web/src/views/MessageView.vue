<script setup>defineProps({title:String,message:String})</script><template><h1>{{title}}</h1><p>{{message}}</p><RouterLink to="/catalog">Открыть каталог</RouterLink></template>
