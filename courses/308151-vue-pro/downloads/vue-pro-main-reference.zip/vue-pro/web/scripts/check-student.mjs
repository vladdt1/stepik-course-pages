import {spawnSync} from 'node:child_process';import{mkdtempSync,readFileSync,rmSync}from'node:fs';import{tmpdir}from'node:os';import{join}from'node:path';
const dir=mkdtempSync(join(tmpdir(),'vue-student-'));const report=join(dir,'report.json');
const result=spawnSync(process.execPath,['node_modules/vitest/vitest.mjs','run','tests/student','--reporter=json','--outputFile='+report],{stdio:'inherit'});
let ok=false;try{const r=JSON.parse(readFileSync(report));ok=result.status===0&&r.numPassedTests>=27&&r.numPendingTests===0&&r.numTodoTests===0;if(!ok)console.error('Допишите все 27 проверок в tests/student. TODO/skip не считаются выполненными.')}finally{rmSync(dir,{recursive:true,force:true})}process.exit(ok?0:1);
