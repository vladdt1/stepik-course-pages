import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
export default defineConfig({base:process.env.LABS_BASE||'/',plugins:[vue()],build:{outDir:process.env.LABS_ONLY?'dist-labs':'dist',copyPublicDir:!process.env.LABS_ONLY,rollupOptions:{input:process.env.LABS_ONLY?{labs:'labs.html'}:{app:'index.html',labs:'labs.html'}}},server:{proxy:{'/api':{target:process.env.API_TARGET||'http://localhost:8082',changeOrigin:false}}},test:{environment:'jsdom',include:['tests/**/*.test.js'],restoreMocks:true}})
