import {it,expect,vi,beforeEach} from 'vitest'
import {createMemoryHistory} from 'vue-router'
const m=vi.hoisted(()=>({auth:null}));vi.mock('../src/stores/auth',()=>({useAuthStore:()=>m.auth}))
import {makeRouter} from '../src/router'
beforeEach(()=>{m.auth={authenticated:false,operator:false,ensure:vi.fn().mockResolvedValue()}})
it('25.8 каталог и параметры товара доступны гостю',async()=>{const r=makeRouter(createMemoryHistory());await r.push('/products/9');expect(r.currentRoute.value.name).toBe('product');expect(r.currentRoute.value.params.id).toBe('9')})
it('25.8 неизвестная страница открывает 404',async()=>{const r=makeRouter(createMemoryHistory());await r.push('/does-not-exist');expect(r.currentRoute.value.name).toBe('notfound')})
it('26.5 гость на защищённом маршруте получает return',async()=>{const r=makeRouter(createMemoryHistory());await r.push('/orders/12');expect(r.currentRoute.value.name).toBe('login');expect(r.currentRoute.value.query.return).toBe('/orders/12');expect(m.auth.ensure).toHaveBeenCalled()})
it('26.5 покупатель не получает кабинет оператора',async()=>{m.auth.authenticated=true;const r=makeRouter(createMemoryHistory());await r.push('/operator');expect(r.currentRoute.value.name).toBe('forbidden')})
it('26.5 оператор получает свою страницу',async()=>{m.auth.authenticated=true;m.auth.operator=true;const r=makeRouter(createMemoryHistory());await r.push('/operator');expect(r.currentRoute.value.name).toBe('operator')})
it('26.5 неизвестная сессия при отказе не открывает защищённый экран',async()=>{m.auth.ensure.mockRejectedValue({status:0});const r=makeRouter(createMemoryHistory());await r.push('/checkout');expect(r.currentRoute.value.name).toBe('login')})
