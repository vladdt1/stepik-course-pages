import{beforeEach,it,expect,vi}from'vitest'
import{loadPending,prepareCheckout,clearPending}from'../src/lib/checkout'
beforeEach(()=>{sessionStorage.clear();vi.restoreAllMocks()})
it('после потерянного ответа повторяет исходные key,body,version',()=>{vi.spyOn(crypto,'randomUUID').mockReturnValue('fixed-key-001');const first=prepareCheckout(7,{cart_version:2,address:' Main street 10 ',comment:' hi '});const second=prepareCheckout(7,{cart_version:3,address:'Other street 20',comment:'changed'});expect(second).toEqual(first);expect(second.body).toEqual({cart_version:2,address:'Main street 10',comment:'hi'});expect(crypto.randomUUID).toHaveBeenCalledTimes(1)})
it('сохраняет команду между экземплярами приложения и изолирует пользователей',()=>{const first=prepareCheckout(7,{cart_version:2,address:'Main street 10'});expect(loadPending(7)).toEqual(first);expect(loadPending(8)).toBe(null);clearPending();expect(loadPending(7)).toBe(null)})
it('повреждённое хранилище не ломает загрузку',()=>{sessionStorage.setItem('delivery.pending-checkout.v1','{bad');expect(loadPending(7)).toBe(null)})
