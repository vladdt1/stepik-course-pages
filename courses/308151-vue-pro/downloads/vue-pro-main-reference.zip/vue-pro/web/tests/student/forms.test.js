import {it,expect,vi,beforeEach,afterEach} from 'vitest'
import {mount,flushPromises} from '@vue/test-utils'
import {reactive} from 'vue'
const mocks=vi.hoisted(()=>({request:vi.fn(),login:vi.fn(),push:vi.fn(),replace:vi.fn(),route:{query:{return:'/orders/12'}}}))
vi.mock('../../src/lib/api',()=>({request:mocks.request,errorText:e=>e.message}))
vi.mock('../../src/stores/auth',()=>({useAuthStore:()=>({login:mocks.login})}))
vi.mock('vue-router',()=>({useRouter:()=>({push:mocks.push,replace:mocks.replace}),useRoute:()=>mocks.route}))
import RegisterView from '../../src/views/RegisterView.vue'
import LoginView from '../../src/views/LoginView.vue'
let wrappers=[]
function render(c){const w=mount(c,{global:{stubs:{RouterLink:{template:'<a><slot/></a>'}}}});wrappers.push(w);return w}
async function fill(w,email='student@example.test',password='StrongPass88'){await w.get('input[type=email]').setValue(email);await w.get('input[type=password]').setValue(password)}
beforeEach(()=>{vi.resetAllMocks();mocks.route.query={return:'/orders/12'}});afterEach(()=>{wrappers.forEach(w=>w.unmount());wrappers=[]})
it('26.3 регистрация отправляет поля и открывает вход после успеха',async()=>{mocks.request.mockResolvedValue({id:7});const w=render(RegisterView);await fill(w);await w.get('form').trigger('submit');await flushPromises();expect(mocks.request).toHaveBeenCalledWith('/auth/register',{method:'POST',body:{email:'student@example.test',password:'StrongPass88'}});expect(mocks.push).toHaveBeenCalledWith('/login')})
it('26.3 ошибка регистрации сохраняет введённое и не открывает вход',async()=>{mocks.request.mockRejectedValue({message:'Адрес занят',status:409});const w=render(RegisterView);await fill(w);await w.get('form').trigger('submit');await flushPromises();expect(w.get('input[type=email]').element.value).toBe('student@example.test');expect(w.get('[role=alert]').text()).toContain('Адрес занят');expect(mocks.push).not.toHaveBeenCalled();expect(w.get('button').attributes('disabled')).toBeUndefined()})
it('26.3 регистрация блокирует поля пока ждёт ответ',async()=>{let resolve;mocks.request.mockImplementation(()=>new Promise(r=>resolve=r));const w=render(RegisterView);await fill(w);await w.get('form').trigger('submit');expect(w.get('button').attributes('disabled')).toBeDefined();expect(w.get('input[type=email]').attributes('disabled')).toBeDefined();resolve({id:1});await flushPromises();expect(w.get('button').attributes('disabled')).toBeUndefined()})
it('26.3 повторное submit регистрации не запускает второй запрос',async()=>{let resolve;mocks.request.mockImplementation(()=>new Promise(r=>resolve=r));const w=render(RegisterView);await fill(w);await w.get('form').trigger('submit');await w.get('form').trigger('submit');expect(mocks.request).toHaveBeenCalledTimes(1);resolve({id:7});await flushPromises()})
