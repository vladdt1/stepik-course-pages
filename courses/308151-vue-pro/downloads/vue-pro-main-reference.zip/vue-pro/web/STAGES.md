> Vue (pro): отдельный курс. Backend в архиве готов, писать Go-код не требуется. Обозначения m23–m28 в именах файлов и командах — стабильные ID упражнений; модулям 2–7 этого курса они соответствуют по порядку.

# Маршрут самостоятельной работы

В starter 39 мест для реализации плюс 27 собственных тестов. Не начинайте с удаления TODO по всему проекту: двигайтесь по урокам. В эталоне эти места завершены. Малые упражнения practice/ и основной web/ проверяются отдельно.

## Как читать задания

«Написать» — отсутствующий код; «Проверить» — отдельный сценарий той же реализации; «Разобрать» — данная инфраструктура; «Приёмка» — наблюдаемый результат целого этапа. Готовый компонент нельзя считать написанным вами только потому, что он есть в эталоне.

## Последовательность

1. Модули 2–25: наборы practice/m23-*…m25-*. В конце 23 перенесите вычисления в web; в конце 24 соберите общие компоненты; в конце 25 разберите маршруты.
2. Модуль 5: request, каталог и страницы товара, формы регистрации/входа, guard. Готовые restore/ensure изучаются по контракту.
3. Модуль 6: сначала успешная запись корзины, затем её интерфейс и конфликты; оформление с прежним ключом; история и оператор. allowedTransitions нужен уже при отмене в 27.5.
4. Модуль 7: собственные тесты, диагностика, настоящие E2E, сборка и приёмка.

## Карта уроков и команд

Команды web выполняйте из web/. Если указан cd practice, начинайте из корня архива. На промежуточном шаге полного урока некоторые тесты ещё могут быть красными из-за следующего TODO; зелёным должен стать набор к контрольной точке.

### m23-l01 — Vue и повторение JavaScript

- `cd practice && npm test -- m23-l01 -t "активные товары"`
- `cd practice && npm test -- m23-l01 -t "подписи товаров"`

### m23-l02 — Создание и запуск Vue-проекта

- `cd practice && npm test -- m23-l02 -t "заголовок"`
- `cd practice && npm test -- m23-l02 -t "действие"`

### m23-l03 — Шаблоны и привязка данных

- `cd practice && npm test -- m23-l03 -t "текстовые данные"`
- `cd practice && npm test -- m23-l03 -t "доступный товар"`

### m23-l04 — Реактивность: ref и reactive

- `cd practice && npm test -- m23-l04 -t "количество"`
- `cd practice && npm test -- m23-l04 -t "реактивное поле"`
- `cd practice && npm test -- m23-l04 -t "сброс"`

### m23-l05 — Условия и списки

- `cd practice && npm test -- m23-l05 -t "пустота"`
- `cd practice && npm test -- m23-l05 -t "личность строки"`

### m23-l06 — События и v-model

- `cd practice && npm test -- m23-l06 -t "ввод связан"`
- `cd practice && npm test -- m23-l06 -t "submit отменяет"`
- `cd practice && npm test -- m23-l06 -t "некорректное количество"`

### m23-l07 — Вычисляемые значения: computed

- `cd practice && npm test -- m23-l07 -t "поиск пересчитывает"`
- `cd practice && npm test -- m23-l07 -t "производный итог"`
- `cd practice && npm test -- m23-l07 -t "исходный массив"`

### m23-l08 — Практика: интерактивное меню

- `cd practice && npm test -- m23-l08 -t "меню фильтруется"`
- `cd practice && npm test -- m23-l08 -t "выбор меняет"`
- `cd practice && npm test -- m23-l08 -t "пустой поиск"`
- `npm test -- tests/domain.test.js -t "каталог|количество"`

### m24-l01 — Однофайловые компоненты и стили

- `cd practice && npm test -- m24-l01`

### m24-l02 — Свойства компонентов: props

- `cd practice && npm test -- m24-l02`

### m24-l03 — События компонентов: emits

- `cd practice && npm test -- m24-l03`

### m24-l04 — Формы и v-model компонента

- `cd practice && npm test -- m24-l04`

### m24-l05 — Слоты и диалоговые окна

- `cd practice && npm test -- m24-l05`

### m24-l06 — Наблюдение за состоянием: watch

- `cd practice && npm test -- m24-l06`

### m24-l07 — Жизненный цикл компонентов

- `cd practice && npm test -- m24-l07`

### m24-l08 — Практика: компоненты каталога

- `cd practice && npm test -- m24-l08`
- `npm test -- tests/course-components.test.js -t "24.8"`

### m24-l09 — Дополнительный проект: список задач

- `cd practice && npm test -- m24-l09`

### m25-l01 — Маршруты и страницы

- `cd practice && npm test -- m25-l01`

### m25-l02 — Параметры маршрута и query

- `cd practice && npm test -- m25-l02`

### m25-l03 — Вложенные маршруты и страницы ошибок

- `cd practice && npm test -- m25-l03`

### m25-l04 — Общее состояние с Pinia

- `cd practice && npm test -- m25-l04`

### m25-l05 — Getters и actions в Pinia

- `cd practice && npm test -- m25-l05`

### m25-l06 — Переиспользуемая логика: composables

- `cd practice && npm test -- m25-l06`

### m25-l07 — Практика: структура приложения доставки

- `cd practice && npm test -- m25-l07`

### m25-l08 — Дополнительный проект: список покупок

- `cd practice && npm test -- m25-l08`
- `npm test -- tests/course-router.test.js -t "25.8"`

### m26-l01 — HTTP-клиент на fetch

- `npm test -- tests/api.test.js`
- `npm test -- tests/course-components.test.js tests/course-catalog-cart.test.js -t "26.1"`

### m26-l02 — Загрузка каталога и состояния запроса

- `npm test -- tests/course-catalog-cart.test.js -t "26.2|25.2"`
- `npm test -- tests/stores.test.js -t "старый ответ"`

### m26-l03 — Регистрация и ошибки формы

- `npm test -- tests/course-auth-pages.test.js -t "26.3"`

### m26-l04 — Вход, cookie и CORS

- `npm test -- tests/course-auth-pages.test.js -t "26.4"`
- `npm test -- tests/stores.test.js -t "очищает корзину"`

### m26-l05 — Восстановление сессии

- `npm test -- tests/stores.test.js -t "восстанавливает сессию"`

### m26-l06 — Защищённые маршруты и роли

- `npm test -- tests/course-router.test.js`

### m26-l07 — Практика: приложение с настоящим пользователем

- `npm test -- tests/api.test.js tests/course-auth-pages.test.js tests/course-router.test.js`
- `npm test -- tests/course-catalog-cart.test.js -t "26.|25.2"`

### m27-l01 — Каталог и страница товара

- `npm test -- tests/course-catalog-cart.test.js -t "27.1"`

### m27-l02 — Серверная корзина

- `npm test -- tests/course-catalog-cart.test.js -t "27.2"`

### m27-l03 — Изменение корзины и конфликт версии

- `npm test -- tests/course-catalog-cart.test.js -t "27.3"`
- `npm test -- tests/stores.test.js -t "409|запоздалая корзина"`

### m27-l04 — Оформление заказа без дублей

- `npm test -- tests/checkout.test.js tests/course-checkout-page.test.js`

### m27-l05 — История заказов и отмена

- `npm test -- tests/course-orders.test.js -t "27.5"`

### m27-l06 — Кабинет оператора

- `npm test -- tests/course-orders.test.js -t "27.6"`
- `npm test -- tests/domain.test.js -t "допустимые действия"`

### m27-l07 — Практика: полный пользовательский путь

- `npm run test:course`
- `npm run build`

### m28-l01 — Отладка Vue и запросов

- `npm run test:course`

### m28-l02 — Тесты логики и хранилищ

- `npm test -- tests/student/domain.test.js tests/student/stores.test.js`

### m28-l03 — Тесты компонентов

- `npm run test:student`

### m28-l04 — Сквозные тесты приложения

- `npm run test:e2e`

### m28-l05 — Сборка Vue и запуск в Docker

- `npm run build`

### m28-l06 — Итоговый проект: Vue, Go и PostgreSQL

- `npm run test:course`
- `npm run test:student`
- `npm run build`

## Итог

`npm run test:course` проверяет готовым набором рабочую реализацию. `npm run test:student` проверяет завершённость ваших 27 тестов. `npm run build` проверяет сборку. Ни одна команда не подменяет приёмку настоящего Go/PostgreSQL приложения. Подробные контракты — PRACTICE.md.
