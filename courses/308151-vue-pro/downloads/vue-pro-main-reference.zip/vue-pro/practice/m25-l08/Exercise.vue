<script setup>
import {useShopping} from './store.js'
const store=useShopping()
</script>
<template><main><header>Осталось: {{store.remaining}}</header><RouterLink to="/">Покупки</RouterLink><RouterView/></main></template>
