import { mount, flushPromises } from '@vue/test-utils'
import { expect, test, afterEach, vi } from 'vitest'
import Exercise from './Exercise.vue'
const mounted=[]
function render(props={},options={}) { const w=mount(Exercise,{props,...options});mounted.push(w);return w }
function button(w,label) {const b=w.findAll('button').find(x=>x.text()===label);if(!b)throw new Error('Нет кнопки '+label);return b}
afterEach(()=>{ mounted.splice(0).forEach(w=>w.unmount()); document.body.innerHTML='';vi.useRealTimers() })
import {createPinia} from 'pinia'
import {createRouter,createMemoryHistory} from 'vue-router'
import {routes} from './routes.js'
async function app(path='/'){const router=createRouter({history:createMemoryHistory(),routes});await router.push(path);const w=render({}, {global:{plugins:[createPinia(),router]}});await router.isReady();await flushPromises();return {w,router}}
test('отметка общая для списка и детали',async()=>{const {w,router}=await app();await w.get('input[aria-label="Куплено Чай"]').setValue(true);expect(w.get('header').text()).toBe('Осталось: 1');await router.push('/items/1');expect(w.get('p').text()).toContain('Куплено');await button(w,'Сменить отметку').trigger('click');expect(w.get('header').text()).toBe('Осталось: 2')})
test('фильтр категории хранится в URL',async()=>{const {w,router}=await app('/?category=Еда');expect(w.findAll('li')).toHaveLength(1);expect(w.get('li a').text()).toBe('Хлеб');await w.get('[aria-label=Категория]').setValue('Напитки');await flushPromises();expect(router.currentRoute.value.query.category).toBe('Напитки');expect(w.get('li a').text()).toBe('Чай')})
test('тема сохраняется отдельно от предметных данных',async()=>{localStorage.clear();const {w}=await app();await w.get('[aria-label=Тема]').setValue('dark');await w.get('input[type=checkbox]').setValue(true);expect(localStorage.getItem('shopping-theme')).toBe('dark');expect(localStorage.length).toBe(1)})
test('прямая ссылка и неизвестный ID',async()=>{const {w,router}=await app('/items/2');expect(w.get('h1').text()).toBe('Хлеб');await router.push('/items/99');expect(w.get('h1').text()).toBe('Позиция не найдена')})
