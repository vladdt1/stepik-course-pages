import {defineStore} from 'pinia'
export const useShopping=defineStore('shopping',{state:()=>({items:[{id:1,name:'Чай',category:'Напитки',bought:false},{id:2,name:'Хлеб',category:'Еда',bought:false}]}),getters:{remaining:s=>s.items.filter(p=>!p.bought).length},actions:{toggle(id){const p=this.items.find(x=>x.id===id);if(p)p.bought=!p.bought}}})
