import { mount, flushPromises } from '@vue/test-utils'
import { expect, test, afterEach, vi } from 'vitest'
import Exercise from './Exercise.vue'
const mounted=[]
function render(props={},options={}) { const w=mount(Exercise,{props,...options});mounted.push(w);return w }
function button(w,label) {const b=w.findAll('button').find(x=>x.text()===label);if(!b)throw new Error('Нет кнопки '+label);return b}
afterEach(()=>{ mounted.splice(0).forEach(w=>w.unmount()); document.body.innerHTML='';vi.useRealTimers() })
test('категория сбрасывает позицию',async()=>{const w=render();await w.get('[aria-label=Категория]').setValue('food');expect(w.get('input').element.value).toBe('')})
test('вид сохраняется',async()=>{localStorage.clear();const w=render();await w.get('[aria-label=Вид]').setValue('list');expect(localStorage.getItem('catalog-view')).toBe('list')})
test('предметные данные не записываются',async()=>{localStorage.clear();const w=render();await w.get('input').setValue('9');expect(localStorage.length).toBe(0)})
