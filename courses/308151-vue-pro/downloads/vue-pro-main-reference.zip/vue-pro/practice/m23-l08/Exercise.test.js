import { mount, flushPromises } from '@vue/test-utils'
import { expect, test, afterEach, vi } from 'vitest'
import Exercise from './Exercise.vue'
const mounted=[]
function render(props={},options={}) { const w=mount(Exercise,{props,...options});mounted.push(w);return w }
function button(w,label) {const b=w.findAll('button').find(x=>x.text()===label);if(!b)throw new Error('Нет кнопки '+label);return b}
afterEach(()=>{ mounted.splice(0).forEach(w=>w.unmount()); document.body.innerHTML='';vi.useRealTimers() })
test('меню фильтруется без потери источника',async()=>{const w=render();await w.get('input').setValue('чай');expect(w.findAll('li')).toHaveLength(1);await w.get('input').setValue('');expect(w.findAll('li')).toHaveLength(2)})
test('выбор меняет предварительный итог',async()=>{const w=render();await button(w,'Добавить Чай').trigger('click');await button(w,'Добавить Чай').trigger('click');expect(w.get('output').text()).toBe('18000')})
test('пустой поиск не удаляет выбранный товар',async()=>{const w=render();await button(w,'Добавить Суп').trigger('click');await w.get('input').setValue('нет');expect(w.text()).toContain('Ничего не найдено');expect(w.get('output').text()).toBe('35000')})
