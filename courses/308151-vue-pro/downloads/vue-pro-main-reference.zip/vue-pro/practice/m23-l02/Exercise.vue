<script setup>
import {title,description} from './labels.js'
</script>
<template><main><h1>{{title}}</h1><p>{{description}}</p><button type="button">Начать</button></main></template>
