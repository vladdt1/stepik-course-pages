import { mount, flushPromises } from '@vue/test-utils'
import { expect, test, afterEach, vi } from 'vitest'
import Exercise from './Exercise.vue'
const mounted=[]
function render(props={},options={}) { const w=mount(Exercise,{props,...options});mounted.push(w);return w }
function button(w,label) {const b=w.findAll('button').find(x=>x.text()===label);if(!b)throw new Error('Нет кнопки '+label);return b}
afterEach(()=>{ mounted.splice(0).forEach(w=>w.unmount()); document.body.innerHTML='';vi.useRealTimers() })
test('заголовок первого экрана',()=>{expect(render().get('h1').text()).toBe('Меню доставки')})
test('описание из модуля',()=>{expect(render().get('p').text()).toBe('Выберите товары для заказа')})
test('понятное действие без неявной отправки формы',()=>{const w=render();expect(button(w,'Начать').attributes('type')).toBe('button')})
