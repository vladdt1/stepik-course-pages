export const title='Меню доставки'
export const description='Выберите товары для заказа'
