import { mount, flushPromises } from '@vue/test-utils'
import { expect, test, afterEach, vi } from 'vitest'
import Exercise from './Exercise.vue'
const mounted=[]
function render(props={},options={}) { const w=mount(Exercise,{props,...options});mounted.push(w);return w }
function button(w,label) {const b=w.findAll('button').find(x=>x.text()===label);if(!b)throw new Error('Нет кнопки '+label);return b}
afterEach(()=>{ mounted.splice(0).forEach(w=>w.unmount()); document.body.innerHTML='';vi.useRealTimers() })
import {createRouter,createMemoryHistory} from 'vue-router'
import {routes} from './routes.js'
async function page(path='/'){const router=createRouter({history:createMemoryHistory(),routes});await router.push(path);await router.isReady();const w=render({}, {global:{plugins:[router]}});return {w,router}}
test('прямой маршрут',async()=>{const {w}=await page('/cart');expect(w.get('h1').text()).toBe('Корзина')})
test('навигация и активная ссылка',async()=>{const {w}=await page();await w.findAll('a')[2].trigger('click');await flushPromises();expect(w.get('h1').text()).toBe('Заказы');expect(w.findAll('a')[2].classes()).toContain('router-link-active')})
test('история маршрутов',async()=>{const {w,router}=await page();await router.push('/cart');await router.push('/orders');router.back();await flushPromises();expect(w.get('h1').text()).toBe('Корзина')})
