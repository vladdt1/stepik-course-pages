<script setup>

</script>
<template><main><nav><RouterLink to="/">Каталог</RouterLink> <RouterLink to="/cart">Корзина</RouterLink> <RouterLink to="/orders">Заказы</RouterLink></nav><RouterView/></main></template>
