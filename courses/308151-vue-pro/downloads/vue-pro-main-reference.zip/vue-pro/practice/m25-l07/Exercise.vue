<script setup>
import {useCart} from './store.js'
const cart=useCart()
</script>
<template><main><header>Выбрано: {{cart.count}}</header><RouterLink to="/">Каталог</RouterLink> <RouterLink to="/cart">Корзина</RouterLink><RouterView/></main></template>
