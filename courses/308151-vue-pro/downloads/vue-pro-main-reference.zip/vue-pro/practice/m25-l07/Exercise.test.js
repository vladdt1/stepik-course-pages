import { mount, flushPromises } from '@vue/test-utils'
import { expect, test, afterEach, vi } from 'vitest'
import Exercise from './Exercise.vue'
const mounted=[]
function render(props={},options={}) { const w=mount(Exercise,{props,...options});mounted.push(w);return w }
function button(w,label) {const b=w.findAll('button').find(x=>x.text()===label);if(!b)throw new Error('Нет кнопки '+label);return b}
afterEach(()=>{ mounted.splice(0).forEach(w=>w.unmount()); document.body.innerHTML='';vi.useRealTimers() })
import {createPinia} from 'pinia'
import {createRouter,createMemoryHistory} from 'vue-router'
import {routes} from './routes.js'
async function app(path='/'){const router=createRouter({history:createMemoryHistory(),routes});await router.push(path);const w=render({}, {global:{plugins:[createPinia(),router]}});await router.isReady();await flushPromises();return {w,router}}
test('общее состояние переживает переход',async()=>{const {w,router}=await app();await button(w,'Добавить').trigger('click');await router.push('/cart');expect(w.get('header').text()).toBe('Выбрано: 1');expect(w.get('output').text()).toBe('1')})
test('позиция по ID без копии состояния',async()=>{const {w,router}=await app();await button(w,'Добавить').trigger('click');await router.push('/products/1');expect(w.get('h1').text()).toBe('Чай');await router.push('/products/9');expect(w.get('h1').text()).toBe('Позиция не найдена')})
test('пустой и неизвестный маршрут',async()=>{const {w,router}=await app('/cart');expect(w.text()).toContain('Пусто');await router.push('/absent');expect(w.get('h1').text()).toBe('Страница не найдена')})
