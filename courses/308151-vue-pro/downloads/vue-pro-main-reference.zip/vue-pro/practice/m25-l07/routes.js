import {computed} from 'vue'
import {useRoute} from 'vue-router'
import {useCart} from './store.js'
const Catalog={setup(){return {cart:useCart()}},template:`<main><h1>Каталог</h1><RouterLink to="/products/1">Чай</RouterLink><button @click="cart.add({id:1,name:'Чай',price_cents:9000})">Добавить</button></main>`}
const Detail={setup(){const r=useRoute(),cart=useCart();return {item:computed(()=>cart.items.find(p=>String(p.id)===r.params.id)),cart}},template:'<main><h1>{{item ? item.name : "Позиция не найдена"}}</h1><p v-if="item">{{item.quantity}}</p></main>'}
const Cart={setup(){return {cart:useCart()}},template:'<main><h1>Корзина</h1><output>{{cart.count}}</output><p v-if="!cart.items.length">Пусто</p></main>'}
export const routes=[{path:'/',component:Catalog},{path:'/products/:id',component:Detail},{path:'/cart',component:Cart},{path:'/orders',component:{template:'<h1>Заказы</h1>'}},{path:'/:pathMatch(.*)*',component:{template:'<h1>Страница не найдена</h1>'}}]
