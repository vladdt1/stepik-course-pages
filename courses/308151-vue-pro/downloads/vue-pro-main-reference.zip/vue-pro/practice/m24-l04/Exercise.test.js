import { mount, flushPromises } from '@vue/test-utils'
import { expect, test, afterEach, vi } from 'vitest'
import Exercise from './Exercise.vue'
const mounted=[]
function render(props={},options={}) { const w=mount(Exercise,{props,...options});mounted.push(w);return w }
function button(w,label) {const b=w.findAll('button').find(x=>x.text()===label);if(!b)throw new Error('Нет кнопки '+label);return b}
afterEach(()=>{ mounted.splice(0).forEach(w=>w.unmount()); document.body.innerHTML='';vi.useRealTimers() })
test('управляемый ввод',async()=>{const w=render();await w.get('input').setValue('Дом');expect(w.emitted('update:modelValue')).toEqual([['Дом']])})
test('пустое значение не отправляется',async()=>{const save=vi.fn();const w=render({save});await w.get('form').trigger('submit');expect(save).not.toHaveBeenCalled();expect(w.get('[role=alert]').text()).toBe('Введите адрес')})
test('ошибка не стирает ввод и снимает pending',async()=>{const w=render({modelValue:'Дом',save:async()=>{throw Error()}});await w.get('form').trigger('submit');await flushPromises();expect(w.get('input').element.value).toBe('Дом');expect(w.get('[role=alert]').text()).toBe('Не удалось сохранить');expect(w.get('button').element.disabled).toBe(false)})
