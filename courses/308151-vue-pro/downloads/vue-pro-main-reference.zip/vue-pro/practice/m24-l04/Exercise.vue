<script setup>
import {ref} from 'vue'
const props=defineProps({modelValue:{type:String,default:''},save:{type:Function,default:async()=>{}}})
const emit=defineEmits(['update:modelValue'])
const error=ref(''),pending=ref(false)
async function submit(){if(!props.modelValue.trim()){error.value='Введите адрес';return}pending.value=true;error.value='';try{await props.save(props.modelValue)}catch{error.value='Не удалось сохранить'}finally{pending.value=false}}
</script>
<template><form @submit.prevent="submit"><label for="address">Адрес</label><input id="address" :value="modelValue" @input="emit('update:modelValue',$event.target.value)" :aria-invalid="Boolean(error)"><p role="alert">{{error}}</p><button :disabled="pending">Сохранить</button></form></template>
