<script setup>
import {useProductFilters,useDialog} from './composables.js'
const {query,visible}=useProductFilters([{id:1,name:'Суп'},{id:2,name:'Чай'}]);const dialog=useDialog()
</script>
<template><main><input v-model="query" aria-label="Поиск"><ul><li v-for="p in visible" :key="p.id">{{p.name}}</li></ul><button type="button" @click="dialog.open.value=true">Открыть</button><section v-if="dialog.open.value" role="dialog"><button type="button" @click="dialog.close">Закрыть</button></section></main></template>
