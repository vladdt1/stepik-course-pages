import { mount, flushPromises } from '@vue/test-utils'
import { expect, test, afterEach, vi } from 'vitest'
import Exercise from './Exercise.vue'
const mounted=[]
function render(props={},options={}) { const w=mount(Exercise,{props,...options});mounted.push(w);return w }
function button(w,label) {const b=w.findAll('button').find(x=>x.text()===label);if(!b)throw new Error('Нет кнопки '+label);return b}
afterEach(()=>{ mounted.splice(0).forEach(w=>w.unmount()); document.body.innerHTML='';vi.useRealTimers() })
import {useProductFilters} from './composables.js'
test('фильтр реактивен',async()=>{const w=render();await w.get('input').setValue('ЧА');expect(w.findAll('li').map(x=>x.text())).toEqual(['Чай'])})
test('экземпляры фильтра независимы',()=>{const a=useProductFilters([{id:1,name:'Суп'}]),b=useProductFilters([{id:2,name:'Чай'}]);a.query.value='нет';expect(a.visible.value).toHaveLength(0);expect(b.visible.value).toHaveLength(1)})
test('диалог закрывается Escape',async()=>{const w=render();await button(w,'Открыть').trigger('click');window.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape'}));await w.vm.$nextTick();expect(w.find('[role=dialog]').exists()).toBe(false)})
