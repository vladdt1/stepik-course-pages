import {ref,computed,onMounted,onUnmounted} from 'vue'
export function useProductFilters(products){const query=ref('');return {query,visible:computed(()=>products.filter(p=>p.name.toLowerCase().includes(query.value.toLowerCase())))}}
export function useDialog(){const open=ref(false),close=()=>open.value=false;const key=e=>{if(e.key==='Escape')close()};onMounted(()=>window.addEventListener('keydown',key));onUnmounted(()=>window.removeEventListener('keydown',key));return {open,close}}
