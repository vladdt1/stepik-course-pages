<script setup>
import {ref,computed} from 'vue'
const props=defineProps({products:{type:Array,default:()=>[]}})
const query=ref(''),quantity=ref(1)
const visible=computed(()=>props.products.filter(p=>p.name.toLowerCase().includes(query.value.toLowerCase())).slice().sort((a,b)=>a.name.localeCompare(b.name,'ru')))
const subtotal=computed(()=>visible.value.reduce((sum,p)=>sum+p.price_cents*quantity.value,0))
</script>
<template><main><input v-model="query" aria-label="Поиск"><input v-model.number="quantity" type="number" aria-label="Количество"><ul><li v-for="p in visible" :key="p.id">{{p.name}}</li></ul><output>{{subtotal}}</output></main></template>
