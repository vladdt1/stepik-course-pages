import { mount, flushPromises } from '@vue/test-utils'
import { expect, test, afterEach, vi } from 'vitest'
import Exercise from './Exercise.vue'
const mounted=[]
function render(props={},options={}) { const w=mount(Exercise,{props,...options});mounted.push(w);return w }
function button(w,label) {const b=w.findAll('button').find(x=>x.text()===label);if(!b)throw new Error('Нет кнопки '+label);return b}
afterEach(()=>{ mounted.splice(0).forEach(w=>w.unmount()); document.body.innerHTML='';vi.useRealTimers() })
const products=[{id:2,name:'Чай',price_cents:9000},{id:1,name:'Суп',price_cents:35000}]
test('поиск пересчитывает видимый список',async()=>{const w=render({products});await w.get('input[aria-label="Поиск"]').setValue('СУ');expect(w.findAll('li').map(x=>x.text())).toEqual(['Суп'])})
test('производный итог реагирует на зависимости',async()=>{const w=render({products});await w.get('input[aria-label="Поиск"]').setValue('чай');await w.get('input[aria-label="Количество"]').setValue('2');expect(w.get('output').text()).toBe('18000')})
test('сортировка и фильтр не меняют исходный массив',async()=>{const input=structuredClone(products),before=structuredClone(input);const w=render({products:input});await w.get('input[aria-label="Поиск"]').setValue('нет');expect(input).toEqual(before);expect(w.findAll('li')).toHaveLength(0);expect(w.get('output').text()).toBe('0')})
