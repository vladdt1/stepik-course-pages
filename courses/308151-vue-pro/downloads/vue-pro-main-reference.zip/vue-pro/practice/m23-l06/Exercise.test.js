import { mount, flushPromises } from '@vue/test-utils'
import { expect, test, afterEach, vi } from 'vitest'
import Exercise from './Exercise.vue'
const mounted=[]
function render(props={},options={}) { const w=mount(Exercise,{props,...options});mounted.push(w);return w }
function button(w,label) {const b=w.findAll('button').find(x=>x.text()===label);if(!b)throw new Error('Нет кнопки '+label);return b}
afterEach(()=>{ mounted.splice(0).forEach(w=>w.unmount()); document.body.innerHTML='';vi.useRealTimers() })
test('ввод связан с моделью и trim',async()=>{const w=render();await w.get('input[aria-label="Поиск"]').setValue('  чай  ');expect(w.get('output').text()).toBe('чай')})
test('submit отменяет стандартное действие',async()=>{const w=render();const e=new Event('submit',{bubbles:true,cancelable:true});w.get('form').element.dispatchEvent(e);await w.vm.$nextTick();expect(e.defaultPrevented).toBe(true);expect(w.get('[data-testid=submitted]').text()).toBe('1')})
test('некорректное количество не принимается',async()=>{const w=render();await w.get('input[aria-label="Количество"]').setValue('0');await w.get('form').trigger('submit');expect(w.get('[data-testid=submitted]').text()).toBe('0');expect(w.get('[role=status]').text()).toBe('Проверьте количество')})
