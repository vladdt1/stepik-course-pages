<script setup>
import {ref} from 'vue'
const query=ref(''),quantity=ref(1),submitted=ref(0),message=ref('')
function submit(){if(!Number.isInteger(quantity.value)||quantity.value<1||quantity.value>100){message.value='Проверьте количество';return}submitted.value++;message.value='Принято'}
</script>
<template><form @submit.prevent="submit"><input v-model.trim="query" aria-label="Поиск"><input v-model.number="quantity" type="number" aria-label="Количество"><button type="submit">Проверить</button><output>{{query}}</output><p data-testid="submitted">{{submitted}}</p><p role="status">{{message}}</p></form></template>
