import { mount, flushPromises } from '@vue/test-utils'
import { expect, test, afterEach, vi } from 'vitest'
import Exercise from './Exercise.vue'
const mounted=[]
function render(props={},options={}) { const w=mount(Exercise,{props,...options});mounted.push(w);return w }
function button(w,label) {const b=w.findAll('button').find(x=>x.text()===label);if(!b)throw new Error('Нет кнопки '+label);return b}
afterEach(()=>{ mounted.splice(0).forEach(w=>w.unmount()); document.body.innerHTML='';vi.useRealTimers() })
import {createPinia} from 'pinia'
import {useCart} from './store.js'
function shop(){const pinia=createPinia();return {w:render({}, {global:{plugins:[pinia]}}),store:useCart(pinia)}}
test('общий счётчик и итог',async()=>{const {w}=shop();await button(w,'Добавить').trigger('click');await button(w,'Добавить').trigger('click');expect(w.get('header').text()).toBe('Единиц: 2');expect(w.get('output').text()).toBe('18000')})
test('изменение и удаление через actions',()=>{const {store}=shop();store.add({id:1,price_cents:9000});store.setQuantity(1,3);expect(store.count).toBe(3);store.setQuantity(1,0);expect(store.count).toBe(3);store.remove(1);expect(store.subtotal).toBe(0)})
test('изоляция экземпляров и входных данных',()=>{const {store}=shop();const p={id:1,price_cents:9000};store.add(p);store.setQuantity(1,5);expect(p.quantity).toBeUndefined();expect(useCart(createPinia()).count).toBe(0)})
