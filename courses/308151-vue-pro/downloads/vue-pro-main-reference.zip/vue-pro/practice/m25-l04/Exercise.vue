<script setup>
import {useCart} from './store.js'
const cart=useCart()
</script>
<template><main><header>Единиц: {{cart.count}}</header><button type="button" @click="cart.add({id:1,name:'Чай',price_cents:9000})">Добавить</button><output>{{cart.subtotal}}</output><ul><li v-for="p in cart.items" :key="p.id">{{p.name}}: {{p.quantity}}</li></ul></main></template>
