export function activeProducts(products) {
  return products.filter(product=>product.active).map(product=>({...product}))
}
export function productLabels(products) {
  return products.map(product=>`${product.name}: ${product.price_cents} коп.`)
}
