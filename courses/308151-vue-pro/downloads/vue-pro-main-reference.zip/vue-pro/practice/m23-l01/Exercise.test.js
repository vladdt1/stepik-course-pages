import {test,expect} from 'vitest'
import {activeProducts,productLabels} from './exercise.js'
test('активные товары: отбор без изменения входа',()=>{const rows=[{id:1,name:'Суп',active:true},{id:2,name:'Чай',active:false}];const before=structuredClone(rows);expect(activeProducts(rows).map(x=>x.id)).toEqual([1]);expect(rows).toEqual(before)})
test('подписи товаров: порядок и цена в копейках',()=>{expect(productLabels([{name:'Чай',price_cents:9000},{name:'Суп',price_cents:35000}])).toEqual(['Чай: 9000 коп.','Суп: 35000 коп.'])})
test('пустота и независимые верхние объекты',()=>{expect(activeProducts([])).toEqual([]);const input=[{id:1,active:true}];const output=activeProducts(input);output[0].id=9;expect(input[0].id).toBe(1);expect(productLabels([])).toEqual([])})
