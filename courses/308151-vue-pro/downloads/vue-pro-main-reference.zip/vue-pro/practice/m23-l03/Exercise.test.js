import { mount, flushPromises } from '@vue/test-utils'
import { expect, test, afterEach, vi } from 'vitest'
import Exercise from './Exercise.vue'
const mounted=[]
function render(props={},options={}) { const w=mount(Exercise,{props,...options});mounted.push(w);return w }
function button(w,label) {const b=w.findAll('button').find(x=>x.text()===label);if(!b)throw new Error('Нет кнопки '+label);return b}
afterEach(()=>{ mounted.splice(0).forEach(w=>w.unmount()); document.body.innerHTML='';vi.useRealTimers() })
test('текстовые данные карточки',()=>{const w=render({product:{name:'Суп',price_cents:35000,stock:2}});expect(w.get('h2').text()).toBe('Суп');expect(w.get('p').text()).toBe('35000 коп.')})
test('недоступный товар выключает кнопку',()=>{const w=render({product:{name:'Чай',price_cents:9000,stock:0}});expect(button(w,'Добавить').element.disabled).toBe(true);expect(w.get('article').classes()).toContain('unavailable')})
test('доступный товар не остаётся выключенным',async()=>{const w=render({product:{name:'Чай',price_cents:9000,stock:0}});await w.setProps({product:{name:'Чай',price_cents:9000,stock:3}});expect(button(w,'Добавить').element.disabled).toBe(false);expect(w.get('article').classes()).not.toContain('unavailable')})
