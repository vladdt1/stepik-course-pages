<script setup>
const props=defineProps({product:{type:Object,required:true}})
</script>
<template><article :class="{unavailable:props.product.stock===0}"><h2>{{props.product.name}}</h2><p>{{props.product.price_cents}} коп.</p><button type="button" :disabled="props.product.stock===0">Добавить</button></article></template>
