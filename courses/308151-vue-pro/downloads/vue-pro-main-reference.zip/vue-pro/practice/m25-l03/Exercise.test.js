import { mount, flushPromises } from '@vue/test-utils'
import { expect, test, afterEach, vi } from 'vitest'
import Exercise from './Exercise.vue'
const mounted=[]
function render(props={},options={}) { const w=mount(Exercise,{props,...options});mounted.push(w);return w }
function button(w,label) {const b=w.findAll('button').find(x=>x.text()===label);if(!b)throw new Error('Нет кнопки '+label);return b}
afterEach(()=>{ mounted.splice(0).forEach(w=>w.unmount()); document.body.innerHTML='';vi.useRealTimers() })
import {createRouter,createMemoryHistory} from 'vue-router'
import {routes} from './routes.js'
async function page(path='/'){const router=createRouter({history:createMemoryHistory(),routes});await router.push(path);await router.isReady();const w=render({}, {global:{plugins:[router]}});return {w,router}}
test('вложенная страница с оболочкой',async()=>{const {w}=await page('/account/orders');expect(w.get('header').text()).toBe('Кабинет');expect(w.get('h1').text()).toBe('Мои заказы')})
test('оболочка сохраняется между дочерними страницами',async()=>{const {w,router}=await page('/account/orders');const header=w.get('header').element;await router.push('/account/profile');expect(w.get('header').element).toBe(header);expect(w.get('h1').text()).toBe('Профиль')})
test('неизвестный адрес и возврат',async()=>{const {w}=await page('/missing');expect(w.get('h1').text()).toBe('Страница не найдена');await w.findAll('a').find(a=>a.text()==='В каталог').trigger('click');await flushPromises();expect(w.get('h1').text()).toBe('Каталог')})
