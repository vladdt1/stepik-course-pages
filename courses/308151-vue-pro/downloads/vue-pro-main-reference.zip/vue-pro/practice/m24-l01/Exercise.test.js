import { mount, flushPromises } from '@vue/test-utils'
import { expect, test, afterEach, vi } from 'vitest'
import Exercise from './Exercise.vue'
const mounted=[]
function render(props={},options={}) { const w=mount(Exercise,{props,...options});mounted.push(w);return w }
function button(w,label) {const b=w.findAll('button').find(x=>x.text()===label);if(!b)throw new Error('Нет кнопки '+label);return b}
afterEach(()=>{ mounted.splice(0).forEach(w=>w.unmount()); document.body.innerHTML='';vi.useRealTimers() })
test('две карточки',()=>expect(render().findAll('article')).toHaveLength(2))
test('названия из отдельных компонентов',()=>expect(render().findAll('h2').map(x=>x.text())).toEqual(['Суп','Чай']))
test('основа кнопок',()=>expect(render().findAll('button').every(x=>x.classes().includes('base-button'))).toBe(true))
