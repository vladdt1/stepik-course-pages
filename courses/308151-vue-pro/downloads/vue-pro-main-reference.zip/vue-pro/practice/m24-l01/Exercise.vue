<script setup>
import ProductCard from './ProductCard.vue'
</script>
<template><main><h1>Доставка</h1><section class="grid"><ProductCard title="Суп"/><ProductCard title="Чай"/></section></main></template>
