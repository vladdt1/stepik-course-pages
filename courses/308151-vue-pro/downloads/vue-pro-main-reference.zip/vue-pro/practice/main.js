import {createApp,h,ref} from 'vue'
import {createPinia} from 'pinia'
import {createRouter,createWebHashHistory} from 'vue-router'
import './style.css'
const components=import.meta.glob('./m*/Exercise.vue')
const query=new URLSearchParams(location.search),key=query.get('lesson')||'m23-l01'
const data={product:{id:1,name:'Суп',price_cents:35000,stock:3},products:[{id:1,name:'Суп',price_cents:35000,stock:3},{id:2,name:'Чай',price_cents:9000,stock:2}],id:1}
const loader=components[`./${key}/Exercise.vue`]
let component
if(loader)component=(await loader()).default
else {const api=await import('./m23-l01/exercise.js');component={setup(){const input=ref(JSON.stringify([{name:'Суп',active:true,price_cents:35000},{name:'Чай',active:false,price_cents:9000}])),result=ref('');function run(){try{const rows=JSON.parse(input.value);result.value=JSON.stringify({active:api.activeProducts(rows),labels:api.productLabels(rows)},null,2)}catch(e){result.value=e.message}}return()=>h('main',[h('label',['Товары JSON',h('textarea',{value:input.value,onInput:e=>input.value=e.target.value})]),h('button',{onClick:run},'Выполнить'),h('pre',result.value)])}}}
const model=ref('');data['onUpdate:modelValue']=value=>model.value=value
const app=createApp({render:()=>h('div',[h('nav',Object.keys(import.meta.glob('./m*/README.md')).map(path=>{const lesson=path.split('/')[1];return h('a',{href:'?lesson='+lesson},lesson+' ')})),h(component,{...data,modelValue:model.value})])})
app.use(createPinia())
const routeModules=import.meta.glob('./m*/routes.js');const routeLoader=routeModules[`./${key}/routes.js`]
if(routeLoader){const {routes}=await routeLoader();const router=createRouter({history:createWebHashHistory(),routes});app.use(router);await router.isReady()}
app.mount('#app')
