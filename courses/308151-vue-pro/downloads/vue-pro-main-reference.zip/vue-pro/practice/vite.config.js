import {defineConfig} from 'vite'
import vue from '@vitejs/plugin-vue'
export default defineConfig({plugins:[vue()],build:{target:'esnext'},resolve:{alias:{vue:'vue/dist/vue.esm-bundler.js'}},test:{environment:'jsdom',include:['m*/**/*.test.js'],maxWorkers:2}})
