<script setup>
import {ref,onMounted,onUnmounted} from 'vue'
const input=ref(null),ticks=ref(0),events=ref(0);let timer
const resize=()=>events.value++
onMounted(()=>{input.value.focus();timer=setInterval(()=>ticks.value++,1000);window.addEventListener('resize',resize)})
onUnmounted(()=>{clearInterval(timer);window.removeEventListener('resize',resize)})
</script>
<template><main><input ref="input" aria-label="Название"><output>{{ticks}}</output><p>{{events}}</p></main></template>
