import { mount, flushPromises } from '@vue/test-utils'
import { expect, test, afterEach, vi } from 'vitest'
import Exercise from './Exercise.vue'
const mounted=[]
function render(props={},options={}) { const w=mount(Exercise,{props,...options});mounted.push(w);return w }
function button(w,label) {const b=w.findAll('button').find(x=>x.text()===label);if(!b)throw new Error('Нет кнопки '+label);return b}
afterEach(()=>{ mounted.splice(0).forEach(w=>w.unmount()); document.body.innerHTML='';vi.useRealTimers() })
test('фокус после монтирования',()=>{const w=render({}, {attachTo:document.body});expect(document.activeElement).toBe(w.get('input').element)})
test('таймер тикает и очищается',async()=>{vi.useFakeTimers();const w=render();vi.advanceTimersByTime(2000);await w.vm.$nextTick();expect(w.get('output').text()).toBe('2');w.unmount();expect(vi.getTimerCount()).toBe(0)})
test('обработчик очищается',()=>{const remove=vi.spyOn(window,'removeEventListener');const w=render();w.unmount();expect(remove).toHaveBeenCalledWith('resize',expect.any(Function));remove.mockRestore()})
