import { mount, flushPromises } from '@vue/test-utils'
import { expect, test, afterEach, vi } from 'vitest'
import Exercise from './Exercise.vue'
const mounted=[]
function render(props={},options={}) { const w=mount(Exercise,{props,...options});mounted.push(w);return w }
function button(w,label) {const b=w.findAll('button').find(x=>x.text()===label);if(!b)throw new Error('Нет кнопки '+label);return b}
afterEach(()=>{ mounted.splice(0).forEach(w=>w.unmount()); document.body.innerHTML='';vi.useRealTimers() })
const product={id:1,name:'Суп',price_cents:35000,stock:2}
test('полный вид по умолчанию',()=>expect(render({product}).get('p').text()).toBe('35000 коп.'))
test('компактный вид',()=>{const w=render({product,compact:true});expect(w.find('p').exists()).toBe(false);expect(w.get('article').classes()).toContain('compact')})
test('вход не изменяется и недоступность учитывается',()=>{const p=Object.freeze({...product,stock:0});const w=render({product:p});expect(w.get('button').element.disabled).toBe(true);expect(p.name).toBe('Суп')})
