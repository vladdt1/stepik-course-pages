<script setup>
const props=defineProps({product:{type:Object,required:true},compact:{type:Boolean,default:false}})
</script>
<template><article :class="{compact}"><h2>{{product.name}}</h2><p v-if="!compact">{{product.price_cents}} коп.</p><button :disabled="product.stock===0" type="button">Выбрать</button></article></template>
