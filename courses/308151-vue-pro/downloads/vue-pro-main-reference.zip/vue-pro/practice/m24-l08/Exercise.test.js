import { mount, flushPromises } from '@vue/test-utils'
import { expect, test, afterEach, vi } from 'vitest'
import Exercise from './Exercise.vue'
const mounted=[]
function render(props={},options={}) { const w=mount(Exercise,{props,...options});mounted.push(w);return w }
function button(w,label) {const b=w.findAll('button').find(x=>x.text()===label);if(!b)throw new Error('Нет кнопки '+label);return b}
afterEach(()=>{ mounted.splice(0).forEach(w=>w.unmount()); document.body.innerHTML='';vi.useRealTimers() })
test('дочерняя карточка открывает диалог',async()=>{const w=render();await button(w,'Выбрать Суп').trigger('click');expect(w.find('[role=dialog]').exists()).toBe(true)})
test('подтверждение меняет родительский итог',async()=>{const w=render();await button(w,'Выбрать Суп').trigger('click');await button(w,'Подтвердить').trigger('click');expect(w.get('output').text()).toBe('1');expect(w.find('[role=dialog]').exists()).toBe(false)})
test('отмена не добавляет',async()=>{const w=render();await button(w,'Выбрать Суп').trigger('click');await button(w,'Отмена').trigger('click');expect(w.get('output').text()).toBe('0')})
