<script setup>
import {ref} from 'vue'
import ProductCard from './ProductCard.vue'
const count=ref(0),open=ref(false)
function confirm(){count.value++;open.value=false}
</script>
<template><main><ProductCard name="Суп" @select="open=true"/><output>{{count}}</output><section v-if="open" role="dialog" @keydown.esc="open=false"><p>Добавить суп?</p><button type="button" @click="confirm">Подтвердить</button><button type="button" @click="open=false">Отмена</button></section></main></template>
