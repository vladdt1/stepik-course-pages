<script setup>
import {ref} from 'vue'
const props=defineProps({products:{type:Array,default:()=>[]}})
const items=ref(props.products.map(p=>({...p,note:p.name})))
const details=ref(false)
function remove(id){items.value=items.value.filter(p=>p.id!==id)}
</script>
<template><main><p v-if="items.length===0" data-testid="empty">Товаров нет</p><ul v-else><li v-for="product in items" :key="product.id" :data-id="product.id"><span>{{product.name}}</span><input v-model="product.note" :aria-label="'Заметка '+product.id"><button type="button" @click="remove(product.id)">Убрать</button></li></ul><button type="button" @click="details=!details">Подробности</button><aside v-show="details">Доставка по правилам</aside></main></template>
