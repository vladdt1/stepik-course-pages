import { mount, flushPromises } from '@vue/test-utils'
import { expect, test, afterEach, vi } from 'vitest'
import Exercise from './Exercise.vue'
const mounted=[]
function render(props={},options={}) { const w=mount(Exercise,{props,...options});mounted.push(w);return w }
function button(w,label) {const b=w.findAll('button').find(x=>x.text()===label);if(!b)throw new Error('Нет кнопки '+label);return b}
afterEach(()=>{ mounted.splice(0).forEach(w=>w.unmount()); document.body.innerHTML='';vi.useRealTimers() })
test('пустота и список взаимоисключаются',()=>{const w=render();expect(w.get('[data-testid=empty]').text()).toBe('Товаров нет');expect(w.find('ul').exists()).toBe(false)})
test('удаление сохраняет личность строки',async()=>{const w=render({products:[{id:1,name:'Суп'},{id:2,name:'Чай'},{id:3,name:'Салат'}]});await w.get('li[data-id="3"] input').setValue('Моя заметка');await w.get('li[data-id="2"] button').trigger('click');expect(w.get('li[data-id="3"] input').element.value).toBe('Моя заметка');expect(w.findAll('li')).toHaveLength(2)})
test('v-show сохраняет DOM при скрытии',async()=>{const w=render();const original=w.get('aside').element;expect(w.get('aside').element.style.display).toBe('none');await button(w,'Подробности').trigger('click');expect(w.get('aside').element.style.display).not.toBe('none');await button(w,'Подробности').trigger('click');expect(w.get('aside').element).toBe(original);expect(w.get('aside').element.style.display).toBe('none')})
