<script setup>
import {ref,computed} from 'vue'
const title=ref(''),tasks=ref([]),filter=ref('all');let id=0
const visible=computed(()=>tasks.value.filter(t=>filter.value==='all'||!t.done))
const remaining=computed(()=>tasks.value.filter(t=>!t.done).length)
function add(){if(!title.value.trim())return;tasks.value.push({id:++id,title:title.value.trim(),done:false});title.value=''}
</script>
<template><main><form @submit.prevent="add"><input v-model="title" aria-label="Задача"><button>Добавить</button></form><select v-model="filter"><option value="all">Все</option><option value="active">Активные</option></select><output>{{remaining}}</output><p v-if="!visible.length">Нет задач</p><ul><li v-for="t in visible" :key="t.id"><input type="checkbox" v-model="t.done"><span>{{t.title}}</span><button type="button" @click="tasks=tasks.filter(x=>x.id!==t.id)">Удалить</button></li></ul></main></template>
