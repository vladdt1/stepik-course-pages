import { mount, flushPromises } from '@vue/test-utils'
import { expect, test, afterEach, vi } from 'vitest'
import Exercise from './Exercise.vue'
const mounted=[]
function render(props={},options={}) { const w=mount(Exercise,{props,...options});mounted.push(w);return w }
function button(w,label) {const b=w.findAll('button').find(x=>x.text()===label);if(!b)throw new Error('Нет кнопки '+label);return b}
afterEach(()=>{ mounted.splice(0).forEach(w=>w.unmount()); document.body.innerHTML='';vi.useRealTimers() })
async function create(w,title){await w.get('input[aria-label=Задача]').setValue(title);await w.get('form').trigger('submit')}
test('пустой ввод отвергается',async()=>{const w=render();await create(w,'  ');expect(w.findAll('li')).toHaveLength(0)})
test('добавление и завершение меняют счётчик',async()=>{const w=render();await create(w,'  Тест  ');expect(w.get('li span').text()).toBe('Тест');await w.get('input[type=checkbox]').setValue(true);expect(w.get('output').text()).toBe('0');await w.get('select').setValue('active');expect(w.findAll('li')).toHaveLength(0)})
test('удаление выбранной строки',async()=>{const w=render();await create(w,'A');await create(w,'B');await w.get('li button').trigger('click');expect(w.findAll('li span').map(x=>x.text())).toEqual(['B'])})
