<script setup>
import {ref,onMounted,onUnmounted} from 'vue'
const emit=defineEmits(['confirm','close'])
const done=ref(false);let previous
function close(){if(done.value)return;done.value=true;emit('close');previous?.focus()}
function confirm(){if(done.value)return;emit('confirm');close()}
function key(e){if(e.key==='Escape')close()}
onMounted(()=>{previous=document.activeElement;window.addEventListener('keydown',key)})
onUnmounted(()=>window.removeEventListener('keydown',key))
</script>
<template><section v-if="!done" role="dialog" aria-label="Подтверждение"><slot>Нет данных</slot><slot name="actions" :confirm="confirm"><button type="button" @click="confirm">Подтвердить</button></slot><button type="button" @click="close">Закрыть</button></section></template>
