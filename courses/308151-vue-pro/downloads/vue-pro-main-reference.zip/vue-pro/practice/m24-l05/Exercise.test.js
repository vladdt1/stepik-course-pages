import { mount, flushPromises } from '@vue/test-utils'
import { expect, test, afterEach, vi } from 'vitest'
import Exercise from './Exercise.vue'
const mounted=[]
function render(props={},options={}) { const w=mount(Exercise,{props,...options});mounted.push(w);return w }
function button(w,label) {const b=w.findAll('button').find(x=>x.text()===label);if(!b)throw new Error('Нет кнопки '+label);return b}
afterEach(()=>{ mounted.splice(0).forEach(w=>w.unmount()); document.body.innerHTML='';vi.useRealTimers() })
test('слот заменяет пустое состояние',()=>{expect(render({}, {slots:{default:'Удалить товар?'}}).text()).toContain('Удалить товар?')})
test('подтверждение одноразовое',async()=>{const w=render();await button(w,'Подтвердить').trigger('click');expect(w.emitted('confirm')).toHaveLength(1);expect(w.emitted('close')).toHaveLength(1);expect(w.find('[role=dialog]').exists()).toBe(false)})
test('Escape возвращает фокус',async()=>{const opener=document.createElement('button');document.body.append(opener);opener.focus();const w=render();window.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape'}));await w.vm.$nextTick();expect(w.emitted('close')).toHaveLength(1);expect(document.activeElement).toBe(opener)})
