import { mount, flushPromises } from '@vue/test-utils'
import { expect, test, afterEach, vi } from 'vitest'
import Exercise from './Exercise.vue'
const mounted=[]
function render(props={},options={}) { const w=mount(Exercise,{props,...options});mounted.push(w);return w }
function button(w,label) {const b=w.findAll('button').find(x=>x.text()===label);if(!b)throw new Error('Нет кнопки '+label);return b}
afterEach(()=>{ mounted.splice(0).forEach(w=>w.unmount()); document.body.innerHTML='';vi.useRealTimers() })
test('выбор передаёт ID ровно один раз',async()=>{const w=render({id:7});await button(w,'Выбрать').trigger('click');expect(w.emitted('select')).toEqual([[7]])})
test('количество сообщает родителю новое значение',async()=>{const w=render({id:7,quantity:2});await button(w,'Больше').trigger('click');expect(w.emitted('update:quantity')).toEqual([[3]]);expect(w.emitted('select')).toBeUndefined()})
test('две карточки независимы',async()=>{const a=render({id:1}),b=render({id:2});await button(b,'Выбрать').trigger('click');expect(a.emitted('select')).toBeUndefined();expect(b.emitted('select')).toEqual([[2]])})
