<script setup>
const props=defineProps({id:Number,quantity:{type:Number,default:0}})
const emit=defineEmits(['select','update:quantity'])
</script>
<template><article @click="emit('select',id)"><span>{{quantity}}</span><button type="button" @click.stop="emit('select',id)">Выбрать</button><button type="button" @click.stop="emit('update:quantity',quantity+1)">Больше</button></article></template>
