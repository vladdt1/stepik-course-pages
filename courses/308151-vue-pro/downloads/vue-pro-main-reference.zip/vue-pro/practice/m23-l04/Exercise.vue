<script setup>
import {ref,reactive} from 'vue'
const quantity=ref(1)
const filters=reactive({query:'',category:0})
function increase(){quantity.value+=1}
function reset(){quantity.value=1;filters.query='';filters.category=0}
</script>
<template><main><p data-testid="quantity">{{quantity}}</p><button type="button" @click="increase">Больше</button><input aria-label="Поиск" :value="filters.query" @input="filters.query=$event.target.value"><p data-testid="query">{{filters.query}}</p><button type="button" @click="reset">Сбросить</button></main></template>
