import { mount, flushPromises } from '@vue/test-utils'
import { expect, test, afterEach, vi } from 'vitest'
import Exercise from './Exercise.vue'
const mounted=[]
function render(props={},options={}) { const w=mount(Exercise,{props,...options});mounted.push(w);return w }
function button(w,label) {const b=w.findAll('button').find(x=>x.text()===label);if(!b)throw new Error('Нет кнопки '+label);return b}
afterEach(()=>{ mounted.splice(0).forEach(w=>w.unmount()); document.body.innerHTML='';vi.useRealTimers() })
test('количество обновляется при действиях',async()=>{const w=render();await button(w,'Больше').trigger('click');await button(w,'Больше').trigger('click');expect(w.get('[data-testid=quantity]').text()).toBe('3')})
test('реактивное поле фильтра обновляется',async()=>{const w=render();await w.get('input').setValue('чай');expect(w.get('[data-testid=query]').text()).toBe('чай')})
test('сброс возвращает согласованное состояние',async()=>{const w=render();await button(w,'Больше').trigger('click');await w.get('input').setValue('суп');await button(w,'Сбросить').trigger('click');expect(w.get('[data-testid=quantity]').text()).toBe('1');expect(w.get('input').element.value).toBe('');expect(w.get('[data-testid=query]').text()).toBe('')})
