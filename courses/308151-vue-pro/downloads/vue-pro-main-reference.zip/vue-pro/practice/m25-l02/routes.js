import {computed} from 'vue'
import {useRoute,useRouter} from 'vue-router'
const Product={setup(){const r=useRoute();return {title:computed(()=>({'1':'Суп','2':'Чай'})[r.params.id]||'Товар не найден')}},template:'<h1>{{title}}</h1>'}
const Catalog={setup(){const r=useRoute(),router=useRouter();return {q:computed(()=>r.query.q||''),change:e=>router.replace({query:{...r.query,q:e.target.value}})}},template:'<label>Поиск<input :value="q" @input="change"></label>'}
export const routes=[{path:'/',component:Catalog},{path:'/products/:id',component:Product}]
