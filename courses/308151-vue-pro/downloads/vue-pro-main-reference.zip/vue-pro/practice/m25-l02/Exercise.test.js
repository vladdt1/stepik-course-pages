import { mount, flushPromises } from '@vue/test-utils'
import { expect, test, afterEach, vi } from 'vitest'
import Exercise from './Exercise.vue'
const mounted=[]
function render(props={},options={}) { const w=mount(Exercise,{props,...options});mounted.push(w);return w }
function button(w,label) {const b=w.findAll('button').find(x=>x.text()===label);if(!b)throw new Error('Нет кнопки '+label);return b}
afterEach(()=>{ mounted.splice(0).forEach(w=>w.unmount()); document.body.innerHTML='';vi.useRealTimers() })
import {createRouter,createMemoryHistory} from 'vue-router'
import {routes} from './routes.js'
async function page(path='/'){const router=createRouter({history:createMemoryHistory(),routes});await router.push(path);await router.isReady();const w=render({}, {global:{plugins:[router]}});return {w,router}}
test('товар по ID',async()=>{const {w}=await page('/products/2');expect(w.get('h1').text()).toBe('Чай')})
test('повторное использование компонента',async()=>{const {w,router}=await page('/products/1');await router.push('/products/999');expect(w.get('h1').text()).toBe('Товар не найден')})
test('query сохраняется и редактируется',async()=>{const {w,router}=await page('/?q=суп&category=food');expect(w.get('input').element.value).toBe('суп');await w.get('input').setValue('чай');await flushPromises();expect(router.currentRoute.value.query).toEqual({q:'чай',category:'food'})})
