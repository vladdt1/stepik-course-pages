<script setup>

</script>
<template><main><nav><RouterLink to="/">Каталог</RouterLink> <RouterLink to="/products/1">Суп</RouterLink></nav><RouterView/></main></template>
