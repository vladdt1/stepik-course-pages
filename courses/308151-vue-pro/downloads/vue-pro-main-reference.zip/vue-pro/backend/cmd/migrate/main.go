package main

import (
	"context"
	"example.com/go-delivery/internal/migrations"
	"example.com/go-delivery/internal/store"
	"log"
	"os"
	"time"
)

func main() {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	s, err := store.Open(ctx, os.Getenv("DATABASE_URL"))
	if err != nil {
		log.Fatal("database connection failed")
	}
	defer s.DB.Close()
	if err = migrations.Apply(ctx, s.DB); err != nil {
		log.Fatal(err)
	}
	if err = s.SeedDemo(ctx, os.Getenv("DEMO_OPERATOR_PASSWORD")); err != nil {
		log.Fatal(err)
	}
	log.Print("migrations and demo catalogue ready")
}
