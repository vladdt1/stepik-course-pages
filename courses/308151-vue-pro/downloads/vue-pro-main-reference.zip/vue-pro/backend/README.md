# Сервис доставки: Go + PostgreSQL

Учебный монолит с HTTP API. Реальной оплаты и Vue пока нет. Go 1.23+ либо только Docker Compose. PostgreSQL 18. Все цены целыми копейками.

## Запуск

В папке с compose.yaml выполните `docker compose up --build -d`. Дождитесь завершения migrate и запуска api: `docker compose ps -a`. Откройте http://localhost:8082/health и /ready. Первый адрес проверяет процесс, второй — соединение с базой. Каталог: http://localhost:8082/api/v1/catalog/products.

Новая база delivery создаётся в отдельном томе нового Compose-проекта. Это та же PostgreSQL, но отдельный стенд с расширенной схемой, а не продолжение старой таблицы orders. Старый стенд предыдущего модуля можно остановить `docker compose down` из его папки. Не переносите его том в новый проект. Порты нового стенда: API 8082, PostgreSQL 55433; внутри сети db:5432. При занятости задайте API_HOST_PORT / PG_HOST_PORT. В PowerShell: `$env:API_HOST_PORT="8083"`, затем обычная команда запуска; Linux/macOS: `API_HOST_PORT=8083 docker compose up -d`.

Демо-учётка оператора operator@example.test / StudyOperator123! создаётся мигратором только если ещё не существует. Пароли и настройки в compose — исключительно для локальной учёбы. Покупателя зарегистрируйте через API. Контейнеры опубликованы только на 127.0.0.1. Для внешнего размещения нужны HTTPS, новые секреты, COOKIE_SECURE=true и отдельный разбор развёртывания. Учебный проект не заявлен готовым коммерческим магазином.

`docker compose logs api` — журнал; `docker compose restart api` — перезапуск; `docker compose down` — остановка с сохранением тома. Не добавляйте -v при обычной остановке.

## Куда писать код

- internal/domain — правила без сети/SQL: деньги, нормализация, статусы.
- internal/store — PostgreSQL, SQL-параметры, транзакции.
- internal/service — сценарии, bcrypt, токены, права.
- internal/httpapi — маршруты, JSON, cookie, ошибки и CORS.
- internal/config — проверка окружения.
- internal/migrations — SQL и журнал версий с контрольными суммами.
- cmd/migrate — применить миграции и начальный каталог; cmd/api — сервер и корректное завершение.

Сверяйтесь с STAGES.md. В starter отмечены TODO; эталон reference нужен для сравнения после самостоятельной работы. Обязательные правила и критерии не спрятаны в тестах.

## API

Все прикладные маршруты начинаются с /api/v1. Запросы с телом требуют Content-Type: application/json, максимум 4096 байт, неизвестные поля и несколько JSON-значений запрещены. Пустые списки возвращаются как [], цены — *_cents. ID положительные. Ошибка: {"error":{"code":"...","message":"...","request_id":"..."}}.

| Метод | Путь | Данные / результат |
|---|---|---|
| GET | /catalog/categories | items |
| GET | /catalog/products | category_id, search, after_id (по возрастанию id), limit 1–50, по умолчанию20; items и next_cursor |
| GET | /catalog/products/{id} | активный товар или404 |
| POST | /auth/register | email, password;201 customer, без автологина |
| POST | /auth/login | email, password;200 и HttpOnly-cookie delivery_session |
| POST | /auth/logout | удалить сессию и cookie;204 |
| GET | /auth/me | текущий пользователь |
| GET | /cart | version, items, subtotal_cents |
| PUT | /cart | version и items[{product_id,quantity}]; полная замена, [] очищает |
| POST | /orders | cart_version,address,comment; заголовок Idempotency-Key;201 новый заказ /200 повтор |
| GET | /orders | свои заказы; before_id по убыванию id, status, limit; items,next_cursor |
| GET | /orders/{id} | свой заказ (оператору любой), позиции и события |
| PATCH | /orders/{id}/status | version,status; покупателю только отмена своего заказа |
| GET | /admin/orders | только оператор, фильтры как /orders |

Ключ идемпотентности 8–128 ASCII букв/цифр/-/_. Область — пользователь. Отпечаток включает нормализованный адрес, комментарий и исходную версию корзины. Повторяйте тот же запрос с тем же ключом; не подставляйте новую версию очищенной корзины. Другие данные с прежним ключом →409. Это повтор команды, а не неизменная фотография ответа: при повторе возвращается текущее состояние уже созданного заказа, новый не создаётся.

Корзина: до40 исходных строк, после объединения одинаковых product_id до20 товаров, итоговое количество каждого1–100. Только активные существующие товары. Версия начинается с1, каждая успешная замена увеличивает её. Остатки здесь не резервируются; available сообщает текущее наличие. Checkout заново проверяет товары, цены и остатки под блокировкой. Пустую корзину оформить нельзя.

Адрес10–300 Unicode-символов после TrimSpace; комментарий до500. Пароль ≥8 Unicode-символов, ≤72 байт (ограничение bcrypt). Email приводится к нижнему регистру и обрезаются крайние пробелы. Каталог фиксирует цену заказа только при оформлении: последующие изменения цен не меняют позиции заказа. subtotal≥100000 — доставка0, иначе14900 копеек. Списываются остатки, сохраняются заказ/позиции/первое событие, очищается корзина — одной транзакцией.

Статусы: new→confirmed→delivering→delivered. new и confirmed можно отменить; delivered/cancelled окончательные. Отмена возвращает остатки ровно один раз. История пишется в той же транзакции. Устаревшая версия →409. Чужой заказ покупателю →404. Роль берётся из БД; регистрация не принимает role/user_id. Оператор не отменяет доставленный заказ.

Cookie действует SESSION_TTL (по умолчанию24h;5m–168h). База хранит SHA256 токена, а не сам токен. Сам случайный токен выдаётся только cookie. В локальном HTTP Secure=false; HttpOnly и SameSite=Lax включены. Сессии проверяются на срок и удаляются при выходе. CORS разрешает ровно CORS_ORIGIN (по умолчанию http://localhost:5173), с credentials. CORS не заменяет проверку владельца. Для реального cross-site размещения потребуется отдельная политика CSRF/cookie; здесь браузер и API работают на localhost.

## Ручная проверка без браузерного интерфейса

В Linux/macOS используйте curl; в PowerShell вызывайте именно curl.exe и учитывайте правила кавычек своей оболочки. Универсальная альтернатива — HTTP-клиент редактора с теми же методами/телами.

```sh
curl -i http://localhost:8082/api/v1/catalog/products
curl -i -H 'Content-Type: application/json' -d '{"email":"alice@example.test","password":"StudyCustomer123!"}' http://localhost:8082/api/v1/auth/register
curl -i -c cookies.txt -H 'Content-Type: application/json' -d '{"email":"alice@example.test","password":"StudyCustomer123!"}' http://localhost:8082/api/v1/auth/login
curl -i -b cookies.txt http://localhost:8082/api/v1/cart
curl -i -b cookies.txt -X PUT -H 'Content-Type: application/json' -d '{"version":1,"items":[{"product_id":1,"quantity":2}]}' http://localhost:8082/api/v1/cart
curl -i -b cookies.txt -H 'Content-Type: application/json' -H 'Idempotency-Key: order-001' -d '{"cart_version":2,"address":"Main street 10","comment":""}' http://localhost:8082/api/v1/orders
```

Последнюю команду повторите без изменений. Ожидайте тот же id, HTTP200 и Idempotency-Replayed:true. Следующий самостоятельный заказ требует новой корзины и нового ключа. Файл cookies.txt содержит локальную сессию: не добавляйте его в Git.

## Проверки

`go test ./...`, `go vet ./...`, `go test -race ./...`.
Интеграционный тест намеренно очищает таблицы: используйте отдельную одноразовую БД, НЕ свою delivery. Например:

```sh
docker compose exec db createdb -U student delivery_test
TEST_DATABASE_URL='postgres://student:study-only@localhost:55433/delivery_test?sslmode=disable' go test -race -tags integration ./...
```

В PowerShell задайте `$env:TEST_DATABASE_URL="postgres://student:study-only@localhost:55433/delivery_test?sslmode=disable"`, затем `go test -race -tags integration ./...`. Флаг integration без переменной завершается ошибкой, а не делает вид, что тест прошёл. Проверяются конкурентные checkout, повтор команды, неизменность цены, возврат остатков, роли, сессии и HTTP. В CI база одноразовая. Теги integration отделяют настоящую PostgreSQL от быстрых тестов правил.
