//go:build integration

package store_test

import (
	"context"
	"encoding/json"
	"errors"
	"example.com/go-delivery/internal/config"
	"example.com/go-delivery/internal/domain"
	"example.com/go-delivery/internal/httpapi"
	"example.com/go-delivery/internal/migrations"
	"example.com/go-delivery/internal/service"
	"example.com/go-delivery/internal/store"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"sync"
	"testing"
	"time"
)

func TestDelivery(t *testing.T) {
	dsn := os.Getenv("TEST_DATABASE_URL")
	if dsn == "" {
		t.Fatal("TEST_DATABASE_URL must point to a disposable test database")
	}
	ctx := context.Background()
	s, e := store.Open(ctx, dsn)
	if e != nil {
		t.Fatal(e)
	}
	defer s.DB.Close()
	if e = migrations.Apply(ctx, s.DB); e != nil {
		t.Fatal(e)
	}
	if e = migrations.Apply(ctx, s.DB); e != nil {
		t.Fatal("migration replay", e)
	}
	if _, e = s.DB.ExecContext(ctx, "TRUNCATE order_events,order_items,orders,cart_items,carts,sessions,users,products,categories RESTART IDENTITY CASCADE"); e != nil {
		t.Fatal(e)
	}
	if e = s.SeedDemo(ctx, "StudyOperator123!"); e != nil {
		t.Fatal(e)
	}
	svc := &service.Service{Repo: s, SessionTTL: time.Hour}
	users := make([]domain.User, 3)
	for i := range users {
		users[i], e = svc.Register(ctx, fmt.Sprintf("user%d@example.test", i), "StudyCustomer123!")
		if e != nil {
			t.Fatal(e)
		}
	}
	if _, e = svc.Register(ctx, "USER0@example.test", "StudyCustomer123!"); !errors.Is(e, domain.ErrConflict) {
		t.Fatal("duplicate email", e)
	}
	u, token, e := svc.Login(ctx, "user0@example.test", "StudyCustomer123!")
	if e != nil || u.ID != users[0].ID {
		t.Fatal(e)
	}
	if _, e = svc.Authenticate(ctx, token); e != nil {
		t.Fatal(e)
	}
	var hash string
	if e = s.DB.QueryRow("SELECT token_hash FROM sessions WHERE user_id=$1", u.ID).Scan(&hash); e != nil || hash == token || hash != service.TokenHash(token) {
		t.Fatal("raw token stored", e)
	}
	cart, e := svc.UpdateCart(ctx, u.ID, domain.CartInput{Version: 1, Items: []domain.ItemInput{{ProductID: 1, Quantity: 2}}})
	if e != nil {
		t.Fatal(e)
	}
	if _, e = svc.UpdateCart(ctx, u.ID, domain.CartInput{Version: 1}); !errors.Is(e, domain.ErrCartVersion) {
		t.Fatal("lost update", e)
	}
	if _, e = svc.UpdateCart(ctx, u.ID, domain.CartInput{Version: 2, Items: []domain.ItemInput{{ProductID: 999, Quantity: 1}}}); !errors.Is(e, domain.ErrInvalid) {
		t.Fatal("missing", e)
	}
	unchanged, _ := s.Cart(ctx, u.ID)
	if unchanged.Version != 2 || len(unchanged.Items) != 1 {
		t.Fatal("invalid update changed cart", unchanged)
	}
	in := domain.CheckoutInput{CartVersion: cart.Version, Address: "Main street 10"}
	order, replay, e := svc.Checkout(ctx, u.ID, "order-001", in)
	if e != nil || replay || order.Total != 84900 || len(order.Events) != 1 {
		t.Fatal(order, replay, e)
	}
	again, replay, e := svc.Checkout(ctx, u.ID, "order-001", in)
	if e != nil || !replay || again.ID != order.ID {
		t.Fatal("retry", again, e)
	}
	changed := in
	changed.Address = "Other street 20"
	if _, _, e = svc.Checkout(ctx, u.ID, "order-001", changed); !errors.Is(e, domain.ErrIdempotency) {
		t.Fatal("changed payload", e)
	}
	if _, e = s.Order(ctx, order.ID, users[1]); !errors.Is(e, domain.ErrNotFound) {
		t.Fatal("foreign read", e)
	}
	if _, e = svc.ChangeStatus(ctx, users[1], order.ID, 1, "cancelled"); !errors.Is(e, domain.ErrNotFound) {
		t.Fatal("foreign cancel", e)
	}
	if _, e = svc.ChangeStatus(ctx, u, order.ID, 1, "confirmed"); !errors.Is(e, domain.ErrForbidden) {
		t.Fatal("role", e)
	}
	if _, e = s.DB.Exec("UPDATE products SET price_cents=99999 WHERE id=1"); e != nil {
		t.Fatal(e)
	}
	frozen, _ := s.Order(ctx, order.ID, u)
	if frozen.Total != order.Total || frozen.Items[0].UnitPrice != 35000 {
		t.Fatal("price not frozen")
	}
	cancelled, e := svc.ChangeStatus(ctx, u, order.ID, 1, "cancelled")
	if e != nil || cancelled.Version != 2 || len(cancelled.Events) != 2 {
		t.Fatal(cancelled, e)
	}
	if _, e = svc.ChangeStatus(ctx, u, order.ID, 2, "cancelled"); !errors.Is(e, domain.ErrTransition) {
		t.Fatal("double cancel", e)
	}
	p, _ := s.Product(ctx, 1)
	if p.Stock != 30 {
		t.Fatal("stock restoration", p.Stock)
	}
	// Two customers compete for one last product: exactly one transaction commits.
	if _, e = s.DB.Exec("UPDATE products SET stock=1,price_cents=35000 WHERE id=1"); e != nil {
		t.Fatal(e)
	}
	for _, x := range users[1:] {
		if _, e = svc.UpdateCart(ctx, x.ID, domain.CartInput{Version: 1, Items: []domain.ItemInput{{ProductID: 1, Quantity: 1}}}); e != nil {
			t.Fatal(e)
		}
	}
	var wg sync.WaitGroup
	errs := make(chan error, 2)
	for _, x := range users[1:] {
		wg.Add(1)
		go func(x domain.User) {
			defer wg.Done()
			_, _, err := svc.Checkout(ctx, x.ID, "last-product", domain.CheckoutInput{CartVersion: 2, Address: "Main street 10"})
			errs <- err
		}(x)
	}
	wg.Wait()
	close(errs)
	ok, stock := 0, 0
	for err := range errs {
		if err == nil {
			ok++
		} else if errors.Is(err, domain.ErrStock) {
			stock++
		} else {
			t.Fatal(err)
		}
	}
	if ok != 1 || stock != 1 {
		t.Fatal("oversell", ok, stock)
	}
	// Same account, concurrent identical command: one new order and one replay.
	c, _ := s.Cart(ctx, u.ID)
	c, e = svc.UpdateCart(ctx, u.ID, domain.CartInput{Version: c.Version, Items: []domain.ItemInput{{ProductID: 2, Quantity: 1}}})
	if e != nil {
		t.Fatal(e)
	}
	type result struct {
		o      domain.Order
		replay bool
		e      error
	}
	results := make(chan result, 2)
	for range 2 {
		wg.Add(1)
		go func() {
			defer wg.Done()
			o, r, e := svc.Checkout(ctx, u.ID, "concurrent-key", domain.CheckoutInput{CartVersion: c.Version, Address: "Main street 10"})
			results <- result{o, r, e}
		}()
	}
	wg.Wait()
	a, b := <-results, <-results
	if a.e != nil || b.e != nil || a.o.ID != b.o.ID || a.replay == b.replay {
		t.Fatal("concurrent retry", a, b)
	}
	// A failing second line must leave the first line, cart and orders untouched.
	before, _ := s.Product(ctx, 2)
	cc, _ := s.Cart(ctx, u.ID)
	cc, e = svc.UpdateCart(ctx, u.ID, domain.CartInput{Version: cc.Version, Items: []domain.ItemInput{{ProductID: 1, Quantity: 1}, {ProductID: 2, Quantity: 1}}})
	if e != nil {
		t.Fatal(e)
	}
	if _, _, e = svc.Checkout(ctx, u.ID, "rollback-key", domain.CheckoutInput{CartVersion: cc.Version, Address: "Main street 10"}); !errors.Is(e, domain.ErrStock) {
		t.Fatal(e)
	}
	after, _ := s.Product(ctx, 2)
	kept, _ := s.Cart(ctx, u.ID)
	if before.Stock != after.Stock || kept.Version != cc.Version || len(kept.Items) != 2 {
		t.Fatal("partial commit")
	}
	// HTTP exercises the same PostgreSQL-backed application.
	cfg := config.Config{Origin: "http://localhost:5173", SessionTTL: time.Hour}
	api := &httpapi.API{DB: s.DB, Service: svc, Config: cfg, Log: slog.New(slog.NewTextHandler(io.Discard, nil))}
	handler := api.Handler()
	request := func(method, path, body, cookie, origin string) *httptest.ResponseRecorder {
		r := httptest.NewRequest(method, path, strings.NewReader(body))
		r.Header.Set("Content-Type", "application/json")
		if cookie != "" {
			r.AddCookie(&http.Cookie{Name: "delivery_session", Value: cookie})
		}
		if origin != "" {
			r.Header.Set("Origin", origin)
		}
		w := httptest.NewRecorder()
		handler.ServeHTTP(w, r)
		return w
	}
	for _, tc := range []struct {
		method, path, body, cookie, origin string
		status                             int
	}{{"GET", "/health", "", "", "", 200}, {"GET", "/ready", "", "", "", 200}, {"GET", "/api/v1/cart", "", "", "", 401}, {"GET", "/api/v1/catalog/products?limit=0", "", "", "", 400}, {"GET", "/api/v1/catalog/products?search=zzzz", "", "", "", 200}, {"GET", "/api/v1/orders/" + fmt.Sprint(order.ID), "", token, "", 200}, {"GET", "/api/v1/admin/orders", "", token, "", 403}, {"POST", "/api/v1/auth/register", `{"email":"evil@example.test","password":"StudyCustomer123!","role":"operator"}`, "", "", 400}, {"GET", "/api/v1/catalog/products", "", "", "http://evil.example", 403}, {"OPTIONS", "/api/v1/cart", "", "", "http://localhost:5173", 204}} {
		w := request(tc.method, tc.path, tc.body, tc.cookie, tc.origin)
		if w.Code != tc.status {
			t.Fatal(tc, w.Code, w.Body.String())
		}
	}
	w := request("GET", "/api/v1/catalog/products?search=zzzz", "", "", "")
	if !strings.Contains(w.Body.String(), `"items":[]`) {
		t.Fatal("empty items", w.Body.String())
	}
	w = request("POST", "/api/v1/auth/login", `{"email":"user0@example.test","password":"StudyCustomer123!"}`, "", "")
	if w.Code != 200 || len(w.Result().Cookies()) != 1 || !w.Result().Cookies()[0].HttpOnly {
		t.Fatal("cookie", w.Body.String())
	}
	var body map[string]any
	_ = json.Unmarshal(w.Body.Bytes(), &body)
	if _, ok := body["password_hash"]; ok {
		t.Fatal("password leaked")
	}
	if e = svc.Logout(ctx, token); e != nil {
		t.Fatal(e)
	}
	if _, e = svc.Authenticate(ctx, token); !errors.Is(e, domain.ErrUnauthorized) {
		t.Fatal("logout", e)
	}
	_, expired, e := svc.Login(ctx, "user0@example.test", "StudyCustomer123!")
	if e != nil {
		t.Fatal(e)
	}
	s.DB.Exec("UPDATE sessions SET expires_at=now()-interval '1 minute' WHERE token_hash=$1", service.TokenHash(expired))
	if _, e = svc.Authenticate(ctx, expired); !errors.Is(e, domain.ErrUnauthorized) {
		t.Fatal("expiry", e)
	}
}
