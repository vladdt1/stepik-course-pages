package store

import (
	"context"
	"example.com/go-delivery/internal/domain"
	"golang.org/x/crypto/bcrypt"
)

func (s *Store) SeedDemo(ctx context.Context, operatorPassword string) error {
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()
	_, err = tx.ExecContext(ctx, `INSERT INTO categories(id,name) VALUES(1,'Горячее'),(2,'Напитки') ON CONFLICT(id) DO NOTHING;
      INSERT INTO products(id,category_id,name,description,price_cents,stock,active) VALUES
      (1,1,'Томатный суп','Порция 350 г',35000,30,true),
      (2,2,'Чай','Чёрный чай, 300 мл',9000,100,true),
      (3,1,'Овощной салат','Порция 250 г',28000,20,true),
      (4,1,'Пицца','Сырная пицца, 30 см',65000,15,true)
      ON CONFLICT(id) DO NOTHING`)
	if err != nil {
		return err
	}
	if operatorPassword != "" {
		if !domain.ValidPassword(operatorPassword) {
			return domain.ErrInvalid
		}
		hash, e := bcrypt.GenerateFromPassword([]byte(operatorPassword), bcrypt.DefaultCost)
		if e != nil {
			return e
		}
		_, err = tx.ExecContext(ctx, `INSERT INTO users(email,password_hash,role) VALUES('operator@example.test',$1,'operator') ON CONFLICT(email) DO NOTHING`, string(hash))
		if err != nil {
			return err
		}
		_, err = tx.ExecContext(ctx, "INSERT INTO carts(user_id) SELECT id FROM users WHERE email='operator@example.test' ON CONFLICT(user_id) DO NOTHING")
		if err != nil {
			return err
		}
	}
	return tx.Commit()
}
