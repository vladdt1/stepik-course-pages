package store

import (
	"context"
	"database/sql"
	"errors"
	"time"

	"example.com/go-delivery/internal/domain"
	_ "github.com/jackc/pgx/v5/stdlib"
)

type Store struct{ DB *sql.DB }
type AuthRecord struct {
	User         domain.User
	PasswordHash string
}
type CatalogFilter struct {
	CategoryID, AfterID int64
	Search              string
	Limit               int
}
type OrderFilter struct {
	UserID, BeforeID int64
	Status           string
	Limit            int
}
type CatalogPage struct {
	Items      []domain.Product `json:"items"`
	NextCursor int64            `json:"next_cursor"`
}
type OrdersPage struct {
	Items      []domain.OrderSummary `json:"items"`
	NextCursor int64                 `json:"next_cursor"`
}

func Open(ctx context.Context, dsn string) (*Store, error) {
	db, err := sql.Open("pgx", dsn)
	if err != nil {
		return nil, err
	}
	db.SetMaxOpenConns(10)
	db.SetMaxIdleConns(3)
	db.SetConnMaxLifetime(30 * time.Minute)
	if err = db.PingContext(ctx); err != nil {
		db.Close()
		return nil, err
	}
	return &Store{DB: db}, nil
}
func mapError(err error) error {
	if errors.Is(err, sql.ErrNoRows) {
		return domain.ErrNotFound
	}
	var pg interface{ SQLState() string }
	if errors.As(err, &pg) && pg.SQLState() == "23505" {
		return domain.ErrConflict
	}
	return err
}
func (s *Store) Categories(ctx context.Context) ([]domain.Category, error) {
	rows, err := s.DB.QueryContext(ctx, "SELECT id,name FROM categories ORDER BY id")
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.Category, 0)
	for rows.Next() {
		var c domain.Category
		if err = rows.Scan(&c.ID, &c.Name); err != nil {
			return nil, err
		}
		out = append(out, c)
	}
	return out, rows.Err()
}
func (s *Store) Catalog(ctx context.Context, f CatalogFilter) (CatalogPage, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT id,category_id,name,description,price_cents,stock,active
      FROM products WHERE active AND id>$1
      AND ($2::bigint=0 OR category_id=$2)
      AND ($3='' OR strpos(lower(name),lower($3))>0)
      ORDER BY id LIMIT $4`, f.AfterID, f.CategoryID, f.Search, f.Limit+1)
	if err != nil {
		return CatalogPage{}, err
	}
	defer rows.Close()
	out := CatalogPage{Items: make([]domain.Product, 0)}
	for rows.Next() {
		var p domain.Product
		if err = rows.Scan(&p.ID, &p.CategoryID, &p.Name, &p.Description, &p.Price, &p.Stock, &p.Active); err != nil {
			return out, err
		}
		out.Items = append(out.Items, p)
	}
	if err = rows.Err(); err != nil {
		return out, err
	}
	if len(out.Items) > f.Limit {
		out.Items = out.Items[:f.Limit]
		out.NextCursor = out.Items[len(out.Items)-1].ID
	}
	return out, nil
}
func (s *Store) Product(ctx context.Context, id int64) (domain.Product, error) {
	var p domain.Product
	err := s.DB.QueryRowContext(ctx, "SELECT id,category_id,name,description,price_cents,stock,active FROM products WHERE id=$1 AND active", id).Scan(&p.ID, &p.CategoryID, &p.Name, &p.Description, &p.Price, &p.Stock, &p.Active)
	return p, mapError(err)
}
func (s *Store) CreateUser(ctx context.Context, email, hash string) (domain.User, error) {
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return domain.User{}, err
	}
	defer tx.Rollback()
	var u domain.User
	if err = tx.QueryRowContext(ctx, "INSERT INTO users(email,password_hash) VALUES($1,$2) RETURNING id,email,role", email, hash).Scan(&u.ID, &u.Email, &u.Role); err != nil {
		return u, mapError(err)
	}
	if _, err = tx.ExecContext(ctx, "INSERT INTO carts(user_id) VALUES($1)", u.ID); err != nil {
		return u, err
	}
	return u, tx.Commit()
}
func (s *Store) AuthByEmail(ctx context.Context, email string) (AuthRecord, error) {
	var r AuthRecord
	err := s.DB.QueryRowContext(ctx, "SELECT id,email,role,password_hash FROM users WHERE email=$1", email).Scan(&r.User.ID, &r.User.Email, &r.User.Role, &r.PasswordHash)
	return r, mapError(err)
}
func (s *Store) SaveSession(ctx context.Context, userID int64, hash string, expires time.Time) error {
	_, err := s.DB.ExecContext(ctx, "INSERT INTO sessions(token_hash,user_id,expires_at) VALUES($1,$2,$3)", hash, userID, expires)
	return err
}
func (s *Store) SessionUser(ctx context.Context, hash string) (domain.User, error) {
	var u domain.User
	err := s.DB.QueryRowContext(ctx, `SELECT u.id,u.email,u.role FROM sessions s JOIN users u ON u.id=s.user_id
      WHERE s.token_hash=$1 AND s.expires_at>now()`, hash).Scan(&u.ID, &u.Email, &u.Role)
	return u, mapError(err)
}
func (s *Store) DeleteSession(ctx context.Context, hash string) error {
	_, err := s.DB.ExecContext(ctx, "DELETE FROM sessions WHERE token_hash=$1", hash)
	return err
}

type queryer interface {
	QueryContext(context.Context, string, ...any) (*sql.Rows, error)
	QueryRowContext(context.Context, string, ...any) *sql.Row
}

func readCart(ctx context.Context, q queryer, userID int64) (domain.Cart, error) {
	out := domain.Cart{Items: make([]domain.CartLine, 0)}
	if err := q.QueryRowContext(ctx, "SELECT version FROM carts WHERE user_id=$1", userID).Scan(&out.Version); err != nil {
		return out, mapError(err)
	}
	rows, err := q.QueryContext(ctx, `SELECT p.id,p.name,p.price_cents,c.quantity,p.active AND p.stock>=c.quantity
      FROM cart_items c JOIN products p ON p.id=c.product_id WHERE c.user_id=$1 ORDER BY p.id`, userID)
	if err != nil {
		return out, err
	}
	defer rows.Close()
	for rows.Next() {
		var item domain.CartLine
		if err = rows.Scan(&item.ProductID, &item.Name, &item.UnitPrice, &item.Quantity, &item.Available); err != nil {
			return out, err
		}
		item.LineTotal = item.UnitPrice * int64(item.Quantity)
		out.Subtotal += item.LineTotal
		out.Items = append(out.Items, item)
	}
	return out, rows.Err()
}
func (s *Store) Cart(ctx context.Context, userID int64) (domain.Cart, error) {
	// Both version and lines belong to one consistent snapshot.
	tx, err := s.DB.BeginTx(ctx, &sql.TxOptions{ReadOnly: true, Isolation: sql.LevelRepeatableRead})
	if err != nil {
		return domain.Cart{}, err
	}
	defer tx.Rollback()
	cart, err := readCart(ctx, tx, userID)
	if err != nil {
		return cart, err
	}
	return cart, tx.Commit()
}
func lockCart(ctx context.Context, tx *sql.Tx, userID int64) (int64, error) {
	var v int64
	err := tx.QueryRowContext(ctx, "SELECT version FROM carts WHERE user_id=$1 FOR UPDATE", userID).Scan(&v)
	return v, mapError(err)
}
func (s *Store) ReplaceCart(ctx context.Context, userID int64, in domain.CartInput) (domain.Cart, error) {
	normalized, err := domain.NormalizeItems(in.Items)
	if err != nil || in.Version < 1 {
		return domain.Cart{}, domain.ErrInvalid
	}
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return domain.Cart{}, err
	}
	defer tx.Rollback()
	version, err := lockCart(ctx, tx, userID)
	if err != nil {
		return domain.Cart{}, err
	}
	if version != in.Version {
		return domain.Cart{}, domain.ErrCartVersion
	}
	// Validate every product before deleting existing lines.
	for _, item := range normalized {
		var active bool
		if err = tx.QueryRowContext(ctx, "SELECT active FROM products WHERE id=$1", item.ProductID).Scan(&active); err != nil {
			if errors.Is(err, sql.ErrNoRows) {
				return domain.Cart{}, domain.ErrInvalid
			}
			return domain.Cart{}, err
		}
		if !active {
			return domain.Cart{}, domain.ErrInvalid
		}
	}
	if _, err = tx.ExecContext(ctx, "DELETE FROM cart_items WHERE user_id=$1", userID); err != nil {
		return domain.Cart{}, err
	}
	for _, item := range normalized {
		if _, err = tx.ExecContext(ctx, "INSERT INTO cart_items(user_id,product_id,quantity) VALUES($1,$2,$3)", userID, item.ProductID, item.Quantity); err != nil {
			return domain.Cart{}, err
		}
	}
	if _, err = tx.ExecContext(ctx, "UPDATE carts SET version=version+1 WHERE user_id=$1", userID); err != nil {
		return domain.Cart{}, err
	}
	cart, err := readCart(ctx, tx, userID)
	if err != nil {
		return cart, err
	}
	return cart, tx.Commit()
}
func readOrder(ctx context.Context, q queryer, id int64) (domain.Order, error) {
	o := domain.Order{Items: make([]domain.OrderItem, 0), Events: make([]domain.Event, 0)}
	err := q.QueryRowContext(ctx, `SELECT id,user_id,status,version,subtotal_cents,delivery_fee_cents,total_cents,address,comment,created_at FROM orders WHERE id=$1`, id).Scan(&o.ID, &o.UserID, &o.Status, &o.Version, &o.Subtotal, &o.DeliveryFee, &o.Total, &o.Address, &o.Comment, &o.CreatedAt)
	if err != nil {
		return o, mapError(err)
	}
	rows, err := q.QueryContext(ctx, "SELECT product_id,name,unit_price_cents,quantity FROM order_items WHERE order_id=$1 ORDER BY product_id", id)
	if err != nil {
		return o, err
	}
	for rows.Next() {
		var i domain.OrderItem
		if err = rows.Scan(&i.ProductID, &i.Name, &i.UnitPrice, &i.Quantity); err != nil {
			rows.Close()
			return o, err
		}
		i.LineTotal = i.UnitPrice * int64(i.Quantity)
		o.Items = append(o.Items, i)
	}
	err = rows.Err()
	rows.Close()
	if err != nil {
		return o, err
	}
	rows, err = q.QueryContext(ctx, "SELECT status,created_at FROM order_events WHERE order_id=$1 ORDER BY id", id)
	if err != nil {
		return o, err
	}
	defer rows.Close()
	for rows.Next() {
		var e domain.Event
		if err = rows.Scan(&e.Status, &e.CreatedAt); err != nil {
			return o, err
		}
		o.Events = append(o.Events, e)
	}
	return o, rows.Err()
}
func (s *Store) Order(ctx context.Context, id int64, actor domain.User) (domain.Order, error) {
	// Authorization is checked before details leave the repository.
	var found int64
	err := s.DB.QueryRowContext(ctx, "SELECT id FROM orders WHERE id=$1 AND (user_id=$2 OR $3)", id, actor.ID, actor.Role == "operator").Scan(&found)
	if err != nil {
		return domain.Order{}, mapError(err)
	}
	tx, err := s.DB.BeginTx(ctx, &sql.TxOptions{ReadOnly: true, Isolation: sql.LevelRepeatableRead})
	if err != nil {
		return domain.Order{}, err
	}
	defer tx.Rollback()
	o, err := readOrder(ctx, tx, found)
	if err != nil {
		return o, err
	}
	return o, tx.Commit()
}
func (s *Store) Orders(ctx context.Context, f OrderFilter) (OrdersPage, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT id,user_id,status,version,total_cents,created_at FROM orders
      WHERE ($1::bigint=0 OR user_id=$1) AND ($2='' OR status=$2) AND ($3::bigint=0 OR id<$3)
      ORDER BY id DESC LIMIT $4`, f.UserID, f.Status, f.BeforeID, f.Limit+1)
	out := OrdersPage{Items: make([]domain.OrderSummary, 0)}
	if err != nil {
		return out, err
	}
	defer rows.Close()
	for rows.Next() {
		var o domain.OrderSummary
		if err = rows.Scan(&o.ID, &o.UserID, &o.Status, &o.Version, &o.Total, &o.CreatedAt); err != nil {
			return out, err
		}
		out.Items = append(out.Items, o)
	}
	if err = rows.Err(); err != nil {
		return out, err
	}
	if len(out.Items) > f.Limit {
		out.Items = out.Items[:f.Limit]
		out.NextCursor = out.Items[len(out.Items)-1].ID
	}
	return out, nil
}
func (s *Store) Checkout(ctx context.Context, userID int64, key, fingerprint string, in domain.CheckoutInput) (domain.Order, bool, error) {
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return domain.Order{}, false, err
	}
	defer tx.Rollback()
	version, err := lockCart(ctx, tx, userID)
	if err != nil {
		return domain.Order{}, false, err
	}
	// Checking under the cart lock also serializes simultaneous retries.
	var existingID int64
	var savedFingerprint string
	err = tx.QueryRowContext(ctx, "SELECT id,fingerprint FROM orders WHERE user_id=$1 AND idempotency_key=$2", userID, key).Scan(&existingID, &savedFingerprint)
	if err == nil {
		if savedFingerprint != fingerprint {
			return domain.Order{}, false, domain.ErrIdempotency
		}
		o, e := readOrder(ctx, tx, existingID)
		if e != nil {
			return o, false, e
		}
		return o, true, tx.Commit()
	}
	if err != sql.ErrNoRows {
		return domain.Order{}, false, err
	}
	if version != in.CartVersion {
		return domain.Order{}, false, domain.ErrCartVersion
	}
	rows, err := tx.QueryContext(ctx, `SELECT p.id,p.category_id,p.name,p.description,p.price_cents,p.stock,p.active,c.quantity
      FROM cart_items c JOIN products p ON p.id=c.product_id
      WHERE c.user_id=$1 ORDER BY p.id FOR UPDATE OF p`, userID)
	if err != nil {
		return domain.Order{}, false, err
	}
	lines := make([]domain.DraftLine, 0)
	for rows.Next() {
		var l domain.DraftLine
		p := &l.Product
		if err = rows.Scan(&p.ID, &p.CategoryID, &p.Name, &p.Description, &p.Price, &p.Stock, &p.Active, &l.Quantity); err != nil {
			rows.Close()
			return domain.Order{}, false, err
		}
		lines = append(lines, l)
	}
	err = rows.Err()
	rows.Close()
	if err != nil {
		return domain.Order{}, false, err
	}
	draft, err := domain.BuildDraft(lines)
	if err != nil {
		return domain.Order{}, false, err
	}
	var orderID int64
	err = tx.QueryRowContext(ctx, `INSERT INTO orders(user_id,status,subtotal_cents,delivery_fee_cents,total_cents,address,comment,idempotency_key,fingerprint)
      VALUES($1,'new',$2,$3,$4,$5,$6,$7,$8) RETURNING id`, userID, draft.Subtotal, draft.DeliveryFee, draft.Total, in.Address, in.Comment, key, fingerprint).Scan(&orderID)
	if err != nil {
		return domain.Order{}, false, mapError(err)
	}
	for _, item := range draft.Items {
		if _, err = tx.ExecContext(ctx, "INSERT INTO order_items(order_id,product_id,name,unit_price_cents,quantity) VALUES($1,$2,$3,$4,$5)", orderID, item.ProductID, item.Name, item.UnitPrice, item.Quantity); err != nil {
			return domain.Order{}, false, err
		}
		if _, err = tx.ExecContext(ctx, "UPDATE products SET stock=stock-$1 WHERE id=$2", item.Quantity, item.ProductID); err != nil {
			return domain.Order{}, false, err
		}
	}
	if _, err = tx.ExecContext(ctx, "INSERT INTO order_events(order_id,actor_id,status) VALUES($1,$2,'new')", orderID, userID); err != nil {
		return domain.Order{}, false, err
	}
	if _, err = tx.ExecContext(ctx, "DELETE FROM cart_items WHERE user_id=$1", userID); err != nil {
		return domain.Order{}, false, err
	}
	if _, err = tx.ExecContext(ctx, "UPDATE carts SET version=version+1 WHERE user_id=$1", userID); err != nil {
		return domain.Order{}, false, err
	}
	o, err := readOrder(ctx, tx, orderID)
	if err != nil {
		return o, false, err
	}
	return o, false, tx.Commit()
}
func (s *Store) ChangeStatus(ctx context.Context, id, expectedVersion int64, actor domain.User, next string) (domain.Order, error) {
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return domain.Order{}, err
	}
	defer tx.Rollback()
	var owner, version int64
	var current string
	err = tx.QueryRowContext(ctx, "SELECT user_id,status,version FROM orders WHERE id=$1 FOR UPDATE", id).Scan(&owner, &current, &version)
	if err != nil {
		return domain.Order{}, mapError(err)
	}
	if actor.Role != "operator" && owner != actor.ID {
		return domain.Order{}, domain.ErrNotFound
	}
	if actor.Role != "operator" && next != "cancelled" {
		return domain.Order{}, domain.ErrForbidden
	}
	if version != expectedVersion {
		return domain.Order{}, domain.ErrOrderVersion
	}
	if !domain.CanTransition(current, next) {
		return domain.Order{}, domain.ErrTransition
	}
	if next == "cancelled" {
		// Same product order as checkout avoids opposing lock orders.
		rows, e := tx.QueryContext(ctx, "SELECT product_id,quantity FROM order_items WHERE order_id=$1 ORDER BY product_id", id)
		if e != nil {
			return domain.Order{}, e
		}
		items := make([]domain.ItemInput, 0)
		for rows.Next() {
			var x domain.ItemInput
			if e = rows.Scan(&x.ProductID, &x.Quantity); e != nil {
				rows.Close()
				return domain.Order{}, e
			}
			items = append(items, x)
		}
		e = rows.Err()
		rows.Close()
		if e != nil {
			return domain.Order{}, e
		}
		for _, item := range items {
			if _, err = tx.ExecContext(ctx, "UPDATE products SET stock=stock+$1 WHERE id=$2", item.Quantity, item.ProductID); err != nil {
				return domain.Order{}, err
			}
		}
	}
	if _, err = tx.ExecContext(ctx, "UPDATE orders SET status=$1,version=version+1 WHERE id=$2", next, id); err != nil {
		return domain.Order{}, err
	}
	if _, err = tx.ExecContext(ctx, "INSERT INTO order_events(order_id,actor_id,status) VALUES($1,$2,$3)", id, actor.ID, next); err != nil {
		return domain.Order{}, err
	}
	o, err := readOrder(ctx, tx, id)
	if err != nil {
		return o, err
	}
	return o, tx.Commit()
}
