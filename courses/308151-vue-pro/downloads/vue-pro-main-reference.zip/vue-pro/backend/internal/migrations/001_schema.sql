CREATE TABLE users (
 id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 email TEXT NOT NULL UNIQUE CHECK (email=lower(email)),
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'customer' CHECK (role IN ('customer','operator')),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE sessions (
 token_hash TEXT PRIMARY KEY,
 user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 expires_at TIMESTAMPTZ NOT NULL
);
CREATE TABLE categories (
 id BIGINT PRIMARY KEY, name TEXT NOT NULL UNIQUE
);
CREATE TABLE products (
 id BIGINT PRIMARY KEY,
 category_id BIGINT NOT NULL REFERENCES categories(id),
 name TEXT NOT NULL,
 description TEXT NOT NULL DEFAULT '',
 price_cents BIGINT NOT NULL CHECK (price_cents BETWEEN 0 AND 100000000),
 stock INT NOT NULL CHECK (stock>=0),
 active BOOLEAN NOT NULL DEFAULT true
);
CREATE TABLE carts (
 user_id BIGINT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
 version BIGINT NOT NULL DEFAULT 1 CHECK (version>0)
);
CREATE TABLE cart_items (
 user_id BIGINT NOT NULL REFERENCES carts(user_id) ON DELETE CASCADE,
 product_id BIGINT NOT NULL REFERENCES products(id),
 quantity INT NOT NULL CHECK (quantity BETWEEN 1 AND 100),
 PRIMARY KEY(user_id,product_id)
);
CREATE TABLE orders (
 id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 user_id BIGINT NOT NULL REFERENCES users(id),
 status TEXT NOT NULL CHECK (status IN ('new','confirmed','delivering','delivered','cancelled')),
 version BIGINT NOT NULL DEFAULT 1,
 subtotal_cents BIGINT NOT NULL CHECK (subtotal_cents>=0),
 delivery_fee_cents BIGINT NOT NULL CHECK (delivery_fee_cents>=0),
 total_cents BIGINT NOT NULL CHECK (total_cents=subtotal_cents+delivery_fee_cents),
 address TEXT NOT NULL,
 comment TEXT NOT NULL DEFAULT '',
 idempotency_key TEXT NOT NULL,
 fingerprint TEXT NOT NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 UNIQUE(user_id,idempotency_key)
);
CREATE TABLE order_items (
 order_id BIGINT NOT NULL REFERENCES orders(id),
 product_id BIGINT NOT NULL REFERENCES products(id),
 name TEXT NOT NULL,
 unit_price_cents BIGINT NOT NULL CHECK (unit_price_cents>=0),
 quantity INT NOT NULL CHECK (quantity BETWEEN 1 AND 100),
 PRIMARY KEY(order_id,product_id)
);
CREATE TABLE order_events (
 id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 order_id BIGINT NOT NULL REFERENCES orders(id),
 actor_id BIGINT NOT NULL REFERENCES users(id),
 status TEXT NOT NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
