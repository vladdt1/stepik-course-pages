CREATE INDEX orders_user_id_id ON orders(user_id,id DESC);
CREATE INDEX orders_status_id ON orders(status,id DESC);
CREATE INDEX order_events_order_id_id ON order_events(order_id,id);
CREATE INDEX sessions_user_id ON sessions(user_id);
CREATE INDEX sessions_expires_at ON sessions(expires_at);
CREATE INDEX products_category_id ON products(category_id,id);
