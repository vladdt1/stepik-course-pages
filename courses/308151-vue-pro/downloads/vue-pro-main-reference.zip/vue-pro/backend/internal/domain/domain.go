package domain

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"net/mail"
	"sort"
	"strings"
	"time"
	"unicode/utf8"
)

var (
	ErrInvalid        = errors.New("invalid input")
	ErrUnauthorized   = errors.New("unauthorized")
	ErrForbidden      = errors.New("forbidden")
	ErrNotFound       = errors.New("not found")
	ErrConflict       = errors.New("conflict")
	ErrStock          = errors.New("insufficient stock")
	ErrCartVersion    = errors.New("cart version conflict")
	ErrOrderVersion   = errors.New("order version conflict")
	ErrIdempotency    = errors.New("idempotency conflict")
	ErrTransition     = errors.New("invalid status transition")
	ErrNotImplemented = errors.New("complete the learning exercise")
)

type User struct {
	ID    int64  `json:"id"`
	Email string `json:"email"`
	Role  string `json:"role"`
}
type Category struct {
	ID   int64  `json:"id"`
	Name string `json:"name"`
}
type Product struct {
	ID          int64  `json:"id"`
	CategoryID  int64  `json:"category_id"`
	Name        string `json:"name"`
	Description string `json:"description"`
	Price       int64  `json:"price_cents"`
	Stock       int    `json:"stock"`
	Active      bool   `json:"active"`
}
type ItemInput struct {
	ProductID int64 `json:"product_id"`
	Quantity  int   `json:"quantity"`
}
type CartInput struct {
	Version int64       `json:"version"`
	Items   []ItemInput `json:"items"`
}
type CartLine struct {
	ProductID int64  `json:"product_id"`
	Name      string `json:"name"`
	UnitPrice int64  `json:"unit_price_cents"`
	Quantity  int    `json:"quantity"`
	LineTotal int64  `json:"line_total_cents"`
	Available bool   `json:"available"`
}
type Cart struct {
	Version  int64      `json:"version"`
	Items    []CartLine `json:"items"`
	Subtotal int64      `json:"subtotal_cents"`
}
type CheckoutInput struct {
	CartVersion int64  `json:"cart_version"`
	Address     string `json:"address"`
	Comment     string `json:"comment"`
}
type OrderItem struct {
	ProductID int64  `json:"product_id"`
	Name      string `json:"name"`
	UnitPrice int64  `json:"unit_price_cents"`
	Quantity  int    `json:"quantity"`
	LineTotal int64  `json:"line_total_cents"`
}
type Event struct {
	Status    string    `json:"status"`
	CreatedAt time.Time `json:"created_at"`
}
type Order struct {
	ID          int64       `json:"id"`
	UserID      int64       `json:"user_id"`
	Status      string      `json:"status"`
	Version     int64       `json:"version"`
	Subtotal    int64       `json:"subtotal_cents"`
	DeliveryFee int64       `json:"delivery_fee_cents"`
	Total       int64       `json:"total_cents"`
	Address     string      `json:"address"`
	Comment     string      `json:"comment"`
	CreatedAt   time.Time   `json:"created_at"`
	Items       []OrderItem `json:"items"`
	Events      []Event     `json:"events"`
}
type OrderSummary struct {
	ID        int64     `json:"id"`
	UserID    int64     `json:"user_id"`
	Status    string    `json:"status"`
	Version   int64     `json:"version"`
	Total     int64     `json:"total_cents"`
	CreatedAt time.Time `json:"created_at"`
}
type DraftLine struct {
	Product  Product
	Quantity int
}
type Draft struct {
	Items                        []OrderItem
	Subtotal, DeliveryFee, Total int64
}

func NormalizeEmail(raw string) (string, error) {
	email := strings.ToLower(strings.TrimSpace(raw))
	if len(email) > 254 || strings.ContainsAny(email, "\r\n") {
		return "", ErrInvalid
	}
	parsed, err := mail.ParseAddress(email)
	if err != nil || parsed.Name != "" || parsed.Address != email {
		return "", ErrInvalid
	}
	return email, nil
}
func ValidPassword(password string) bool {
	return utf8.RuneCountInString(password) >= 8 && len(password) <= 72
}
func NormalizeItems(items []ItemInput) ([]ItemInput, error) {
	if len(items) > 40 {
		return nil, ErrInvalid
	}
	counts := make(map[int64]int)
	for _, item := range items {
		if item.ProductID <= 0 || item.Quantity < 1 || item.Quantity > 100 {
			return nil, ErrInvalid
		}
		counts[item.ProductID] += item.Quantity
		if counts[item.ProductID] > 100 {
			return nil, ErrInvalid
		}
	}
	if len(counts) > 20 {
		return nil, ErrInvalid
	}
	out := make([]ItemInput, 0, len(counts))
	for id, q := range counts {
		out = append(out, ItemInput{id, q})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ProductID < out[j].ProductID })
	return out, nil
}
func DeliveryFee(subtotal int64) int64 {
	if subtotal >= 100000 {
		return 0
	}
	return 14900
}
func BuildDraft(lines []DraftLine) (Draft, error) {
	if len(lines) == 0 || len(lines) > 20 {
		return Draft{}, ErrInvalid
	}
	d := Draft{Items: make([]OrderItem, 0, len(lines))}
	for _, line := range lines {
		p, q := line.Product, line.Quantity
		if p.ID <= 0 || !p.Active {
			return Draft{}, ErrInvalid
		}
		if q < 1 || q > 100 || p.Price < 0 || p.Price > 100000000 {
			return Draft{}, ErrInvalid
		}
		if p.Stock < q {
			return Draft{}, ErrStock
		}
		total := p.Price * int64(q)
		d.Items = append(d.Items, OrderItem{p.ID, p.Name, p.Price, q, total})
		d.Subtotal += total
	}
	d.DeliveryFee = DeliveryFee(d.Subtotal)
	d.Total = d.Subtotal + d.DeliveryFee
	return d, nil
}
func NormalizeCheckout(in CheckoutInput) (CheckoutInput, error) {
	in.Address = strings.TrimSpace(in.Address)
	in.Comment = strings.TrimSpace(in.Comment)
	n := utf8.RuneCountInString(in.Address)
	if in.CartVersion < 1 || n < 10 || n > 300 || utf8.RuneCountInString(in.Comment) > 500 {
		return CheckoutInput{}, ErrInvalid
	}
	return in, nil
}
func ValidIdempotencyKey(key string) bool {
	if len(key) < 8 || len(key) > 128 {
		return false
	}
	for _, c := range key {
		if !(c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' || c == '-' || c == '_') {
			return false
		}
	}
	return true
}
func Fingerprint(in CheckoutInput) string {
	data, _ := json.Marshal(in)
	sum := sha256.Sum256(data)
	return hex.EncodeToString(sum[:])
}
func CanTransition(from, to string) bool {
	switch from {
	case "new":
		return to == "confirmed" || to == "cancelled"
	case "confirmed":
		return to == "delivering" || to == "cancelled"
	case "delivering":
		return to == "delivered"
	default:
		return false
	}
}
func KnownStatus(s string) bool {
	return s == "new" || s == "confirmed" || s == "delivering" || s == "delivered" || s == "cancelled"
}
