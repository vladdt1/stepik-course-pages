package domain

import (
	"errors"
	"testing"
)

func TestDeliveryBoundary(t *testing.T) {
	for _, x := range []struct{ in, want int64 }{{99999, 14900}, {100000, 0}, {100001, 0}} {
		if got := DeliveryFee(x.in); got != x.want {
			t.Fatalf("%d: %d", x.in, got)
		}
	}
}
func TestNormalizeItems(t *testing.T) {
	v, e := NormalizeItems([]ItemInput{{2, 2}, {1, 1}, {2, 3}})
	if e != nil || len(v) != 2 || v[0].ProductID != 1 || v[1].Quantity != 5 {
		t.Fatal(v, e)
	}
	for _, x := range [][]ItemInput{{{1, 0}}, {{1, 100}, {1, 1}}, {{0, 1}}} {
		if _, e = NormalizeItems(x); !errors.Is(e, ErrInvalid) {
			t.Fatal(x, e)
		}
	}
	v, e = NormalizeItems(nil)
	if e != nil || v == nil || len(v) != 0 {
		t.Fatal(v, e)
	}
}
func TestBuildDraft(t *testing.T) {
	lines := []DraftLine{{Product: Product{ID: 1, Name: "soup", Price: 35000, Stock: 2, Active: true}, Quantity: 2}}
	d, e := BuildDraft(lines)
	if e != nil || d.Subtotal != 70000 || d.Total != 84900 || d.Items[0].UnitPrice != 35000 {
		t.Fatal(d, e)
	}
	lines[0].Quantity = 3
	if _, e = BuildDraft(lines); !errors.Is(e, ErrStock) {
		t.Fatal(e)
	}
	lines[0].Product.Active = false
	if _, e = BuildDraft(lines); e == nil {
		t.Fatal("inactive accepted")
	}
}
func TestTransitions(t *testing.T) {
	allowed := map[string]bool{"new:confirmed": true, "new:cancelled": true, "confirmed:delivering": true, "confirmed:cancelled": true, "delivering:delivered": true}
	for _, from := range []string{"new", "confirmed", "delivering", "delivered", "cancelled", "bad"} {
		for _, to := range []string{"new", "confirmed", "delivering", "delivered", "cancelled", "bad"} {
			if CanTransition(from, to) != allowed[from+":"+to] {
				t.Fatal(from, to)
			}
		}
	}
}
func TestIdentity(t *testing.T) {
	if v, e := NormalizeEmail("  Alice@Example.test "); e != nil || v != "alice@example.test" {
		t.Fatal(v, e)
	}
	for _, s := range []string{"not email", "Name <a@example.test>", "a@example.test\r\nb"} {
		if _, e := NormalizeEmail(s); e == nil {
			t.Fatal(s)
		}
	}
	if ValidPassword("short") || ValidPassword(string(make([]byte, 73))) {
		t.Fatal("bad password accepted")
	}
	a := CheckoutInput{CartVersion: 2, Address: " Main street 10 "}
	b, _ := NormalizeCheckout(a)
	a.Address = "Main street 10"
	if Fingerprint(a) != Fingerprint(b) {
		t.Fatal("normalization")
	}
	a.CartVersion++
	if Fingerprint(a) == Fingerprint(b) {
		t.Fatal("version absent")
	}
	if !ValidIdempotencyKey("order-001") || ValidIdempotencyKey("bad key!") {
		t.Fatal("key")
	}
}
