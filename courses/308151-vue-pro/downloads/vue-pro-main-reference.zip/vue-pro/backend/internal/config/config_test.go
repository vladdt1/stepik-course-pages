package config

import (
	"strings"
	"testing"
)

func TestLoad(t *testing.T) {
	for _, tc := range []struct {
		k, v string
		ok   bool
	}{{"CORS_ORIGIN", "https://example.test", true}, {"CORS_ORIGIN", "https://example.test/path", false}, {"CORS_ORIGIN", "*", false}, {"HTTP_ADDR", ":0", false}, {"HTTP_ADDR", ":8080", true}, {"SESSION_TTL", "4m", false}, {"COOKIE_SECURE", "1", false}, {"COOKIE_SECURE", "true", true}} {
		m := map[string]string{"DATABASE_URL": "private-test-value", tc.k: tc.v}
		_, e := Load(func(k string) (string, bool) { v, ok := m[k]; return v, ok })
		if (e == nil) != tc.ok {
			t.Fatal(tc, e)
		}
		if e != nil && strings.Contains(e.Error(), "private-test-value") {
			t.Fatal("secret leaked")
		}
	}
}
