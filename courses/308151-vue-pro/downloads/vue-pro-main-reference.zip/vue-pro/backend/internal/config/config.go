package config

import (
	"errors"
	"net"
	"net/url"
	"strconv"
	"strings"
	"time"
)

type Config struct {
	DatabaseURL     string
	HTTPAddr        string
	Origin          string
	SessionTTL      time.Duration
	ShutdownTimeout time.Duration
	CookieSecure    bool
}

func Load(getenv func(string) (string, bool)) (Config, error) {
	c := Config{HTTPAddr: ":8080", Origin: "http://localhost:5173", SessionTTL: 24 * time.Hour, ShutdownTimeout: 5 * time.Second}
	c.DatabaseURL, _ = getenv("DATABASE_URL")
	if strings.TrimSpace(c.DatabaseURL) == "" {
		return Config{}, errors.New("DATABASE_URL is required")
	}
	if v, ok := getenv("HTTP_ADDR"); ok {
		_, port, e := net.SplitHostPort(v)
		n, pe := strconv.Atoi(port)
		if strings.TrimSpace(v) == "" || e != nil || pe != nil || n < 1 || n > 65535 {
			return Config{}, errors.New("HTTP_ADDR is empty")
		}
		c.HTTPAddr = v
	}
	if v, ok := getenv("CORS_ORIGIN"); ok {
		u, e := url.Parse(v)
		if e != nil || u.Host == "" || (u.Scheme != "http" && u.Scheme != "https") || u.User != nil || u.Path != "" || u.RawQuery != "" || u.Fragment != "" || v == "" || v == "*" || strings.ContainsAny(v, "\r\n") || strings.HasSuffix(v, "/") {
			return Config{}, errors.New("CORS_ORIGIN must be one origin without a trailing slash")
		}
		c.Origin = v
	}
	if v, ok := getenv("SESSION_TTL"); ok {
		d, e := time.ParseDuration(v)
		if e != nil || d < 5*time.Minute || d > 7*24*time.Hour {
			return Config{}, errors.New("SESSION_TTL must be between 5m and 168h")
		}
		c.SessionTTL = d
	}
	if v, ok := getenv("COOKIE_SECURE"); ok {
		if v != "true" && v != "false" {
			return Config{}, errors.New("COOKIE_SECURE must be true or false")
		}
		c.CookieSecure, _ = strconv.ParseBool(v)
	}
	return c, nil
}
