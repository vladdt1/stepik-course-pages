package httpapi

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"example.com/go-delivery/internal/domain"
	"net/http"
	"time"
)

type ctxKey int

const (
	requestKey ctxKey = iota
	userKey
)

func requestID(r *http.Request) string  { s, _ := r.Context().Value(requestKey).(string); return s }
func actor(r *http.Request) domain.User { u, _ := r.Context().Value(userKey).(domain.User); return u }

type statusWriter struct {
	http.ResponseWriter
	status int
}

func (w *statusWriter) WriteHeader(status int) {
	if w.status != 0 {
		return
	}
	w.status = status
	w.ResponseWriter.WriteHeader(status)
}
func (w *statusWriter) Write(data []byte) (int, error) {
	if w.status == 0 {
		w.WriteHeader(200)
	}
	return w.ResponseWriter.Write(data)
}
func (w *statusWriter) Unwrap() http.ResponseWriter { return w.ResponseWriter }
func (a *API) observed(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		data := make([]byte, 12)
		_, err := rand.Read(data)
		if err != nil {
			http.Error(w, "request id unavailable", 500)
			return
		}
		id := hex.EncodeToString(data)
		w.Header().Set("X-Request-ID", id)
		r = r.WithContext(context.WithValue(r.Context(), requestKey, id))
		start := time.Now()
		sw := &statusWriter{ResponseWriter: w}
		defer func() {
			if p := recover(); p != nil {
				a.Log.Error("panic", "request_id", id)
				if sw.status == 0 {
					errorResponse(sw, r, 500, "internal_error", "Не удалось выполнить запрос.")
				}
			}
			status := sw.status
			if status == 0 {
				status = 200
			}
			a.Log.Info("http_request", "request_id", id, "method", r.Method, "path", r.URL.Path, "status", status, "duration_ms", time.Since(start).Milliseconds())
		}()
		next.ServeHTTP(sw, r)
	})
}
func (a *API) cors(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		origin := r.Header.Get("Origin")
		if origin != "" {
			w.Header().Add("Vary", "Origin")
			if origin != a.Config.Origin {
				errorResponse(w, r, 403, "origin_denied", "Этот источник запроса не разрешён.")
				return
			}
			w.Header().Set("Access-Control-Allow-Origin", origin)
			w.Header().Set("Access-Control-Allow-Credentials", "true")
			w.Header().Set("Access-Control-Expose-Headers", "X-Request-ID, Idempotency-Replayed")
		}
		if r.Method == http.MethodOptions {
			if origin == "" {
				errorResponse(w, r, 400, "invalid_preflight", "Для предварительного запроса нужен Origin.")
				return
			}
			w.Header().Set("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, OPTIONS")
			w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Idempotency-Key")
			w.WriteHeader(204)
			return
		}
		next.ServeHTTP(w, r)
	})
}
func (a *API) protected(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		c, err := r.Cookie("delivery_session")
		if err != nil {
			a.fail(w, r, domain.ErrUnauthorized)
			return
		}
		u, err := a.Service.Authenticate(r.Context(), c.Value)
		if err != nil {
			a.fail(w, r, err)
			return
		}
		next(w, r.WithContext(context.WithValue(r.Context(), userKey, u)))
	}
}
