package httpapi

import (
	"context"
	"database/sql"
	"example.com/go-delivery/internal/config"
	"example.com/go-delivery/internal/domain"
	"example.com/go-delivery/internal/service"
	"example.com/go-delivery/internal/store"
	"log/slog"
	"net/http"
	"strconv"
	"time"
)

type API struct {
	Service *service.Service
	DB      *sql.DB
	Config  config.Config
	Log     *slog.Logger
}

func (a *API) Handler() http.Handler {
	m := http.NewServeMux()
	m.HandleFunc("GET /health", func(w http.ResponseWriter, r *http.Request) { writeJSON(w, 200, map[string]string{"status": "ok"}) })
	m.HandleFunc("GET /ready", func(w http.ResponseWriter, r *http.Request) {
		ctx, cancel := context.WithTimeout(r.Context(), 2*time.Second)
		defer cancel()
		if err := a.DB.PingContext(ctx); err != nil {
			errorResponse(w, r, 503, "not_ready", "База пока недоступна.")
			return
		}
		writeJSON(w, 200, map[string]string{"status": "ready"})
	})
	m.HandleFunc("GET /api/v1/catalog/categories", func(w http.ResponseWriter, r *http.Request) {
		v, e := a.Service.Repo.Categories(r.Context())
		if e != nil {
			a.fail(w, r, e)
			return
		}
		writeJSON(w, 200, map[string]any{"items": v})
	})
	m.HandleFunc("GET /api/v1/catalog/products", a.products)
	m.HandleFunc("GET /api/v1/catalog/products/{id}", func(w http.ResponseWriter, r *http.Request) {
		id, e := pathID(r)
		if e != nil {
			a.fail(w, r, e)
			return
		}
		v, e := a.Service.Repo.Product(r.Context(), id)
		if e != nil {
			a.fail(w, r, e)
			return
		}
		writeJSON(w, 200, v)
	})
	m.HandleFunc("POST /api/v1/auth/register", a.register)
	m.HandleFunc("POST /api/v1/auth/login", a.login)
	m.HandleFunc("POST /api/v1/auth/logout", a.logout)
	m.HandleFunc("GET /api/v1/auth/me", a.protected(func(w http.ResponseWriter, r *http.Request) { writeJSON(w, 200, actor(r)) }))
	m.HandleFunc("GET /api/v1/cart", a.protected(a.getCart))
	m.HandleFunc("PUT /api/v1/cart", a.protected(a.putCart))
	m.HandleFunc("POST /api/v1/orders", a.protected(a.checkout))
	m.HandleFunc("GET /api/v1/orders", a.protected(func(w http.ResponseWriter, r *http.Request) { a.orders(w, r, false) }))
	m.HandleFunc("GET /api/v1/orders/{id}", a.protected(a.order))
	m.HandleFunc("PATCH /api/v1/orders/{id}/status", a.protected(a.status))
	m.HandleFunc("GET /api/v1/admin/orders", a.protected(func(w http.ResponseWriter, r *http.Request) { a.orders(w, r, true) }))
	for path, allow := range map[string]string{
		"/health": "GET", "/ready": "GET", "/api/v1/catalog/categories": "GET", "/api/v1/catalog/products": "GET", "/api/v1/catalog/products/{id}": "GET",
		"/api/v1/auth/register": "POST", "/api/v1/auth/login": "POST", "/api/v1/auth/logout": "POST", "/api/v1/auth/me": "GET",
		"/api/v1/cart": "GET, PUT", "/api/v1/orders": "GET, POST", "/api/v1/orders/{id}": "GET", "/api/v1/orders/{id}/status": "PATCH", "/api/v1/admin/orders": "GET",
	} {
		m.HandleFunc(path, func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Allow", allow)
			errorResponse(w, r, 405, "method_not_allowed", "Метод не поддерживается.")
		})
	}
	m.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		errorResponse(w, r, 404, "not_found", "Маршрут не найден.")
	})
	return a.observed(a.cors(m))
}
func pathID(r *http.Request) (int64, error) {
	v, e := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if e != nil || v < 1 {
		return 0, domain.ErrInvalid
	}
	return v, nil
}
func number(r *http.Request, key string, def int64) (int64, error) {
	v := r.URL.Query().Get(key)
	if v == "" {
		return def, nil
	}
	n, e := strconv.ParseInt(v, 10, 64)
	if e != nil {
		return 0, domain.ErrInvalid
	}
	return n, nil
}
func (a *API) products(w http.ResponseWriter, r *http.Request) {
	category, e := number(r, "category_id", 0)
	if e != nil {
		a.fail(w, r, e)
		return
	}
	after, e := number(r, "after_id", 0)
	if e != nil {
		a.fail(w, r, e)
		return
	}
	limit, e := number(r, "limit", 20)
	if e != nil || limit < 1 || limit > 50 {
		a.fail(w, r, domain.ErrInvalid)
		return
	}
	v, e := a.Service.Products(r.Context(), store.CatalogFilter{CategoryID: category, AfterID: after, Search: r.URL.Query().Get("search"), Limit: int(limit)})
	if e != nil {
		a.fail(w, r, e)
		return
	}
	writeJSON(w, 200, v)
}

type credentials struct {
	Email    string `json:"email"`
	Password string `json:"password"`
}

func (a *API) register(w http.ResponseWriter, r *http.Request) {
	var in credentials
	if e := DecodeJSON(w, r, &in); e != nil {
		a.fail(w, r, e)
		return
	}
	u, e := a.Service.Register(r.Context(), in.Email, in.Password)
	if e != nil {
		a.fail(w, r, e)
		return
	}
	writeJSON(w, 201, u)
}
func (a *API) cookie(w http.ResponseWriter, value string, maxAge int) {
	http.SetCookie(w, &http.Cookie{Name: "delivery_session", Value: value, Path: "/", HttpOnly: true, Secure: a.Config.CookieSecure, SameSite: http.SameSiteLaxMode, MaxAge: maxAge})
}
func (a *API) login(w http.ResponseWriter, r *http.Request) {
	var in credentials
	if e := DecodeJSON(w, r, &in); e != nil {
		a.fail(w, r, e)
		return
	}
	u, token, e := a.Service.Login(r.Context(), in.Email, in.Password)
	if e != nil {
		a.fail(w, r, e)
		return
	}
	a.cookie(w, token, int(a.Config.SessionTTL.Seconds()))
	writeJSON(w, 200, u)
}
func (a *API) logout(w http.ResponseWriter, r *http.Request) {
	if c, e := r.Cookie("delivery_session"); e == nil {
		if e = a.Service.Logout(r.Context(), c.Value); e != nil {
			a.fail(w, r, e)
			return
		}
	}
	a.cookie(w, "", -1)
	w.WriteHeader(204)
}
func (a *API) getCart(w http.ResponseWriter, r *http.Request) {
	v, e := a.Service.Repo.Cart(r.Context(), actor(r).ID)
	if e != nil {
		a.fail(w, r, e)
		return
	}
	writeJSON(w, 200, v)
}
func (a *API) putCart(w http.ResponseWriter, r *http.Request) {
	var in domain.CartInput
	if e := DecodeJSON(w, r, &in); e != nil {
		a.fail(w, r, e)
		return
	}
	if in.Items == nil {
		a.fail(w, r, domain.ErrInvalid)
		return
	}
	v, e := a.Service.UpdateCart(r.Context(), actor(r).ID, in)
	if e != nil {
		a.fail(w, r, e)
		return
	}
	writeJSON(w, 200, v)
}
func (a *API) checkout(w http.ResponseWriter, r *http.Request) {
	var in domain.CheckoutInput
	if e := DecodeJSON(w, r, &in); e != nil {
		a.fail(w, r, e)
		return
	}
	v, replay, e := a.Service.Checkout(r.Context(), actor(r).ID, r.Header.Get("Idempotency-Key"), in)
	if e != nil {
		a.fail(w, r, e)
		return
	}
	status := 201
	if replay {
		status = 200
		w.Header().Set("Idempotency-Replayed", "true")
	}
	writeJSON(w, status, v)
}
func (a *API) orders(w http.ResponseWriter, r *http.Request, admin bool) {
	before, e := number(r, "before_id", 0)
	if e != nil {
		a.fail(w, r, e)
		return
	}
	limit, e := number(r, "limit", 20)
	if e != nil || limit < 1 || limit > 50 {
		a.fail(w, r, domain.ErrInvalid)
		return
	}
	v, e := a.Service.ListOrders(r.Context(), actor(r), admin, store.OrderFilter{BeforeID: before, Limit: int(limit), Status: r.URL.Query().Get("status")})
	if e != nil {
		a.fail(w, r, e)
		return
	}
	writeJSON(w, 200, v)
}
func (a *API) order(w http.ResponseWriter, r *http.Request) {
	id, e := pathID(r)
	if e != nil {
		a.fail(w, r, e)
		return
	}
	v, e := a.Service.Repo.Order(r.Context(), id, actor(r))
	if e != nil {
		a.fail(w, r, e)
		return
	}
	writeJSON(w, 200, v)
}
func (a *API) status(w http.ResponseWriter, r *http.Request) {
	id, e := pathID(r)
	if e != nil {
		a.fail(w, r, e)
		return
	}
	var in struct {
		Version int64  `json:"version"`
		Status  string `json:"status"`
	}
	if e = DecodeJSON(w, r, &in); e != nil {
		a.fail(w, r, e)
		return
	}
	v, e := a.Service.ChangeStatus(r.Context(), actor(r), id, in.Version, in.Status)
	if e != nil {
		a.fail(w, r, e)
		return
	}
	writeJSON(w, 200, v)
}
