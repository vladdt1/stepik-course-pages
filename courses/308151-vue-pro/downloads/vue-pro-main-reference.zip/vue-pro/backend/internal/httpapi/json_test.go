package httpapi

import (
	"net/http/httptest"
	"strings"
	"testing"
)

func TestStrictJSON(t *testing.T) {
	for _, body := range []string{`null`, `[]`, `{"quantity":1,"price":1}`, `{"quantity":1} {}`, `{"quantity":"1"}`, strings.Repeat("x", 5000)} {
		r := httptest.NewRequest("POST", "/", strings.NewReader(body))
		r.Header.Set("Content-Type", "application/json")
		var v struct {
			Quantity int `json:"quantity"`
		}
		if DecodeJSON(httptest.NewRecorder(), r, &v) == nil {
			t.Fatalf("accepted %s", body[:min(30, len(body))])
		}
	}
	r := httptest.NewRequest("POST", "/", strings.NewReader(`{"quantity":1}`))
	r.Header.Set("Content-Type", "application/json; charset=utf-8")
	var v struct {
		Quantity int `json:"quantity"`
	}
	if e := DecodeJSON(httptest.NewRecorder(), r, &v); e != nil || v.Quantity != 1 {
		t.Fatal(v, e)
	}
}
