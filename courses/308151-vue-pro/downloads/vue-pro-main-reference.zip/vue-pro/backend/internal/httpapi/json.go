package httpapi

import (
	"bytes"
	"encoding/json"
	"errors"
	"example.com/go-delivery/internal/domain"
	"io"
	"mime"
	"net/http"
)

func DecodeJSON(w http.ResponseWriter, r *http.Request, dst any) error {
	media, _, err := mime.ParseMediaType(r.Header.Get("Content-Type"))
	if err != nil || media != "application/json" {
		return domain.ErrInvalid
	}
	r.Body = http.MaxBytesReader(w, r.Body, 4096)
	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()
	// Decode through a RawMessage first so top-level null is not mistaken for an empty DTO.
	var raw json.RawMessage
	if err = decoder.Decode(&raw); err != nil {
		return domain.ErrInvalid
	}
	if string(raw) == "null" {
		return domain.ErrInvalid
	}
	if err = decoder.Decode(new(any)); err != io.EOF {
		return domain.ErrInvalid
	}
	strict := json.NewDecoder(bytes.NewReader(raw))
	strict.DisallowUnknownFields()
	if err = strict.Decode(dst); err != nil {
		return domain.ErrInvalid
	}
	return nil
}
func writeJSON(w http.ResponseWriter, status int, value any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(value)
}

type errorBody struct {
	Error errorInfo `json:"error"`
}
type errorInfo struct {
	Code      string `json:"code"`
	Message   string `json:"message"`
	RequestID string `json:"request_id"`
}

func errorResponse(w http.ResponseWriter, r *http.Request, status int, code, message string) {
	writeJSON(w, status, errorBody{errorInfo{code, message, requestID(r)}})
}
func (a *API) fail(w http.ResponseWriter, r *http.Request, err error) {
	status, code, message := 500, "internal_error", "Не удалось выполнить запрос."
	switch {
	case errors.Is(err, domain.ErrUnauthorized):
		status, code, message = 401, "unauthorized", "Войдите в аккаунт."
	case errors.Is(err, domain.ErrForbidden):
		status, code, message = 403, "forbidden", "Для этого действия недостаточно прав."
	case errors.Is(err, domain.ErrNotFound):
		status, code, message = 404, "not_found", "Объект не найден."
	case errors.Is(err, domain.ErrCartVersion):
		status, code, message = 409, "cart_version_conflict", "Корзина изменилась. Загрузите её заново."
	case errors.Is(err, domain.ErrOrderVersion):
		status, code, message = 409, "order_version_conflict", "Заказ изменился. Загрузите его заново."
	case errors.Is(err, domain.ErrIdempotency):
		status, code, message = 409, "idempotency_conflict", "Этот ключ уже связан с другой командой."
	case errors.Is(err, domain.ErrStock):
		status, code, message = 409, "insufficient_stock", "Одного из товаров не хватает."
	case errors.Is(err, domain.ErrTransition):
		status, code, message = 409, "invalid_transition", "Такой переход статуса недоступен."
	case errors.Is(err, domain.ErrConflict):
		status, code, message = 409, "conflict", "Запись с такими данными уже существует."
	case errors.Is(err, domain.ErrInvalid):
		status, code, message = 400, "invalid_input", "Проверьте поля, формат и ограничения запроса."
	case errors.Is(err, domain.ErrNotImplemented):
		status, code, message = 501, "learning_todo", "Эта часть заготовки ещё не реализована."
	}
	if status == 500 {
		a.Log.Error("request failed", "request_id", requestID(r), "error", err)
	}
	errorResponse(w, r, status, code, message)
}
