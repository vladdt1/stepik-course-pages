package service

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"errors"
	"strings"
	"time"

	"example.com/go-delivery/internal/domain"
	"example.com/go-delivery/internal/store"
	"golang.org/x/crypto/bcrypt"
)

type Repository interface {
	Categories(context.Context) ([]domain.Category, error)
	Catalog(context.Context, store.CatalogFilter) (store.CatalogPage, error)
	Product(context.Context, int64) (domain.Product, error)
	CreateUser(context.Context, string, string) (domain.User, error)
	AuthByEmail(context.Context, string) (store.AuthRecord, error)
	SaveSession(context.Context, int64, string, time.Time) error
	SessionUser(context.Context, string) (domain.User, error)
	DeleteSession(context.Context, string) error
	Cart(context.Context, int64) (domain.Cart, error)
	ReplaceCart(context.Context, int64, domain.CartInput) (domain.Cart, error)
	Checkout(context.Context, int64, string, string, domain.CheckoutInput) (domain.Order, bool, error)
	Order(context.Context, int64, domain.User) (domain.Order, error)
	Orders(context.Context, store.OrderFilter) (store.OrdersPage, error)
	ChangeStatus(context.Context, int64, int64, domain.User, string) (domain.Order, error)
}
type Service struct {
	Repo       Repository
	SessionTTL time.Duration
}

func (s *Service) Register(ctx context.Context, email, password string) (domain.User, error) {
	email, err := domain.NormalizeEmail(email)
	if err != nil || !domain.ValidPassword(password) {
		return domain.User{}, domain.ErrInvalid
	}
	hash, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return domain.User{}, err
	}
	return s.Repo.CreateUser(ctx, email, string(hash))
}
func TokenHash(token string) string {
	sum := sha256.Sum256([]byte(token))
	return hex.EncodeToString(sum[:])
}
func (s *Service) Login(ctx context.Context, email, password string) (domain.User, string, error) {
	email, err := domain.NormalizeEmail(email)
	if err != nil || len(password) > 72 {
		return domain.User{}, "", domain.ErrUnauthorized
	}
	record, err := s.Repo.AuthByEmail(ctx, email)
	if errors.Is(err, domain.ErrNotFound) {
		return domain.User{}, "", domain.ErrUnauthorized
	}
	if err != nil {
		return domain.User{}, "", err
	}
	if bcrypt.CompareHashAndPassword([]byte(record.PasswordHash), []byte(password)) != nil {
		return domain.User{}, "", domain.ErrUnauthorized
	}
	data := make([]byte, 32)
	if _, err = rand.Read(data); err != nil {
		return domain.User{}, "", err
	}
	token := base64.RawURLEncoding.EncodeToString(data)
	if err = s.Repo.SaveSession(ctx, record.User.ID, TokenHash(token), time.Now().UTC().Add(s.SessionTTL)); err != nil {
		return domain.User{}, "", err
	}
	return record.User, token, nil
}
func (s *Service) Authenticate(ctx context.Context, token string) (domain.User, error) {
	if len(token) != 43 {
		return domain.User{}, domain.ErrUnauthorized
	}
	u, err := s.Repo.SessionUser(ctx, TokenHash(token))
	if errors.Is(err, domain.ErrNotFound) {
		return domain.User{}, domain.ErrUnauthorized
	}
	return u, err
}
func (s *Service) Logout(ctx context.Context, token string) error {
	if token == "" {
		return nil
	}
	return s.Repo.DeleteSession(ctx, TokenHash(token))
}
func (s *Service) Checkout(ctx context.Context, userID int64, key string, in domain.CheckoutInput) (domain.Order, bool, error) {
	normalized, err := domain.NormalizeCheckout(in)
	if err != nil || !domain.ValidIdempotencyKey(key) {
		return domain.Order{}, false, domain.ErrInvalid
	}
	return s.Repo.Checkout(ctx, userID, key, domain.Fingerprint(normalized), normalized)
}
func (s *Service) UpdateCart(ctx context.Context, userID int64, in domain.CartInput) (domain.Cart, error) {
	items, err := domain.NormalizeItems(in.Items)
	if err != nil || in.Version < 1 {
		return domain.Cart{}, domain.ErrInvalid
	}
	in.Items = items
	return s.Repo.ReplaceCart(ctx, userID, in)
}
func (s *Service) Products(ctx context.Context, f store.CatalogFilter) (store.CatalogPage, error) {
	f.Search = strings.TrimSpace(f.Search)
	if f.CategoryID < 0 || f.AfterID < 0 || f.Limit < 1 || f.Limit > 50 || len([]rune(f.Search)) > 100 {
		return store.CatalogPage{}, domain.ErrInvalid
	}
	return s.Repo.Catalog(ctx, f)
}
func (s *Service) ListOrders(ctx context.Context, actor domain.User, admin bool, f store.OrderFilter) (store.OrdersPage, error) {
	if f.BeforeID < 0 || f.Limit < 1 || f.Limit > 50 || f.Status != "" && !domain.KnownStatus(f.Status) {
		return store.OrdersPage{}, domain.ErrInvalid
	}
	if admin {
		if actor.Role != "operator" {
			return store.OrdersPage{}, domain.ErrForbidden
		}
		f.UserID = 0
	} else {
		f.UserID = actor.ID
	}
	return s.Repo.Orders(ctx, f)
}
func (s *Service) ChangeStatus(ctx context.Context, actor domain.User, id, version int64, next string) (domain.Order, error) {
	if id < 1 || version < 1 || !domain.KnownStatus(next) {
		return domain.Order{}, domain.ErrInvalid
	}
	return s.Repo.ChangeStatus(ctx, id, version, actor, next)
}
