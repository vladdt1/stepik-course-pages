# Этапы самостоятельной сборки

Работайте в starter. Десять TODO находятся в функциях ниже. Остальная инфраструктура готова, её нужно прочитать и использовать. Тесты заготовки изначально показывают недостающие правила; не удаляйте ассерты ради зелёного цвета. Все обязательные требования перечислены здесь и в README. После изменения кода пересобирайте контейнер api. Изолированные задачи Stepik не подключены автоматически к этому проекту.

## 1. Требования и правила

`internal/domain/domain.go`: TODO NormalizeItems и BuildDraft.
NormalizeItems: до40 исходных строк; положительный ProductID; Quantity1–100; объединение одинаковых ID; после объединения не больше100 каждого товара и20 различных товаров; сортировка по ID; [] разрешён и возвращается непустым по типу (не nil) срезом длины0. Вход не модифицируйте. Ошибка ErrInvalid.
BuildDraft:1–20 строк; active=true; Product.Price0–100000000; Quantity1–100; при недостатке stock ErrStock; остальные нарушения ErrInvalid. Формирует OrderItem со снимком названия/цены, subtotal, доставку14900 при subtotal<100000 и0 иначе, total. Пустой заказ запрещён. Возвращать частичный успешный результат при ошибке нельзя.
Проверка: `go test ./internal/domain -run 'TestNormalizeItems|TestBuildDraft|TestDeliveryBoundary' -v`. Добавьте крайние случаи повторов и пустоты.

## 2. Структура и схема

Прочитайте compose.yaml, 001_schema.sql,002_indexes.sql, migrations.Apply. `docker compose up --build -d`, `ps -a`, `logs migrate`. /health и /ready работают до реализации прикладных TODO. Повторный migrate не дублирует версии/данные. Seed не перезаписывает stock существующих товаров. Здесь TODO нет: задача — воспроизводимый запуск и понимание связей.

## 3. HTTP и каталог

`internal/httpapi/json.go`: TODO DecodeJSON. Content-Type application/json (параметр charset допустим), тело≤4096байт, ровно одно JSON-значение, не null; DisallowUnknownFields; несоответствие типа/формата →ErrInvalid. Тело разбирается в переданную структуру dst. Используйте уже импортируемые стандартные пакеты. `go test ./internal/httpapi -v`.
`internal/store/postgres.go`: TODO Catalog. Параметризованный SELECT активных товаров id>AfterID, категория0 означает отсутствие фильтра, Search — буквальная подстрока без учёта регистра, порядок id ASC. Читать Limit+1, возвращать не большеLimit; если есть продолжение, NextCursor=ID последнего возвращённого, иначе0. Items не nil. Корректные QueryContext, Scan, Close, rows.Err. Проверка параметров находится в service.Products. Ручная проверка категорий, поиска, пустого результата и двух страниц.

## 4. Регистрация и вход

`internal/service/service.go`: TODO Register и Login. Register использует NormalizeEmail и ValidPassword, bcrypt.DefaultCost, затем Repo.CreateUser. Login нормализует email, длина password≤72байт; отсутствующий пользователь/неверный пароль →ErrUnauthorized без раскрытия причины, прочие ошибки не скрывать. Сравнить bcrypt-хеш, получить32 криптографически случайных байта, base64.RawURLEncoding, сохранить SHA256 токена через TokenHash и Repo.SaveSession со сроком now.UTC()+SessionTTL. Вернуть User и исходный токен. Cookie устанавливает готовый обработчик; Authenticate/Logout готовы. role не принимается от клиента.
Проверки интеграции: регистрация, дубль email с другим регистром, неправильный пароль, token_hash не равен cookie, /me, logout, срок сессии, чужие заказы.

## 5. Корзина

`internal/store/postgres.go`: TODO ReplaceCart. Нормализуйте позиции и проверьте Version≥1. BeginTx→defer Rollback→lockCart→сравнение version. Под блокировкой: проверить существование и active всех товаров; неверный товар →ErrInvalid; только после всех проверок DELETE прежнего набора/INSERT нового, version+1; readCart(ctx,tx,userID), Commit. Пустой список очищает корзину, но не удаляет строку carts. Остатки не резервируются. Все SQL изменения через tx, не DB.
После отказа GET/cart должен вернуть прежние позиции и версию. Две замены с исходной version: один успех и ErrCartVersion. Перезапуск сохраняет корзину.

## 6. Checkout

`internal/store/postgres.go`: TODO Checkout. Service уже нормализовал вход и вычислил fingerprint.
1. BeginTx, Rollback, блокировка carts данного пользователя через lockCart.
2. Найти существующий order по user_id+key. Совпавший fingerprint →readOrder через tx, Commit, replay=true; другой →ErrIdempotency. Проверять раньше version, потому что успешный первый запрос уже изменил корзину.
3. Сравнить cart version с in.CartVersion →ErrCartVersion.
4. Загрузить cart_items JOIN products, ORDER BY p.id FOR UPDATE OF p; собрать []DraftLine. Закрыть rows до следующего запроса. BuildDraft проверяет наличие и считает сумму.
5. INSERT orders status=new, суммы, адрес/комментарий, key,fingerprint RETURNING id. INSERT снимков order_items; уменьшить stock; INSERT order_events new; DELETE cart_items; carts.version+1. Все действия через tx.
6. readOrder внутри tx, Commit; вернуть Order,replay=false. Любая ошибка возвращается и откатывает всё. Новая транзакция следующего запроса видит уже изменённые остатки.

Сохранённые уникальные ключи принадлежат пользователю. Повтор возвращает текущее состояние существующего заказа, не создавая новый. Новый заказ — новая корзина и новый ключ. Нельзя сбрасывать таблицу ключей при рестарте.

## 7. Статусы и оператор

`internal/domain/domain.go`: TODO CanTransition. Только new→confirmed/cancelled,confirmed→delivering/cancelled,delivering→delivered; самопереходы, неизвестные, исходные final запрещены.
`internal/store/postgres.go`: TODO ChangeStatus. BeginTx/lock orders FOR UPDATE; чужой покупателю →ErrNotFound; покупателю переход кроме cancelled→ErrForbidden; version mismatch→ErrOrderVersion; запрет графа→ErrTransition. Для отмены прочитать order_items по product_id, вернуть остатки через tx. UPDATE status,version+1 и INSERT event(actor.ID) атомарно; readOrder, Commit. Повторная отмена не меняет остатки. Права проверять до раскрытия текущего состояния.
Проверка роли customer/operator, всех пар графа, stale version, чужого заказа, истории и единственного возврата stock.

## 8. Настройки и будущий браузер

Готовые config/middleware прочитайте и проверьте. DATABASE_URL обязателен, CORS_ORIGIN точный origin без пути, SESSION_TTL5m–168h, COOKIE_SECURE строгий bool. /health не ходит в БД, /ready делает PingContext. Shutdown с новым timeout-context5s. Cookie HttpOnly/SameSite=Lax; локальный HTTP Secure=false. CORS с credentials и одним origin; OPTIONS до проверки сессии. JSON-ошибки стабильны, request_id совпадает с логом. Не печатать токены/пароли/полный Config.

## 9. Тесты и итог

Unit: `go test ./...`; `go vet ./...`; `go test -race ./...`.
Отдельная одноразовая БД delivery_test: `go test -race -tags integration ./...` с TEST_DATABASE_URL по README. Тест очищает таблицы именно указанной БД! Интеграционный набор проверяет реальные SQL/блокировки/rollback, а не только fake.

Приёмка: каталог→регистрация→вход→корзина→заказ→повтор без дубля→GET; два покупателя изолированы; оператор подтверждает и завершает; отмена возвращает stock один раз; старый заказ сохраняет цену; конфликт не меняет данные; два checkout на последний товар дают один успех; перезапуск сохраняет всё. Все10 TODO заполнены. После этого сверка с reference, затем отдельный этап Vue.
