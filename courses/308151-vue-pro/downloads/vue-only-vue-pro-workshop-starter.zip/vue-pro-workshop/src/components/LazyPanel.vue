<script setup>
defineProps({loader:{type:Function,required:true}})
// E13–E14: асинхронный компонент с состояниями.
</script><template><p>TODO: панель</p></template>
