<script setup>
// E09: предоставьте реактивный контекст по venueKey.
</script><template><slot/></template>
