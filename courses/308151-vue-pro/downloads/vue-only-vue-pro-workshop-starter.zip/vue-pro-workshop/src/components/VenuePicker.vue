<script setup>
// E09–E10: получите контекст; обработайте отсутствие.
</script><template><p>TODO: выбор площадки</p></template>
