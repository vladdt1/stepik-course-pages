<script setup>
import {ref} from 'vue'
defineProps({load:{type:Function,required:true}})
const query=ref('')
// E12: запускайте загрузку и освобождайте устаревший запрос.
</script><template><input v-model="query" aria-label="Поиск"><p role="status">Ожидание</p><p data-testid="result"></p></template>
