<script setup>
import {ref} from 'vue'
import TabDraft from './TabDraft.vue'
const active=ref(true)
// E11: сохраните экземпляр редактора между вкладками.
</script><template><button @click="active=!active">Переключить вкладку</button><TabDraft v-if="active"/><p v-else>Список событий</p></template>
