<template><main><h1>Встречаемся</h1><p>Соберите интерфейс по PROJECT.md. Начните с каталога.</p></main></template>
