// Готовая локальная модель HTTP-контракта для практики Vue. Серверное программирование не входит в курс.
import http from 'node:http'
import {randomUUID,scryptSync,timingSafeEqual} from 'node:crypto'
import {readFileSync,writeFileSync,existsSync,mkdirSync} from 'node:fs'
import path from 'node:path'
import {fileURLToPath} from 'node:url'
const here=path.dirname(fileURLToPath(import.meta.url))
const categories=[{id:1,name:'Горячее'},{id:2,name:'Напитки'}]
const products=[{id:1,category_id:1,name:'Томатный суп',description:'Порция 350 г',price_cents:35000,stock:1000,active:true},{id:2,category_id:2,name:'Чай',description:'Чёрный чай, 300 мл',price_cents:9000,stock:1000,active:true},{id:3,category_id:1,name:'Овощной салат',description:'Порция 250 г',price_cents:28000,stock:1000,active:true},{id:4,category_id:1,name:'Пицца',description:'Сырная пицца, 30 см',price_cents:65000,stock:1000,active:true}]
function passwordHash(value,salt){return scryptSync(value,salt,32).toString('hex')}
function fresh(){const salt=randomUUID();return {users:[{id:1,email:'operator@example.test',role:'operator',salt,hash:passwordHash('StudyOperator123!',salt)}],sessions:{},carts:{},orders:[],replays:{},products:structuredClone(products)}}
export function createStudyServer({dataFile=null,staticRoot=null}={}){
 let state=fresh();if(dataFile&&existsSync(dataFile))state=JSON.parse(readFileSync(dataFile,'utf8'))
 function save(){if(dataFile){mkdirSync(path.dirname(dataFile),{recursive:true});writeFileSync(dataFile,JSON.stringify(state),{mode:0o600})}}
 const publicUser=u=>({id:u.id,email:u.email,role:u.role})
 const fail=(status,code,message)=>{throw Object.assign(new Error(message),{status,code})}
 function cartFor(uid){if(!state.carts[uid])state.carts[uid]={version:1,items:[]};return state.carts[uid]}
 function cartView(cart){const items=cart.items.map(i=>{const p=state.products.find(p=>p.id===i.product_id);return {...i,name:p.name,unit_price_cents:p.price_cents,line_total_cents:p.price_cents*i.quantity,available:p.active&&p.stock>=i.quantity}});return {version:cart.version,items,subtotal_cents:items.reduce((n,i)=>n+i.line_total_cents,0)}}
 return http.createServer(async(req,res)=>{
 const requestId=randomUUID();res.setHeader('X-Request-ID',requestId);res.once('finish',()=>console.log(JSON.stringify({request_id:requestId,method:req.method,path:req.url.split('?')[0],status:res.statusCode})))
 const origin=req.headers.origin;if(origin&&/^http:\/\/(localhost|127\.0\.0\.1):(5173|8088)$/.test(origin)){res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Access-Control-Allow-Credentials','true');res.setHeader('Vary','Origin');res.setHeader('Access-Control-Expose-Headers','X-Request-ID, Idempotency-Replayed')}
 const send=(status,data)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(status===204?'':JSON.stringify(data))}
 try{
  if(req.method==='OPTIONS'){res.setHeader('Access-Control-Allow-Headers','Content-Type, Idempotency-Key');res.setHeader('Access-Control-Allow-Methods','GET, POST, PUT, PATCH, OPTIONS');return send(204)}
  const url=new URL(req.url,'http://study.local'),p=url.pathname,m=req.method
  if(p==='/health'||p==='/ready')return send(200,{status:'ok'})
  let data={};if(['POST','PUT','PATCH'].includes(m)){let raw='';for await(const chunk of req){raw+=chunk;if(raw.length>65536)fail(413,'invalid_input','Слишком большой запрос.')}if(raw){try{data=JSON.parse(raw)}catch{fail(400,'invalid_input','Проверьте JSON.')}}}
  if(m==='GET'&&p==='/api/v1/catalog/categories')return send(200,{items:categories})
  if(m==='GET'&&p==='/api/v1/catalog/products'){
   const limit=Number(url.searchParams.get('limit')||20),after=Number(url.searchParams.get('after_id')||0),category=Number(url.searchParams.get('category_id')||0),search=(url.searchParams.get('search')||'').trim().toLowerCase();if(!Number.isInteger(limit)||limit<1||limit>50)fail(400,'invalid_input','Проверьте параметры списка.')
   const all=state.products.filter(x=>x.active&&x.id>after&&(!category||x.category_id===category)&&x.name.toLowerCase().includes(search)),items=all.slice(0,limit);return send(200,{items,next_cursor:all.length>limit?items.at(-1).id:0})
  }
  const product=p.match(/^\/api\/v1\/catalog\/products\/(\d+)$/)
  if(m==='GET'&&product){const item=state.products.find(x=>x.id===Number(product[1]));if(!item)fail(404,'not_found','Объект не найден.');return send(200,item)}
  if(m==='POST'&&p==='/api/v1/auth/register'){
   const email=String(data.email||'').trim().toLowerCase(),password=String(data.password||'');if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||[...password].length<8||Buffer.byteLength(password)>72)fail(400,'invalid_input','Проверьте email и пароль.')
   if(state.users.some(u=>u.email===email))fail(409,'email_taken','Этот email уже используется.')
   const salt=randomUUID(),user={id:Math.max(...state.users.map(u=>u.id))+1,email,role:'customer',salt,hash:passwordHash(password,salt)};state.users.push(user);save();return send(201,publicUser(user))
  }
  if(m==='POST'&&p==='/api/v1/auth/login'){
   const u=state.users.find(u=>u.email===String(data.email||'').trim().toLowerCase());if(!u||!timingSafeEqual(Buffer.from(u.hash,'hex'),Buffer.from(passwordHash(String(data.password||''),u.salt),'hex')))fail(401,'unauthorized','Проверьте email и пароль.')
   const token=randomUUID();state.sessions[token]=u.id;save();res.setHeader('Set-Cookie',`delivery_session=${token}; HttpOnly; SameSite=Lax; Path=/`);return send(200,publicUser(u))
  }
  const token=(req.headers.cookie||'').match(/(?:^|;\s*)delivery_session=([^;]+)/)?.[1];const user=state.users.find(u=>u.id===state.sessions[token])
  if(m==='POST'&&p==='/api/v1/auth/logout'){delete state.sessions[token];save();res.setHeader('Set-Cookie','delivery_session=; Max-Age=0; HttpOnly; SameSite=Lax; Path=/');return send(204)}
  if(p.startsWith('/api/v1/')){
   if(!user)fail(401,'unauthorized','Войдите в аккаунт.')
   if(m==='GET'&&p==='/api/v1/auth/me')return send(200,publicUser(user))
   const cart=cartFor(user.id)
   if(m==='GET'&&p==='/api/v1/cart')return send(200,cartView(cart))
   if(m==='PUT'&&p==='/api/v1/cart'){
    if(data.version!==cart.version)fail(409,'cart_version_conflict','Корзина изменилась. Обновите данные.')
    if(!Array.isArray(data.items)||data.items.length>40)fail(400,'invalid_input','Проверьте состав корзины.')
    const counts=new Map();for(const item of data.items){const product=state.products.find(p=>p.id===item.product_id);if(!product||!product.active||!Number.isInteger(item.quantity)||item.quantity<1||item.quantity>100)fail(400,'invalid_input','Проверьте товар и количество.');counts.set(item.product_id,(counts.get(item.product_id)||0)+item.quantity);if(counts.get(item.product_id)>100||counts.get(item.product_id)>product.stock)fail(409,'insufficient_stock','Недостаточно товара.')}
    if(counts.size>20)fail(400,'invalid_input','Слишком много товаров.');cart.items=[...counts].map(([product_id,quantity])=>({product_id,quantity}));cart.version++;save();return send(200,cartView(cart))
   }
   if(m==='POST'&&p==='/api/v1/orders'){
    const key=req.headers['idempotency-key'];if(!/^[A-Za-z0-9_-]{8,128}$/.test(key||''))fail(400,'invalid_input','Проверьте ключ операции.');const identity=user.id+':'+key;const fingerprint=JSON.stringify(data)
    if(state.replays[identity]){const replay=state.replays[identity];if(replay.fingerprint!==fingerprint)fail(409,'idempotency_conflict','Ключ уже использован для другого запроса.');res.setHeader('Idempotency-Replayed','true');return send(200,state.orders.find(o=>o.id===replay.id))}
    const address=String(data.address||'').trim();if(address.length<10||address.length>300||String(data.comment||'').length>500)fail(400,'invalid_input','Проверьте адрес и комментарий.')
    if(data.cart_version!==cart.version)fail(409,'cart_version_conflict','Корзина изменилась. Обновите данные.');if(!cart.items.length)fail(400,'invalid_input','Корзина пуста.')
    const view=cartView(cart);if(view.items.some(i=>!i.available))fail(409,'insufficient_stock','Недостаточно товара.');const now=new Date().toISOString(),fee=view.subtotal_cents>=100000?0:14900;const order={id:Math.max(0,...state.orders.map(o=>o.id))+1,user_id:user.id,status:'new',version:1,subtotal_cents:view.subtotal_cents,delivery_fee_cents:fee,total_cents:view.subtotal_cents+fee,address,comment:data.comment||'',created_at:now,items:view.items,events:[{status:'new',created_at:now}]};state.orders.push(order);for(const i of cart.items)state.products.find(p=>p.id===i.product_id).stock-=i.quantity;cart.items=[];cart.version++;state.replays[identity]={id:order.id,fingerprint};save();return send(201,order)
   }
   if(m==='GET'&&(p==='/api/v1/orders'||p==='/api/v1/admin/orders')){
    const admin=p.includes('/admin/');if(admin&&user.role!=='operator')fail(403,'forbidden','Недостаточно прав.');const status=url.searchParams.get('status'),before=Number(url.searchParams.get('before_id')||0),limit=Number(url.searchParams.get('limit')||20);const all=state.orders.filter(o=>(admin||o.user_id===user.id)&&(!status||o.status===status)&&(!before||o.id<before)).sort((a,b)=>b.id-a.id),items=all.slice(0,limit);return send(200,{items,next_cursor:all.length>limit?items.at(-1).id:0})
   }
   const match=p.match(/^\/api\/v1\/orders\/(\d+)(\/status)?$/)
   if(match){const order=state.orders.find(o=>o.id===Number(match[1]));if(!order||(user.role!=='operator'&&order.user_id!==user.id))fail(404,'not_found','Объект не найден.')
    if(m==='GET'&&!match[2])return send(200,order)
    if(m==='PATCH'&&match[2]){if(data.version!==order.version)fail(409,'order_version_conflict','Заказ изменился.');const allowed={new:['confirmed','cancelled'],confirmed:['delivering','cancelled'],delivering:['delivered']}[order.status]||[];if(!allowed.includes(data.status)||(user.role!=='operator'&&data.status!=='cancelled'))fail(409,'invalid_transition','Такой переход недоступен.');order.status=data.status;order.version++;order.events.push({status:data.status,created_at:new Date().toISOString()});if(data.status==='cancelled')for(const i of order.items)state.products.find(p=>p.id===i.product_id).stock+=i.quantity;save();return send(200,order)}
   }
   fail(404,'not_found','Маршрут не найден.')
  }
  if(staticRoot&&m==='GET'){
   const root=path.resolve(staticRoot),file=path.resolve(root,'.'+decodeURIComponent(p));if(!file.startsWith(root+path.sep)&&file!==root)fail(404,'not_found','Объект не найден.')
   let target=file;try{if(p.endsWith('/'))target=path.join(root,'index.html');const bytes=readFileSync(target);res.setHeader('Content-Type',({'html':'text/html; charset=utf-8',js:'text/javascript',css:'text/css',svg:'image/svg+xml',png:'image/png'}[target.split('.').pop()])||'application/octet-stream');return res.end(bytes)}catch{res.setHeader('Content-Type','text/html; charset=utf-8');return res.end(readFileSync(path.join(root,'index.html')))}
  }
  fail(404,'not_found','Маршрут не найден.')
 }catch(e){send(e.status||500,{error:{code:e.code||'internal_error',message:e.status?e.message:'Не удалось выполнить запрос.',request_id:requestId}})}
 })
}
if(process.argv[1]===fileURLToPath(import.meta.url)){
 const preview=process.argv.includes('--preview'),port=Number(process.env.PORT||(preview?8088:8082));const server=createStudyServer({dataFile:process.env.STUDY_MEMORY==='1'?null:path.join(here,'.data/state.json'),staticRoot:preview?path.join(here,'../web/dist'):null});server.listen(port,process.env.HOST||'127.0.0.1',()=>console.log('Учебный стенд: http://localhost:'+port))
}
