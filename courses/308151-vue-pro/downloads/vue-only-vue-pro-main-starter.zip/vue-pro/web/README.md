# Vue-клиент

Запуск и Docker описаны в ../README.md. Из web/: npm ci, npm run dev, npm run test:course, npm run test:student, npm run build. Для API запустите npm run api из корня. Изолированные упражнения находятся в ../practice/.
