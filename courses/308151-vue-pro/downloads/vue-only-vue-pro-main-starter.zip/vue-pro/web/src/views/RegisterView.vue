<script setup>
import{ref,reactive}from'vue';import{useRouter}from'vue-router';import{request}from'../lib/api';import{emailError,passwordError}from'../lib/domain';import FormField from'../components/FormField.vue';import NoticeBox from'../components/NoticeBox.vue'
const router=useRouter(),email=ref(''),password=ref(''),pending=ref(false),error=ref(null),errors=reactive({email:'',password:''})
async function submit(){
 // TODO: submit — контракт и проверка в PRACTICE.md.
 error.value = new Error("TODO: регистрация")
}
</script>
<template>
<!-- TODO: RegisterView — соберите интерфейс по контракту PRACTICE.md. -->
<section class="panel"><h1>RegisterView</h1><p>Экран пока не собран.</p></section>
</template>
