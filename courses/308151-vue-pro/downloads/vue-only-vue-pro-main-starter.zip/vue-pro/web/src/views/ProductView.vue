<script setup>
import{ref,watch}from'vue';import{useRoute,useRouter}from'vue-router';import{request}from'../lib/api';import{formatMoney}from'../lib/domain';import{useCartStore}from'../stores/cart';import{useAuthStore}from'../stores/auth';import NoticeBox from'../components/NoticeBox.vue'
const route=useRoute(),router=useRouter(),cart=useCartStore(),auth=useAuthStore(),product=ref(null),error=ref(null),loading=ref(false),notice=ref('')
watch(()=>route.params.id,async(id,old,onCleanup)=>{const controller=new AbortController();onCleanup(()=>controller.abort());loading.value=true;error.value=null;product.value=null;try{product.value=await request('/catalog/products/'+encodeURIComponent(id),{signal:controller.signal})}catch(e){if(e.name!=='AbortError')error.value=e}finally{if(!controller.signal.aborted)loading.value=false}},{immediate:true})
async function add(){
 // TODO: add — контракт и проверка в PRACTICE.md.
 error.value = new Error("TODO: выбор товара")
}
</script>
<template>
<!-- TODO: ProductView — соберите интерфейс по контракту PRACTICE.md. -->
<section class="panel"><h1>ProductView</h1><p>Экран пока не собран.</p></section>
</template>
