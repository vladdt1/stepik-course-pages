<script setup>
import{ref,onMounted,computed}from'vue';import{useRouter}from'vue-router';import{useCartStore}from'../stores/cart';import{useAuthStore}from'../stores/auth';import{request}from'../lib/api';import{loadPending,prepareCheckout,clearPending}from'../lib/checkout';import{formatMoney,previewDelivery,addressError}from'../lib/domain';import FormField from'../components/FormField.vue';import NoticeBox from'../components/NoticeBox.vue'
const router=useRouter(),cart=useCartStore(),auth=useAuthStore(),address=ref(''),comment=ref(''),pending=ref(false),attempt=ref(null),error=ref(null),validation=ref('')
const estimated=computed(()=>cart.cart.subtotal_cents+previewDelivery(cart.cart.subtotal_cents))
onMounted(async()=>{attempt.value=loadPending(auth.user.id);if(attempt.value){address.value=attempt.value.body.address;comment.value=attempt.value.body.comment}try{await cart.load();if(!cart.cart.items.length&&!attempt.value)await router.replace('/cart')}catch(e){error.value=e}})
async function submit(){
 // TODO: submit — контракт и проверка в PRACTICE.md.
 error.value = new Error("TODO: оформление и повтор")
}
</script>
<template>
<!-- TODO: CheckoutView — соберите интерфейс по контракту PRACTICE.md. -->
<section class="panel"><h1>CheckoutView</h1><p>Экран пока не собран.</p></section>
</template>
