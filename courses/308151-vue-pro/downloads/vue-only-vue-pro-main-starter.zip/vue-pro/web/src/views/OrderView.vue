<script setup>
import{ref,watch}from'vue';import{useRoute}from'vue-router';import{request}from'../lib/api';import{formatMoney,statusLabel,allowedTransitions}from'../lib/domain';import{useAuthStore}from'../stores/auth';import NoticeBox from'../components/NoticeBox.vue';import BaseDialog from'../components/BaseDialog.vue'
const route=useRoute(),auth=useAuthStore(),order=ref(null),error=ref(null),busy=ref(false),confirm=ref(false)
async function load(){
 // TODO: load — контракт и проверка в PRACTICE.md.
 error.value = new Error("TODO: детали заказа")
}
watch(()=>route.params.id,()=>{order.value=null;error.value=null;load()},{immediate:true})
async function cancel(){
 // TODO: cancel — контракт и проверка в PRACTICE.md.
 error.value = new Error("TODO: отмена заказа")
}
</script>
<template>
<!-- TODO: OrderView — соберите интерфейс по контракту PRACTICE.md. -->
<section class="panel"><h1>OrderView</h1><p>Экран пока не собран.</p></section>
</template>
