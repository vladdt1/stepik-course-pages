<script setup>
import{ref}from'vue';import{useRoute,useRouter}from'vue-router';import{useAuthStore}from'../stores/auth';import{safeReturn,emailError}from'../lib/domain';import FormField from'../components/FormField.vue';import NoticeBox from'../components/NoticeBox.vue'
const route=useRoute(),router=useRouter(),auth=useAuthStore(),email=ref(''),password=ref(''),error=ref(null),pending=ref(false),validation=ref('')
async function submit(){
 // TODO: submit — контракт и проверка в PRACTICE.md.
 error.value = new Error("TODO: вход")
}
</script>
<template>
<!-- TODO: LoginView — соберите интерфейс по контракту PRACTICE.md. -->
<section class="panel"><h1>LoginView</h1><p>Экран пока не собран.</p></section>
</template>
