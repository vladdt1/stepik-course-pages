<script setup>
import{ref,onMounted}from'vue';import{request,query}from'../lib/api';import{formatMoney,statusLabel,allowedTransitions}from'../lib/domain';import NoticeBox from'../components/NoticeBox.vue'
const items=ref([]),cursor=ref(0),status=ref('new'),busy=ref(false),error=ref(null)
async function load(append=false){
 // TODO: load — контракт и проверка в PRACTICE.md.
 error.value = new Error("TODO: очередь оператора")
}
async function change(o,next){
 // TODO: change — контракт и проверка в PRACTICE.md.
 error.value = new Error("TODO: смена статуса")
}
onMounted(()=>load())
</script>
<template>
<!-- TODO: OperatorView — соберите интерфейс по контракту PRACTICE.md. -->
<section class="panel"><h1>OperatorView</h1><p>Экран пока не собран.</p></section>
</template>
