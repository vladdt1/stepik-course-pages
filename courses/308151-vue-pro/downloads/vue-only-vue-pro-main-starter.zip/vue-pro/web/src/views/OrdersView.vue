<script setup>
import{ref,onMounted}from'vue';import{request,query}from'../lib/api';import{formatMoney,statusLabel}from'../lib/domain';import NoticeBox from'../components/NoticeBox.vue';import EmptyState from'../components/EmptyState.vue'
const items=ref([]),cursor=ref(0),error=ref(null),loading=ref(false),status=ref('')
async function load(append=false){
 // TODO: load — контракт и проверка в PRACTICE.md.
 error.value = new Error("TODO: история заказов")
}
onMounted(()=>load())
</script>
<template>
<!-- TODO: OrdersView — соберите интерфейс по контракту PRACTICE.md. -->
<section class="panel"><h1>OrdersView</h1><p>Экран пока не собран.</p></section>
</template>
