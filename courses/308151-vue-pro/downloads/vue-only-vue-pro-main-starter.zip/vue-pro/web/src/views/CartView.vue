<script setup>
import{ref,onMounted}from'vue';import{useCartStore}from'../stores/cart';import{formatMoney}from'../lib/domain';import NoticeBox from'../components/NoticeBox.vue';import QuantityInput from'../components/QuantityInput.vue';import EmptyState from'../components/EmptyState.vue'
const cart=useCartStore(),error=ref(null),loading=ref(false)
onMounted(async()=>{loading.value=true;try{await cart.load()}catch(e){error.value=e}finally{loading.value=false}})
async function change(id,q){
 // TODO: change — контракт и проверка в PRACTICE.md.
 error.value = new Error("TODO: изменение количества")
}
</script>
<template>
<!-- TODO: CartView — соберите интерфейс по контракту PRACTICE.md. -->
<section class="panel"><h1>CartView</h1><p>Экран пока не собран.</p></section>
</template>
