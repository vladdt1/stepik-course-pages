<script setup>
import{computed,watch,onMounted,onUnmounted,ref}from'vue';import{useRoute,useRouter}from'vue-router';import{useCatalogStore}from'../stores/catalog';import{useAuthStore}from'../stores/auth';import{useCartStore}from'../stores/cart';import ProductList from'../components/ProductList.vue';import NoticeBox from'../components/NoticeBox.vue';import EmptyState from'../components/EmptyState.vue'
const route=useRoute(),router=useRouter(),catalog=useCatalogStore(),auth=useAuthStore(),cart=useCartStore(),notice=ref(''),error=ref(null)
const search=computed({get:()=>String(route.query.search||''),set:v=>router.replace({query:{...route.query,search:v||undefined}})}),category=computed({get:()=>String(route.query.category_id||''),set:v=>router.replace({query:{...route.query,category_id:v||undefined}})})
const filters=computed(()=>({search:search.value,category_id:category.value?Number(category.value):0}))
watch(filters,value=>catalog.load(value),{immediate:true});onMounted(async()=>{try{await catalog.loadCategories()}catch(e){error.value=e}});onUnmounted(catalog.cancel)
async function add(id){
 // TODO: add — контракт и проверка в PRACTICE.md.
 error.value = new Error("TODO: добавление товара")
}
</script>
<template>
<!-- TODO: CatalogView — соберите интерфейс по контракту PRACTICE.md. -->
<section class="panel"><h1>CatalogView</h1><p>Экран пока не собран.</p></section>
</template>
