<script setup>
import{ref,watch,nextTick,onBeforeUnmount,useId}from'vue'
const open=defineModel({type:Boolean,default:false});defineProps({title:String});const titleId=useId();const dialog=ref(null);let previous=null
watch(open,async value=>{await nextTick();if(value&&!dialog.value.open){previous=document.activeElement;dialog.value.showModal()}else if(!value&&dialog.value.open){dialog.value.close();previous?.focus()}},{immediate:true})
function close(){open.value=false}
onBeforeUnmount(()=>{dialog.value?.close();previous?.focus()})
</script>
<template>
<!-- TODO: BaseDialog — разметка, привязки и события. Контракт: PRACTICE.md. -->
<section class="panel">Компонент BaseDialog пока не собран.</section>
</template>
