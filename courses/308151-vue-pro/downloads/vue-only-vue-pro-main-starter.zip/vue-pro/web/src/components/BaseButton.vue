<script setup>defineProps({busy:Boolean,variant:{type:String,default:'primary'}})</script>
<template>
<!-- TODO: BaseButton — разметка, привязки и события. Контракт: PRACTICE.md. -->
<section class="panel">Компонент BaseButton пока не собран.</section>
</template>
