<script setup>
import{formatMoney}from'../lib/domain';defineProps({product:{type:Object,required:true},busy:Boolean});defineEmits(['add'])
</script>
<template>
<!-- TODO: ProductCard — разметка, привязки и события. Контракт: PRACTICE.md. -->
<section class="panel">Компонент ProductCard пока не собран.</section>
</template>
