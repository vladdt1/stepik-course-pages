<script setup>defineProps({title:{type:String,default:'Пока ничего нет'}})</script>
<template>
<!-- TODO: EmptyState — разметка, привязки и события. Контракт: PRACTICE.md. -->
<section class="panel">Компонент EmptyState пока не собран.</section>
</template>
