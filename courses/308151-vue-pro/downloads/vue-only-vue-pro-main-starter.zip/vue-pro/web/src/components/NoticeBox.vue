<script setup>import{errorText}from'../lib/api';defineProps({error:Object,message:String})</script>
<template>
<!-- TODO: NoticeBox — разметка, привязки и события. Контракт: PRACTICE.md. -->
<section class="panel">Компонент NoticeBox пока не собран.</section>
</template>
