<script setup>defineProps({id:{type:String,required:true},label:String,error:String,type:{type:String,default:'text'},autocomplete:String,required:Boolean,disabled:Boolean});const model=defineModel({type:String,default:''})</script>
<template>
<!-- TODO: FormField — разметка, привязки и события. Контракт: PRACTICE.md. -->
<section class="panel">Компонент FormField пока не собран.</section>
</template>
