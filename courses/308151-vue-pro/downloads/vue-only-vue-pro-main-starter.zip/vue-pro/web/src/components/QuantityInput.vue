<script setup>
const model=defineModel({type:Number,default:1});const props=defineProps({disabled:Boolean,label:{type:String,default:'Количество'},min:{type:Number,default:1},max:{type:Number,default:100}})
function update(event){
 // TODO: update — контракт и проверка в PRACTICE.md.
 // Проверьте число и обновите model только для допустимого значения.
}
</script>
<template>
<!-- TODO: QuantityInput — разметка, привязки и события. Контракт: PRACTICE.md. -->
<section class="panel">Компонент QuantityInput пока не собран.</section>
</template>
