<script setup>
import ProductCard from './ProductCard.vue'
defineProps({products:{type:Array,default:()=>[]},busy:Boolean})
defineEmits(['add'])
</script>
<template><!-- TODO: список карточек, стабильный key и передача события add. --><section class="grid">Список пока не собран.</section></template>
