import {defineStore} from 'pinia'
import {ref,computed,onScopeDispose} from 'vue'
import {request} from '../lib/api'
import {cartCount} from '../lib/domain'
export const useCartStore=defineStore('cart',()=>{
 const cart=ref({version:1,items:[],subtotal_cents:0}),loaded=ref(false),saving=ref(false),error=ref(null)
 let generation=0
 const count=computed(()=>cartCount(cart.value.items))
 function reset(){generation++;saving.value=false;cart.value={version:1,items:[],subtotal_cents:0};loaded.value=false;error.value=null}
 async function load(){const mine=generation;const value=await request('/cart');if(mine===generation&&(!loaded.value||value.version>=cart.value.version)){cart.value=value;loaded.value=true}return value}
 async function replace(items){
 // TODO: replace — контракт и проверки в STAGES.md и соответствующем уроке.
 throw new Error('TODO: сохранить состав с ожидаемой version и обработать конфликт')
}
 async function setQuantity(id,quantity){const items=cart.value.items.map(p=>({product_id:p.product_id,quantity:p.quantity}));const row=items.find(p=>p.product_id===id);if(row){row.quantity=quantity}else{items.push({product_id:id,quantity})}return replace(items.filter(p=>p.quantity>0))}
 async function add(id){if(!loaded.value)await load();const found=cart.value.items.find(p=>p.product_id===id);return setQuantity(id,(found?.quantity||0)+1)}
 window.addEventListener('delivery:identity-changed',reset);onScopeDispose(()=>window.removeEventListener('delivery:identity-changed',reset))
 return{cart,loaded,saving,error,count,load,replace,setQuantity,add,reset}
})
