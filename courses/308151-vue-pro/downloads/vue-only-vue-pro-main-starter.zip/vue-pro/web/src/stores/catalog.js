import {defineStore} from 'pinia'
import {ref} from 'vue'
import {request,query} from '../lib/api'
export const useCatalogStore=defineStore('catalog',()=>{
 const items=ref([]),categories=ref([]),nextCursor=ref(0),loading=ref(false),error=ref(null)
 let controller=null,generation=0
 async function load(filters={},append=false){
 // TODO: load — контракт и проверки в STAGES.md и соответствующем уроке.
 error.value=new Error('TODO: загрузить каталог,защитить результат от старого ответа');loading.value=false
}
 async function loadCategories(){categories.value=(await request('/catalog/categories')).items}
 function cancel(){++generation;controller?.abort();loading.value=false}
 return{items,categories,nextCursor,loading,error,load,loadCategories,cancel}
})
