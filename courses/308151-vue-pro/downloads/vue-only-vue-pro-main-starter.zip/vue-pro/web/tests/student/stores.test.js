// TODO: замените it.todo настоящими проверками; setup/импорты даны.
import{it,expect,vi,beforeEach,afterEach}from'vitest'
import{createPinia,setActivePinia,disposePinia}from'pinia'
import{useAuthStore}from'../../src/stores/auth';import{useCartStore}from'../../src/stores/cart';import{useCatalogStore}from'../../src/stores/catalog';import{prepareCheckout,loadPending}from'../../src/lib/checkout'
let pinia
beforeEach(()=>{pinia=createPinia();setActivePinia(pinia);sessionStorage.clear()});afterEach(()=>{disposePinia(pinia);vi.unstubAllGlobals()})
const response=(data,status=200)=>({ok:status<400,status,json:async()=>data})
function seedPending(userId){const command={userId,key:'study-command',body:{cart_version:2,address:'Main street 10',comment:''}};sessionStorage.setItem('delivery.pending-checkout.v1',JSON.stringify(command));return command}
it.todo("восстанавливает сессию одним запросом и сохраняет незавершённую команду своего пользователя")
it.todo("очищает корзину и чужую команду при входе другого пользователя")
it.todo("при409 перечитывает серверную корзину,не сохраняет желаемую как успешную")
it.todo("старый ответ поиска не затирает новый")
it.todo("запоздалая корзина прошлого пользователя не появляется после сброса")

it.todo("сеть при сохранении оставляет подтверждённую корзину")
