// TODO: замените it.todo настоящими проверками; setup/импорты даны.
import {it,expect,vi,beforeEach,afterEach} from 'vitest'
import {mount,flushPromises} from '@vue/test-utils'
import {reactive} from 'vue'
const mocks=vi.hoisted(()=>({request:vi.fn(),login:vi.fn(),push:vi.fn(),replace:vi.fn(),route:{query:{return:'/orders/12'}}}))
vi.mock('../../src/lib/api',()=>({request:mocks.request,errorText:e=>e.message}))
vi.mock('../../src/stores/auth',()=>({useAuthStore:()=>({login:mocks.login})}))
vi.mock('vue-router',()=>({useRouter:()=>({push:mocks.push,replace:mocks.replace}),useRoute:()=>mocks.route}))
import RegisterView from '../../src/views/RegisterView.vue'
import LoginView from '../../src/views/LoginView.vue'
let wrappers=[]
function render(c){const w=mount(c,{global:{stubs:{RouterLink:{template:'<a><slot/></a>'}}}});wrappers.push(w);return w}
async function fill(w,email='student@example.test',password='StrongPass88'){await w.get('input[type=email]').setValue(email);await w.get('input[type=password]').setValue(password)}
beforeEach(()=>{vi.resetAllMocks();mocks.route.query={return:'/orders/12'}});afterEach(()=>{wrappers.forEach(w=>w.unmount());wrappers=[]})
it.todo("26.3 регистрация отправляет поля и открывает вход после успеха")
it.todo("26.3 ошибка регистрации сохраняет введённое и не открывает вход")
it.todo("26.3 регистрация блокирует поля пока ждёт ответ")
it.todo("26.3 повторное submit регистрации не запускает второй запрос")
