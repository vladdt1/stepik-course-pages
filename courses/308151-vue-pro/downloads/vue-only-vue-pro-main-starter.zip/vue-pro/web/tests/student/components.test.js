// TODO: замените it.todo настоящими проверками; setup/импорты даны.
import {it,expect,vi,afterEach} from 'vitest'
import {mount} from '@vue/test-utils'
import {nextTick} from 'vue'
import BaseButton from '../../src/components/BaseButton.vue'
import FormField from '../../src/components/FormField.vue'
import QuantityInput from '../../src/components/QuantityInput.vue'
import ProductCard from '../../src/components/ProductCard.vue'
import EmptyState from '../../src/components/EmptyState.vue'
import NoticeBox from '../../src/components/NoticeBox.vue'
import BaseDialog from '../../src/components/BaseDialog.vue'
const wrappers=[]
function render(component,options={}){const w=mount(component,options);wrappers.push(w);return w}
afterEach(()=>{wrappers.forEach(w=>w.unmount());wrappers.length=0;document.body.innerHTML='';vi.restoreAllMocks()})
it.todo("24.8 кнопка отражает busy и сохраняет слот")
it.todo("24.8 поле испускает строку через v-model и связывает подпись")
it.todo("24.8 поле показывает и снимает ошибку без потери ввода")
it.todo("24.8 количество отвергает дроби и выход за обе границы")
it.todo("24.8 две карточки передают собственные ID без мутации props")
it.todo("24.8 занятая карточка блокирует добавление")
it.todo("24.8 пустое состояние показывает оба слота")
it.todo("26.1 уведомление различает статус и ошибку с request_id")
it.todo("24.8 диалог открывается, закрывается и возвращает фокус")
it.todo("24.8 список передаёт ID выбранной карточки родителю")

it.todo("карточка нулевого остатка не разрешает добавить товар")
