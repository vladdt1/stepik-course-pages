// TODO: замените it.todo настоящими проверками; setup/импорты даны.
import{describe,it,expect}from'vitest'
import{filterProducts,cartCount,previewSubtotal,previewDelivery,allowedTransitions,emailError,passwordError,addressError,safeReturn,formatMoney}from'../../src/lib/domain'
describe('Правила отображения',()=>{
it.todo("не меняет исходный каталог при фильтрации")
it.todo("считает количество и предварительную сумму отдельно от тарифа")
it.todo("показывает допустимые действия, окончательное решение оставляет API")
it.todo("проверяет ввод с Unicode и пределом bcrypt")
it.todo("возвращает только внутренний путь")
it.todo("форматирует целые копейки для экрана")
})
