<script setup>
import {ref,watch} from 'vue'
const category=ref('all'),selected=ref('1'),view=ref(localStorage.getItem('catalog-view')||'grid')
// TODO: наблюдение категории
// TODO: сохранение вида
</script>
<template><main><select v-model="category" aria-label="Категория"><option value="all">Все</option><option value="food">Еда</option></select><input v-model="selected" aria-label="Позиция"><select v-model="view" aria-label="Вид"><option value="grid">Сетка</option><option value="list">Список</option></select></main></template>
