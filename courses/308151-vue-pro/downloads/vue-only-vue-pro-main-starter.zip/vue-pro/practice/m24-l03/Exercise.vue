<script setup>
const props=defineProps({id:Number,quantity:{type:Number,default:0}})
const emit=defineEmits(['select','update:quantity'])
</script>
<template><article @click="emit('select',id)"><span>{{quantity}}</span><button type="button" @click="emit('select',id)">Выбрать</button><button type="button" @click="emit('update:quantity',quantity)">Больше</button></article></template>
