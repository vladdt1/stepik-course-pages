<script setup>
import {ref,onMounted,onUnmounted} from 'vue'
const input=ref(null),ticks=ref(0),events=ref(0);let timer
const resize=()=>events.value++
onMounted(()=>{/* TODO: фокус */;timer=setInterval(()=>ticks.value++,1000);window.addEventListener('resize',resize)})
onUnmounted(()=>{/* TODO: очистка ресурсов */})
</script>
<template><main><input ref="input" aria-label="Название"><output>{{ticks}}</output><p>{{events}}</p></main></template>
