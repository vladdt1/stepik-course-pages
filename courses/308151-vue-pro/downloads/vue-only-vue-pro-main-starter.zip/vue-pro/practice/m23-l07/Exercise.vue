<script setup>
import {ref,computed} from 'vue'
const props=defineProps({products:{type:Array,default:()=>[]}})
const query=ref(''),quantity=ref(1)
const visible=computed(()=>props.products) // TODO: вычисляемый фильтр и сортировка
const subtotal=computed(()=>0) // TODO: производный итог
</script>
<template><main><input v-model="query" aria-label="Поиск"><input v-model.number="quantity" type="number" aria-label="Количество"><ul><li v-for="p in visible" :key="p.id">{{p.name}}</li></ul><output>{{subtotal}}</output></main></template>
