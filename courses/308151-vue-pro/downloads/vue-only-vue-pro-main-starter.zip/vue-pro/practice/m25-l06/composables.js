import {ref,computed,onMounted,onUnmounted} from 'vue'
export function useProductFilters(products){const query=ref('');return {query,visible:computed(()=>products.filter(p=>true))}}
export function useDialog(){const open=ref(false),close=()=>open.value=false;const key=e=>{/* TODO */};onMounted(()=>window.addEventListener('keydown',key));onUnmounted(()=>window.removeEventListener('keydown',key));return {open,close}}
