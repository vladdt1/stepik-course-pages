export function activeProducts(products) {
  // TODO: отберите активные товары и верните отдельные верхние объекты.
  return []
}
export function productLabels(products) {
  // TODO: сформируйте подписи, не изменяя исходные объекты.
  return []
}
