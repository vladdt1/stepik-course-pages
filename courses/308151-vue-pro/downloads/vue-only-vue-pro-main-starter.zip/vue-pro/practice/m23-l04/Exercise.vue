<script setup>
import {ref,reactive} from 'vue'
const quantity=ref(1)
const filters=reactive({query:'',category:0})
function increase(){/* TODO: увеличить количество */}
function reset(){/* TODO: сбросить оба вида состояния */}
</script>
<template><main><p data-testid="quantity">{{quantity}}</p><button type="button" @click="increase">Больше</button><input aria-label="Поиск" :value="filters.query" @input="() => {}"><p data-testid="query">{{filters.query}}</p><button type="button" @click="reset">Сбросить</button></main></template>
