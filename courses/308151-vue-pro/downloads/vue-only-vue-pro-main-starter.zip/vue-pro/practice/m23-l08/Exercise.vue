<script setup>
import {ref,computed} from 'vue'
const products=[{id:1,name:'Суп',price_cents:35000},{id:2,name:'Чай',price_cents:9000}]
const query=ref(''),quantities=ref({})
const visible=computed(()=>products) // TODO: поиск
const total=computed(()=>products.reduce((s,p)=>s+p.price_cents*(quantities.value[p.id]||0),0))
function add(id){/* TODO: изменить выбор */}
</script>
<template><main><h1>Меню доставки</h1><input v-model="query" aria-label="Поиск"><p v-if="!visible.length">Ничего не найдено</p><ul><li v-for="p in visible" :key="p.id"><span>{{p.name}}</span><button type="button" @click="add(p.id)">Добавить {{p.name}}</button></li></ul><output>{{total}}</output></main></template>
