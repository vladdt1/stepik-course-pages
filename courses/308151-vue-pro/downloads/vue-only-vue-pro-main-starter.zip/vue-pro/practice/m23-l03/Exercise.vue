<script setup>
const props=defineProps({product:{type:Object,required:true}})
</script>
<template><article :class="{unavailable:props.product.stock===0}"><h2>TODO: название</h2><p>0 коп.</p><button type="button" disabled>Добавить</button></article></template>
