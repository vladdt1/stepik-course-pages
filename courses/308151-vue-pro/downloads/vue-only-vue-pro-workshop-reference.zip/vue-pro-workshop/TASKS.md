# Упражнения

E01: publicSettings(env) → {apiBase,release}; defaults /api и dev; остальные поля не копируем.
E02: pageEvents(events,search,page,size) → {items,pages,page,total}. Поиск по title, trim/case-insensitive; фильтр до среза; размер положительный целый, page целый; минимум одна страница; страницу ограничить границами; исходный массив не менять.
E03: median(numbers) → медиана или null для пустого; массив не менять.
E04: nextCheck(results): порядок lint,format,unit,api,build,e2e. failed → null; первый не passed → его имя; всё passed → publish.
E05: safeError(error,pathname,release) → только {route,code,release}, путь без query/hash; code по умолчанию CLIENT_ERROR.
E06: createLatestLoader(loader,commit) → {run(query),dispose()}. loader(query,signal) возвращает Promise; новая run отменяет предыдущую; commit получает только актуальный результат; dispose отменяет/обесценивает работу; активная не-AbortError отклоняет run.
E07: bookingState(status): 201 success,409 full,401 login,прочие error. Это учебный маппер статуса; реальный ALREADY_BOOKED уточняйте по code.
E08: eventQuery(search,page) → querystring без ?, search trimmed/пустой опущен, page минимум1, специальные символы кодируются.
E09: VenueProvider/VenuePicker — readonly ref venue и choose по общему venueKey; начальное Онлайн, кнопка Выбрать зал меняет на Зал A.
E10: без Provider показать «Контекст площадки недоступен».
E11: DraftTabs сохраняет заметку между редактором и списком без изменения TabDraft и без localStorage.
E12: WatchedSearch получает load(query,signal), сразу загружает, повторяет при вводе, отменяет и игнорирует старое/размонтированное; статус Загрузка/Готово/Ошибка; data-testid=result содержит результат.
E13: LazyPanel loader → компонент, до завершения «Загрузка панели».
E14: при отказе loader «Не удалось загрузить панель», timeout5000, delay0; не используйте template-строки как runtime-компиляцию production Vue.

Проверки: npm test -- tests/workshop.test.js или tests/components.test.js. Отдельный тест: npm test -- -t "E06".

Подсказка1: выпишите допустимые состояния функции/компонента.
Подсказка2: проверьте пустой набор, отсутствие зависимости и обратный порядок ответов там, где они применимы.
Подсказка3: сравните, что наблюдает тест и какой внешний контракт вы реализуете. Тесты не требуют совпадения исходного кода.
