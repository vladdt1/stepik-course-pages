import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
export default defineConfig({base: process.env.DEPLOY_BASE || '/', plugins:[vue()],server:{proxy:{'/api':'http://127.0.0.1:8093'}},test:{environment:'jsdom',include:['tests/**/*.test.js'],restoreMocks:true}})
