import { test } from 'node:test'
import assert from 'node:assert/strict'
import { createServer } from './server.mjs'
async function use(fn) {
  const s = createServer()
  await new Promise((r) => s.listen(0, '127.0.0.1', r))
  const url = `http://127.0.0.1:${s.address().port}/api`
  try {
    await fn((path, init) => fetch(url + path, init))
  } finally {
    await new Promise((r) => s.close(r))
  }
}
test('catalog and details', () =>
  use(async (get) => {
    const r = await get('/events')
    assert.equal(r.status, 200)
    const d = await r.json()
    assert.equal(d.items.length, 3)
    assert.equal((await get('/events/1')).status, 200)
    assert.equal((await get('/events/999')).status, 404)
  }))
test('booking, duplicate, cancellation', () =>
  use(async (get) => {
    const post = () =>
      get('/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ eventId: 1 }),
      })
    const r = await post()
    assert.equal(r.status, 201)
    const b = await r.json()
    assert.equal((await post()).status, 409)
    assert.equal((await (await get('/bookings')).json()).items.length, 1)
    assert.equal(
      (await get('/bookings/' + b.id, { method: 'DELETE' })).status,
      200,
    )
    assert.equal(
      (await get('/bookings/' + b.id, { method: 'DELETE' })).status,
      404,
    )
    assert.equal((await post()).status, 201)
  }))
test('invalid json and missing event', () =>
  use(async (get) => {
    assert.equal(
      (await get('/bookings', { method: 'POST', body: 'x' })).status,
      400,
    )
    assert.equal(
      (await get('/bookings', { method: 'POST', body: '{"eventId":999}' }))
        .status,
      404,
    )
  }))
