import http from 'node:http'
import { fileURLToPath } from 'node:url'
const initial = () => [
  { id: 1, title: 'Vue вечером', category: 'frontend', capacity: 2 },
  { id: 2, title: 'HTTP и API', category: 'backend', capacity: 1 },
  { id: 3, title: 'Тесты без паники', category: 'frontend', capacity: 3 },
]
export function createServer() {
  const events = initial(),
    bookings = new Map()
  let next = 1
  const reply = (res, status, data) => {
    res.writeHead(status, {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
    })
    res.end(JSON.stringify(data))
  }
  return http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://local'),
        send = (s, d) => reply(res, s, d)
      if (req.method === 'GET' && url.pathname === '/api/health')
        return send(200, { ok: true })
      if (req.method === 'GET' && url.pathname === '/api/events')
        return send(200, {
          items: events.map((e) => ({
            ...e,
            remaining:
              e.capacity -
              [...bookings.values()].filter((b) => b.eventId === e.id).length,
          })),
        })
      const match = url.pathname.match(/^\/api\/events\/(\d+)$/)
      if (req.method === 'GET' && match) {
        const e = events.find((e) => e.id === Number(match[1]))
        return e
          ? send(200, {
              ...e,
              remaining:
                e.capacity -
                [...bookings.values()].filter((b) => b.eventId === e.id).length,
            })
          : send(404, { code: 'NOT_FOUND' })
      }
      // Изолированный учебный demo-user, НЕ авторизация. Данные сбрасываются при перезапуске.
      if (req.method === 'GET' && url.pathname === '/api/bookings')
        return send(200, { items: [...bookings.values()] })
      if (req.method === 'POST' && url.pathname === '/api/bookings') {
        let raw = ''
        for await (const chunk of req) {
          raw += chunk
          if (raw.length > 4096) return send(413, { code: 'TOO_LARGE' })
        }
        let body
        try {
          body = JSON.parse(raw)
        } catch {
          return send(400, { code: 'BAD_JSON' })
        }
        const e = events.find((e) => e.id === body.eventId)
        if (!e) return send(404, { code: 'NOT_FOUND' })
        if ([...bookings.values()].some((b) => b.eventId === e.id))
          return send(409, { code: 'ALREADY_BOOKED' })
        if (
          e.capacity <=
          [...bookings.values()].filter((b) => b.eventId === e.id).length
        )
          return send(409, { code: 'FULL' })
        const b = { id: next++, eventId: e.id }
        bookings.set(b.id, b)
        return send(201, b)
      }
      const cancel = url.pathname.match(/^\/api\/bookings\/(\d+)$/)
      if (req.method === 'DELETE' && cancel) {
        const ok = bookings.delete(Number(cancel[1]))
        return send(ok ? 200 : 404, ok ? { ok: true } : { code: 'NOT_FOUND' })
      }
      return send(404, { code: 'NOT_FOUND' })
    } catch {
      return reply(res, 500, { code: 'INTERNAL' })
    }
  })
}
if (process.argv[1] === fileURLToPath(import.meta.url))
  createServer().listen(Number(process.env.PORT || 8093), '127.0.0.1', () =>
    console.log('Учебный API: http://127.0.0.1:8093'),
  )
