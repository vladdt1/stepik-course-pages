<script setup>
import { ref } from 'vue'
const draft = ref('')
</script>
<template>
  <label>Заметка <input v-model="draft" aria-label="Заметка" /></label>
</template>
