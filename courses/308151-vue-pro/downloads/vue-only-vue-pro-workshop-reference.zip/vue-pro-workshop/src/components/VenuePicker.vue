<script setup>
import { inject } from 'vue'
import { venueKey } from './context.js'
const context = inject(venueKey, null)
</script>
<template>
  <div v-if="context">
    <span data-testid="venue">{{ context.venue.value }}</span
    ><button @click="context.choose('Зал A')">Выбрать зал</button>
  </div>
  <p v-else>Контекст площадки недоступен</p>
</template>
