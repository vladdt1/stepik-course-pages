<script setup>
import { ref, watchEffect } from 'vue'
const props = defineProps({ load: { type: Function, required: true } })
const query = ref(''),
  status = ref(''),
  result = ref('')
watchEffect((onCleanup) => {
  const value = query.value
  const controller = new AbortController()
  let active = true
  onCleanup(() => {
    active = false
    controller.abort()
  })
  status.value = 'Загрузка'
  props
    .load(value, controller.signal)
    .then((data) => {
      if (active) {
        result.value = data
        status.value = 'Готово'
      }
    })
    .catch((error) => {
      if (active && error.name !== 'AbortError') status.value = 'Ошибка'
    })
})
</script>
<template>
  <input v-model="query" aria-label="Поиск" />
  <p role="status">{{ status }}</p>
  <p data-testid="result">{{ result }}</p>
</template>
