<script setup>
import { ref } from 'vue'
import TabDraft from './TabDraft.vue'
const active = ref(true)
</script>
<template>
  <button @click="active = !active">Переключить вкладку</button
  ><KeepAlive
    ><TabDraft v-if="active" />
    <p v-else>Список событий</p></KeepAlive
  >
</template>
