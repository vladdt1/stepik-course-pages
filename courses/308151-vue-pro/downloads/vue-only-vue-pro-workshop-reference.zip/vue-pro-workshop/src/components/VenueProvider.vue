<script setup>
import { ref, readonly, provide } from 'vue'
import { venueKey } from './context.js'
const venue = ref('Онлайн')
function choose(value) {
  venue.value = value
}
provide(venueKey, { venue: readonly(venue), choose })
</script>
<template><slot /></template>
