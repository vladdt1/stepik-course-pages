<script setup>
import { defineAsyncComponent, h } from 'vue'
const props = defineProps({ loader: { type: Function, required: true } })
const Panel = defineAsyncComponent({
  loader: props.loader,
  delay: 0,
  loadingComponent: {
    render: () => h('p', { role: 'status' }, 'Загрузка панели'),
  },
  errorComponent: {
    render: () => h('p', { role: 'alert' }, 'Не удалось загрузить панель'),
  },
  timeout: 5000,
})
</script>
<template><Panel /></template>
