// Изолированная модель браузера. Не сервер и не авторизация.
const initial = () => [
  { id: 1, title: 'Vue вечером', category: 'frontend', capacity: 2 },
  { id: 2, title: 'HTTP и API', category: 'backend', capacity: 1 },
  { id: 3, title: 'Тесты без паники', category: 'frontend', capacity: 3 },
]
const key = 'vue-pro-events-demo-v1'
function read() {
  try {
    const value = JSON.parse(localStorage.getItem(key) || 'null')
    return Array.isArray(value) ? value : []
  } catch {
    return []
  }
}
export async function demoRequest(path, options = {}) {
  const events = initial(),
    bookings = read(),
    method = options.method || 'GET'
  const fail = (code) => {
    const e = new Error('Учебный отказ')
    e.code = code
    e.status = code === 'NOT_FOUND' ? 404 : 409
    throw e
  }
  const available = (e) => ({
    ...e,
    remaining: e.capacity - bookings.filter((b) => b.eventId === e.id).length,
  })
  if (path === '/events') return { items: events.map(available) }
  if (path.startsWith('/events/')) {
    const e = events.find((e) => e.id === Number(path.split('/').pop()))
    if (!e) fail('NOT_FOUND')
    return available(e)
  }
  if (path === '/bookings' && method === 'GET') return { items: bookings }
  if (path === '/bookings' && method === 'POST') {
    const body = JSON.parse(options.body),
      e = events.find((e) => e.id === body.eventId)
    if (!e) fail('NOT_FOUND')
    if (bookings.some((b) => b.eventId === e.id)) fail('ALREADY_BOOKED')
    if (available(e).remaining <= 0) fail('FULL')
    const b = {
      id: Math.max(0, ...bookings.map((b) => b.id)) + 1,
      eventId: e.id,
    }
    localStorage.setItem(key, JSON.stringify([...bookings, b]))
    return b
  }
  if (path.startsWith('/bookings/') && method === 'DELETE') {
    const id = Number(path.split('/').pop())
    if (!bookings.some((b) => b.id === id)) fail('NOT_FOUND')
    localStorage.setItem(
      key,
      JSON.stringify(bookings.filter((b) => b.id !== id)),
    )
    return { ok: true }
  }
  fail('NOT_FOUND')
}
