import { demoRequest } from './demo.js'
const base = import.meta.env.VITE_API_BASE || '/api'
export async function request(path, options = {}) {
  if (import.meta.env.VITE_DEMO === 'true') return demoRequest(path, options)
  const r = await fetch(base + path, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...options.headers },
  })
  const data = await r.json()
  if (!r.ok) {
    const e = new Error('Запрос не выполнен')
    e.status = r.status
    e.code = data.code
    throw e
  }
  return data
}
