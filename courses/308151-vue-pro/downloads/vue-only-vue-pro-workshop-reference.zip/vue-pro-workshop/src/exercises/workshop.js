// E01. Выберите отдельные поля; не меняйте переданный объект.
export function publicSettings(env) {
  return {
    apiBase: env.VITE_API_BASE || '/api',
    release: env.VITE_RELEASE || 'dev',
  }
}
// E02. Фильтр по подстроке без учёта регистра, затем страница; входные массивы сохраняем.
export function pageEvents(events, search, page, size) {
  const filtered = events.filter((e) =>
    e.title.toLowerCase().includes(search.trim().toLowerCase()),
  )
  const count = Math.max(1, Math.ceil(filtered.length / size))
  const safePage = Math.min(count, Math.max(1, page))
  return {
    items: filtered.slice((safePage - 1) * size, safePage * size),
    pages: count,
    page: safePage,
    total: filtered.length,
  }
}
// E03. Устойчивый вывод суммы измерений, а не одного случайного запуска.
export function median(values) {
  if (!values.length) return null
  const a = [...values].sort((x, y) => x - y),
    i = Math.floor(a.length / 2)
  return a.length % 2 ? a[i] : (a[i - 1] + a[i]) / 2
}
// E04. Следующий шаг CI запускается только после успешного предыдущего.
export function nextCheck(results) {
  const steps = ['lint', 'format', 'unit', 'api', 'build', 'e2e']
  for (const name of steps) {
    if (results[name] === 'failed') return null
    if (results[name] !== 'passed') return name
  }
  return 'publish'
}
// E05. Обезличенное событие, разрешены только route/code/release. URL приводим к пути без query.
export function safeError(error, pathname, release) {
  return {
    route: pathname.split('?')[0].split('#')[0],
    code: error?.code || 'CLIENT_ERROR',
    release,
  }
}
// E06. Новая заявка отменяет старую; даже если loader игнорирует signal, старый ответ не применяем.
export function createLatestLoader(loader, commit) {
  let controller,
    version = 0
  return {
    async run(query) {
      controller?.abort()
      controller = new AbortController()
      const own = ++version
      try {
        const value = await loader(query, controller.signal)
        if (own === version) commit(value)
      } catch (e) {
        if (own === version && e.name !== 'AbortError') throw e
      }
    },
    dispose() {
      ++version
      controller?.abort()
    },
  }
}
// E07. Целевое состояние UI после ответа сервера. Строки кодов не подменяют HTTP-ошибки.
export function bookingState(status) {
  if (status === 201) return 'success'
  if (status === 409) return 'full'
  if (status === 401) return 'login'
  return 'error'
}
// E08. Динамические параметры формируем через URLSearchParams, пустые опускаем.
export function eventQuery(search, page) {
  const q = new URLSearchParams()
  if (search.trim()) q.set('search', search.trim())
  q.set('page', String(Math.max(1, page)))
  return q.toString()
}
