<script setup>
import { onMounted } from 'vue'
import { loading, error, load } from './store.js'
const demo = import.meta.env.VITE_DEMO === 'true'
onMounted(load)
</script>
<template>
  <main>
    <h1>Встречаемся</h1>
    <p>
      {{
        demo
          ? 'Demo: искусственные записи хранятся только в этом браузере.'
          : 'Учебный API одного demo-пользователя. Данные сбрасываются при перезапуске API.'
      }}
    </p>
    <nav>
      <RouterLink to="/">Каталог</RouterLink
      ><RouterLink to="/bookings">Мои записи</RouterLink>
    </nav>
    <p v-if="loading" role="status">Загрузка</p>
    <p v-if="error" role="alert">
      {{ error }} <button @click="load">Повторить загрузку</button>
    </p>
    <RouterView v-if="!loading" />
  </main>
</template>
<style>
body {
  font: 17px/1.6 system-ui;
  color: #173544;
  background: #f0f8f9;
  margin: 0;
}
main {
  max-width: 850px;
  margin: auto;
  padding: 20px;
}
li {
  background: white;
  border: 1px solid #b4d9da;
  border-radius: 12px;
  padding: 16px;
  margin: 12px 0;
}
ul {
  padding: 0;
  list-style: none;
}
button,
input,
select {
  font: inherit;
  padding: 8px;
  border: 1px solid #448a91;
  border-radius: 7px;
  max-width: 100%;
}
button {
  cursor: pointer;
}
button:disabled {
  cursor: default;
  opacity: 0.55;
}
nav {
  display: flex;
  gap: 20px;
  flex-wrap: wrap;
}
a {
  color: #08748a;
}
label {
  display: block;
  margin: 12px 0;
}
[role='alert'] {
  color: #a12c45;
}
:focus-visible {
  outline: 3px solid #b65ac8;
  outline-offset: 3px;
}
</style>
