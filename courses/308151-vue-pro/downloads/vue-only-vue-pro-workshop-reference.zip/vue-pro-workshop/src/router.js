import { createRouter, createWebHashHistory } from 'vue-router'
import { h } from 'vue'
export const router = createRouter({
  history: createWebHashHistory(import.meta.env.BASE_URL),
  routes: [
    { path: '/', component: () => import('./views/Catalog.vue') },
    { path: '/events/:id', component: () => import('./views/Details.vue') },
    { path: '/bookings', component: () => import('./views/Bookings.vue') },
    {
      path: '/:pathMatch(.*)*',
      component: { render: () => h('h2', 'Страница не найдена') },
    },
  ],
})
