import { ref } from 'vue'
import { request } from './api.js'
export const events = ref([]),
  bookings = ref([]),
  error = ref(''),
  busy = ref(false),
  loading = ref(false)
export async function load() {
  loading.value = true
  error.value = ''
  try {
    const [e, b] = await Promise.all([request('/events'), request('/bookings')])
    events.value = e.items
    bookings.value = b.items
  } catch {
    error.value = 'Не удалось загрузить события. Попробуйте ещё раз.'
  } finally {
    loading.value = false
  }
}
export async function book(eventId) {
  if (busy.value) return
  busy.value = true
  error.value = ''
  try {
    await request('/bookings', {
      method: 'POST',
      body: JSON.stringify({ eventId }),
    })
    await load()
  } catch (e) {
    error.value =
      e.code === 'ALREADY_BOOKED'
        ? 'Вы уже записаны'
        : e.code === 'FULL'
          ? 'Места закончились'
          : 'Не удалось записаться. Попробуйте ещё раз.'
  } finally {
    busy.value = false
  }
}
export async function cancel(id) {
  if (busy.value) return
  busy.value = true
  error.value = ''
  try {
    await request('/bookings/' + id, { method: 'DELETE' })
    await load()
  } catch {
    error.value = 'Не удалось отменить запись'
  } finally {
    busy.value = false
  }
}
