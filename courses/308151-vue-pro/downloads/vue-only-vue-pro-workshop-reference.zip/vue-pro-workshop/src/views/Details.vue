<script setup>
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import { events, bookings, busy, book } from '../store.js'
const route = useRoute(),
  event = computed(() =>
    events.value.find((e) => e.id === Number(route.params.id)),
  )
</script>
<template>
  <section v-if="event">
    <h2>{{ event.title }}</h2>
    <p>Категория: {{ event.category }}. Свободно: {{ event.remaining }}</p>
    <button
      :disabled="
        busy || bookings.some((b) => b.eventId === event.id) || !event.remaining
      "
      @click="book(event.id)"
    >
      {{
        bookings.some((b) => b.eventId === event.id)
          ? 'Вы записаны'
          : 'Записаться'
      }}
    </button>
  </section>
  <h2 v-else>Мероприятие не найдено</h2>
</template>
