<script setup>
import { bookings, events, busy, cancel } from '../store.js'
</script>
<template>
  <h2>Мои записи</h2>
  <p v-if="!bookings.length">Вы пока никуда не записаны</p>
  <ul>
    <li v-for="b in bookings" :key="b.id">
      {{ events.find((e) => e.id === b.eventId)?.title }}
      <button :disabled="busy" @click="cancel(b.id)">Отменить запись</button>
    </li>
  </ul>
</template>
