<script setup>
import { computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { events, bookings, busy, book } from '../store.js'
const route = useRoute(),
  router = useRouter()
const search = computed({
  get: () => (typeof route.query.search === 'string' ? route.query.search : ''),
  set: (value) =>
    router.replace({ query: { ...route.query, search: value || undefined } }),
})
const category = computed(() =>
  ['frontend', 'backend'].includes(route.query.category)
    ? route.query.category
    : '',
)
const filtered = computed(() =>
  events.value.filter(
    (e) =>
      e.title.toLowerCase().includes(search.value.trim().toLowerCase()) &&
      (!category.value || e.category === category.value),
  ),
)
function choose(e) {
  router.push({
    query: { ...route.query, category: e.target.value || undefined },
  })
}
</script>
<template>
  <h2>Каталог мероприятий</h2>
  <label>Поиск <input v-model="search" aria-label="Поиск мероприятий" /></label
  ><label
    >Категория
    <select :value="category" @change="choose">
      <option value="">Все</option>
      <option value="frontend">Frontend</option>
      <option value="backend">Backend</option>
    </select></label
  >
  <ul>
    <li v-for="event in filtered" :key="event.id">
      <h3>
        <RouterLink :to="'/events/' + event.id">{{ event.title }}</RouterLink>
      </h3>
      <p>Свободно: {{ event.remaining }}</p>
      <button
        :disabled="
          busy ||
          bookings.some((b) => b.eventId === event.id) ||
          event.remaining === 0
        "
        @click="book(event.id)"
      >
        {{
          bookings.some((b) => b.eventId === event.id)
            ? 'Вы записаны'
            : 'Записаться'
        }}
      </button>
    </li>
  </ul>
  <p v-if="!filtered.length">Ничего не найдено</p>
</template>
