import { describe, it, expect, vi } from 'vitest'
import {
  publicSettings,
  pageEvents,
  median,
  nextCheck,
  safeError,
  createLatestLoader,
  bookingState,
  eventQuery,
} from '../src/exercises/workshop.js'
describe('E01 publicSettings', () => {
  it('defaults', () =>
    expect(publicSettings({})).toEqual({ apiBase: '/api', release: 'dev' }))
  it('allowlist', () =>
    expect(
      publicSettings({
        VITE_API_BASE: '/x',
        VITE_RELEASE: 'v2',
        TOKEN: 'secret',
        VITE_PASSWORD: 'hidden',
      }),
    ).toEqual({ apiBase: '/x', release: 'v2' }))
})
describe('E02 pagination', () => {
  const events = [
    { id: 1, title: 'Vue' },
    { id: 2, title: 'Go' },
    { id: 3, title: 'Vue API' },
  ]
  it('filter then slice', () =>
    expect(pageEvents(events, ' VUE ', 2, 1)).toEqual({
      items: [events[2]],
      pages: 2,
      page: 2,
      total: 2,
    }))
  it('empty', () =>
    expect(pageEvents(events, 'SQL', 9, 2)).toEqual({
      items: [],
      pages: 1,
      page: 1,
      total: 0,
    }))
  it('clamp', () =>
    expect(pageEvents(events, '', 0, 2).items).toEqual(events.slice(0, 2)))
  it('preserve order', () => {
    pageEvents(events, '', 2, 2)
    expect(events.map((e) => e.id)).toEqual([1, 2, 3])
  })
})
describe('E03 measurements', () => {
  it.each([
    [[], null],
    [[9, 1, 3], 3],
    [[8, 2, 4, 6], 5],
    [[0], 0],
  ])('%j', (values, want) => expect(median(values)).toBe(want))
  it('immutable', () => {
    const a = [9, 1, 3]
    median(a)
    expect(a).toEqual([9, 1, 3])
  })
})
describe('E04 CI', () => {
  it('first', () => expect(nextCheck({})).toBe('lint'))
  it('stop', () =>
    expect(nextCheck({ lint: 'passed', format: 'failed' })).toBe(null))
  it('pending', () =>
    expect(
      nextCheck({ lint: 'passed', format: 'passed', unit: 'pending' }),
    ).toBe('unit'))
  it('publish', () =>
    expect(
      nextCheck(
        Object.fromEntries(
          ['lint', 'format', 'unit', 'api', 'build', 'e2e'].map((x) => [
            x,
            'passed',
          ]),
        ),
      ),
    ).toBe('publish'))
})
describe('E05 error event', () => {
  it('strip personal data', () =>
    expect(
      safeError(
        { code: 'HTTP_500', email: 'a@b', message: 'token' },
        '/events?email=a#b',
        'v1',
      ),
    ).toEqual({ route: '/events', code: 'HTTP_500', release: 'v1' }))
  it('default', () =>
    expect(safeError(null, '/', 'dev').code).toBe('CLIENT_ERROR'))
})
describe('E06 requests', () => {
  it('last result wins even without abort support', async () => {
    const resolve = {}
    const commits = []
    const model = createLatestLoader(
      (q) => new Promise((r) => (resolve[q] = r)),
      (x) => commits.push(x),
    )
    const a = model.run('a'),
      b = model.run('b')
    resolve.b('new')
    await b
    resolve.a('old')
    await a
    expect(commits).toEqual(['new'])
  })
  it('abort and dispose', async () => {
    let signal, resolve
    const commit = vi.fn()
    const m = createLatestLoader((_q, s) => {
      signal = s
      return new Promise((r) => (resolve = r))
    }, commit)
    const p = m.run('x')
    m.dispose()
    expect(signal.aborted).toBe(true)
    resolve('late')
    await p
    expect(commit).not.toHaveBeenCalled()
  })
  it('current failure propagates', async () => {
    const m = createLatestLoader(
      () => Promise.reject(new Error('offline')),
      () => {},
    )
    await expect(m.run('x')).rejects.toThrow('offline')
  })
})
describe('E07 booking state', () =>
  it.each([
    [201, 'success'],
    [409, 'full'],
    [401, 'login'],
    [500, 'error'],
    [0, 'error'],
  ])('%s', (status, want) => expect(bookingState(status)).toBe(want)))
describe('E08 query', () => {
  it('encoding', () =>
    expect(new URLSearchParams(eventQuery(' Vue & Go ', 2)).get('search')).toBe(
      'Vue & Go',
    ))
  it('empty', () => expect(eventQuery(' ', 0)).toBe('page=1'))
})
