import { it, expect } from 'vitest'
import { mount, flushPromises } from '@vue/test-utils'
import { defineComponent, nextTick } from 'vue'
import VenueProvider from '../src/components/VenueProvider.vue'
import VenuePicker from '../src/components/VenuePicker.vue'
import DraftTabs from '../src/components/DraftTabs.vue'
import WatchedSearch from '../src/components/WatchedSearch.vue'
import LazyPanel from '../src/components/LazyPanel.vue'
it('E09 provided reactive context works through wrappers', async () => {
  const Root = defineComponent({
    components: { VenueProvider, VenuePicker },
    template:
      '<VenueProvider><section><VenuePicker/></section></VenueProvider>',
  })
  const w = mount(Root)
  expect(w.text()).toContain('Онлайн')
  await w.get('button').trigger('click')
  expect(w.text()).toContain('Зал A')
  w.unmount()
})
it('E10 missing context', () => {
  const w = mount(VenuePicker)
  expect(w.text()).toContain('недоступен')
  w.unmount()
})
it('E11 draft survives tabs', async () => {
  const w = mount(DraftTabs)
  await w.get('input').setValue('мой черновик')
  await w.get('button').trigger('click')
  await w.get('button').trigger('click')
  expect(w.get('input').element.value).toBe('мой черновик')
  w.unmount()
})
it('E12 watcher aborts on new value and unmount', async () => {
  const signals = []
  const w = mount(WatchedSearch, {
    props: {
      load: (_q, s) => {
        signals.push(s)
        return new Promise(() => {})
      },
    },
  })
  await w.get('input').setValue('vue')
  expect(signals[0].aborted).toBe(true)
  expect(signals[1].aborted).toBe(false)
  w.unmount()
  expect(signals[1].aborted).toBe(true)
})
it('E12 stale result ignored', async () => {
  const resolve = {}
  const w = mount(WatchedSearch, {
    props: { load: (q) => new Promise((r) => (resolve[q] = r)) },
  })
  await w.get('input').setValue('new')
  resolve.new('актуально')
  await flushPromises()
  resolve['']('старое')
  await flushPromises()
  expect(w.get('[data-testid=result]').text()).toBe('актуально')
  w.unmount()
})
it('E13 async loading and success', async () => {
  let done
  const w = mount(LazyPanel, {
    props: { loader: () => new Promise((r) => (done = r)) },
  })
  await nextTick()
  expect(w.text()).toContain('Загрузка')
  done(defineComponent({ template: '<p>Отчёт готов</p>' }))
  await flushPromises()
  expect(w.text()).toContain('Отчёт готов')
  w.unmount()
})
it('E14 async error state', async () => {
  const w = mount(LazyPanel, {
    props: { loader: () => Promise.reject(new Error('network')) },
    global: { config: { warnHandler: () => {}, errorHandler: () => {} } },
  })
  await flushPromises()
  expect(w.text()).toContain('Не удалось')
  w.unmount()
})
