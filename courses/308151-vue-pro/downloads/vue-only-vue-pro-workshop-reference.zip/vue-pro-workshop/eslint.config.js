import vue from 'eslint-plugin-vue'
import globals from 'globals'
export default [{ignores:['dist/**','node_modules/**','playwright-report/**','test-results/**']},...vue.configs['flat/essential'],{files:['**/*.{js,mjs,vue}'],languageOptions:{globals:{...globals.browser,...globals.node}},rules:{'vue/multi-word-component-names':'off','no-unused-vars':['error',{argsIgnorePattern:'^_',varsIgnorePattern:'^_'}],'no-undef':'error'}}]
