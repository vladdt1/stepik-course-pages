# Публикация безопасного demo на GitHub Pages

Это не публикация учебного API. VITE_DEMO=true выбирает искусственные данные в браузере. Нет настоящих пользователей, общих записей и серверной авторизации. Не используйте реальные персональные данные.

## Локальная проверка
Linux/macOS: `DEPLOY_BASE=/events/ VITE_DEMO=true npm run build`.
PowerShell: `$env:DEPLOY_BASE="/events/"`, затем `$env:VITE_DEMO="true"`, затем `npm run build`.
Замените events на имя вашего репозитория. `npm run preview` выводит адрес предпросмотра; добавьте папку /events/. Путь экрана находится после #. Обновите карточку события: она должна открыться снова.

## Публикация
Создайте личный репозиторий, загрузите исходники, lock и workflow check.yml. В Settings → Pages выберите Source → GitHub Actions.
Создайте .github/workflows/pages.yml с содержимым ниже. Замените events на имя репозитория. Не меняйте настройки существующего общего репозитория курса ради упражнения.

```yaml
name: Проверить и опубликовать demo
on:
  push:
    branches: [main]
permissions:
  contents: read
concurrency:
  group: pages
  cancel-in-progress: true
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 24
          cache: npm
      - run: npm ci
      - run: npm run check
      - run: npx playwright install --with-deps chromium
      - run: npm run test:e2e
      - run: npm run build
        env:
          DEPLOY_BASE: /events/
          VITE_DEMO: 'true'
      - uses: actions/configure-pages@v5
      - uses: actions/upload-pages-artifact@v4
        with:
          path: dist
  deploy:
    needs: build
    permissions:
      pages: write
      id-token: write
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    steps:
      - uses: actions/deploy-pages@v4
        id: deployment
```

Проверьте HTTPS-ссылку в новом окне и на телефоне, прямой вход по hash-маршруту, перезагрузку, поиск и отмену. Данные localStorage исчезают при очистке браузера. Для общего API нужен отдельный защищённый backend, а не /api на Pages.

## Настоящий API и домен — отдельный маршрут
Для основного проекта доставки: подготовьте сервер с Docker/Compose и защищённым backend, настройте DNS A/AAAA на сервер, откройте 80/443, задайте публичный origin и production-параметры cookie, соберите dist с base /.
Пример Caddyfile в уроке показывает /api → api:8080 и остальные пути → /srv с fallback. Caddy и api должны находиться в общей контейнерной сети; /srv — volume с dist. Сохраните /data и /config Caddy в постоянных volumes для сертификатов. API и база не требуют публичных портов при работе через proxy.
Проверьте DNS, доступность ACME, HTTPS, health, права и вход. Это маршрут настройки инфраструктуры, а не обещание автоматического деплоя на произвольный VPS. Учебный API этой мастерской без авторизации наружу не открывать.
